# 01. 프로젝트 아키텍처 설계

## 배운 것

퀀트봇처럼 여러 모듈이 협력하는 프로젝트는 처음부터 구조를 잘 잡아야 한다.
나중에 바꾸면 코드 전체를 뜯어고쳐야 하기 때문이다.

---

## 사용한 설계 패턴

### 1. 레이어드 아키텍처 (Layered Architecture)

```
[데이터 수집층]  collector/     ← 외부 API에서 원시 데이터 가져옴
      ↓
[분석층]        analysis/      ← 기술적 지표 계산, 감성 분석
      ↓
[전략층]        strategy/      ← 앙상블 결합, 포지션 사이징, 손절관리
      ↓
[실행층]        executor/      ← 브로커 API로 주문 실행 + 안전장치
      ↓
[알림층]        notifier/      ← 텔레그램/디스코드 알림
      ↓
[표현층]        dashboard/     ← Flask 웹 대시보드 (사용자 인터페이스)
```

**왜 이렇게 나눴나?**
- 각 층이 독립적이라 한 층을 바꿔도 다른 층에 영향이 적다
- 테스트가 쉽다 (분석 모듈만 따로 테스트 가능)
- 새 기능 추가가 편하다 (팩터 모듈 추가 시 strategy/ 안에만 작업)

### 2. 모듈 구조 (실제 폴더)

```
quant-bot/
├── config/              # 설정 (settings.py, user_settings.json)
├── collector/           # 데이터 수집기 (가격, 뉴스, 거시경제)
│   ├── price_kr.py      # 한국 주가 (pykrx)
│   ├── price_us.py      # 미국 주가 (yfinance)
│   ├── news_collector.py # 뉴스 RSS 수집
│   └── macro.py         # 거시경제 데이터
├── analysis/            # 분석 엔진
│   ├── technical.py     # 기술적 지표 (RSI, MACD, 볼린저 등)
│   └── sentiment.py     # 뉴스 감성 분석
├── strategy/            # 매매 전략
│   ├── ensemble.py      # 앙상블 결합 (핵심)
│   ├── factor_model.py  # 팩터 투자 (모멘텀/밸류/퀄리티/사이즈)
│   ├── position_sizer.py # 포지션 사이징 (ATR/Kelly)
│   └── stop_loss.py     # 손절/익절 관리
├── executor/            # 주문 실행
│   ├── paper_executor.py  # 모의매매기
│   ├── alpaca_executor.py # Alpaca API (미국 실거래)
│   ├── kis_executor.py    # 한국투자증권 API
│   └── safety_guard.py    # 안전장치 (8가지 체크)
├── notifier/            # 알림
│   ├── telegram_bot.py    # 텔레그램 알림
│   └── discord_webhook.py # 디스코드 알림
├── dashboard/           # 웹 대시보드
│   ├── app.py             # Flask 서버 (API + WebSocket)
│   ├── templates/         # HTML 템플릿
│   └── static/            # CSS + JS
├── data/                # 데이터 (DB, 캐시)
├── reports/             # 생성된 보고서
├── scheduler/           # 작업 스케줄러
├── run_bot.py           # 봇 메인 진입점 (QuantBot 클래스)
└── main.py              # CLI 진입점
```

### 3. 설정 관리 패턴

```python
# config/settings.py - dataclass로 타입 안전한 설정
@dataclass
class RiskConfig:
    risk_per_trade: float = 0.02      # 1회 거래당 리스크 2%
    max_position_size: float = 0.10   # 최대 포지션 10%
    max_daily_loss: float = 0.03      # 일일 최대 손실 3%

# config/user_settings.json - 사용자가 대시보드에서 변경하는 설정
# → 서버 재시작해도 유지됨 (영속화)
```

**핵심 교훈:**
- 기본값은 코드(dataclass)에, 사용자 설정은 JSON 파일에
- 설정 변경 시 JSON → dataclass 매핑하는 로직이 필요
- `hasattr()` 체크로 하위 호환성 유지

---

## 실전에서 배운 점

### 순환 의존성 주의
`run_bot.py`가 거의 모든 모듈을 import하므로, 역방향 import가 생기면 안 된다.
해결: 하위 모듈은 상위를 import하지 않고, 필요하면 인자로 전달받는다.

### 인터페이스 통일의 중요성
모든 executor(paper, alpaca, kis)가 같은 메서드를 가져야 한다:
`connect()`, `buy_market()`, `close_position()`, `get_account()`, `get_positions()`
→ 봇 코드 변경 없이 브로커만 교체 가능 (Strategy 패턴)

### 점진적 구현
Phase 1(분석) → Phase 2(백테스트) → Phase 3(알림) → Phase 4(자동매매)
각 단계가 독립적으로 동작하도록 설계하여, 앞 단계가 완성되지 않아도 다음 단계 시작 가능.
