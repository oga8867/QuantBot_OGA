# 08. 에러 핸들링 & 시스템 안정성

## 배운 것

금융 봇은 24시간 돌아가야 하므로, 하나의 에러로 전체가 죽으면 안 된다.
"에러가 나도 최대한 살아남는" 방어적 코딩이 핵심이다.

---

## 1. 핵심 원칙: Graceful Degradation

"전체 기능을 다 못 쓰더라도, 핵심 기능은 계속 작동한다."

```
DB 에러     → 로깅 안 되지만, 매매는 계속
뉴스 API 실패 → 감성 점수 0으로 대체, 나머지 분석은 계속
pykrx 실패   → 하드코딩 폴백 사용, 종목명은 표시
텔레그램 오프  → 알림 없이 매매 계속 실행
```

---

## 2. try-except 패턴

### 나쁜 예: 전체를 하나의 try로 감싸기
```python
def _analyze_symbol(self, symbol):
    try:
        data = fetch_price(symbol)
        score = self.analyzer.analyze(data)
        self.db.log_signal(symbol, score)  # ← DB 에러
        self._execute_buy(symbol)          # ← 실행 안 됨!
    except Exception as e:
        self.logger.error(f"분석 오류: {e}")
```
→ DB 에러 하나가 매수 실행까지 차단

### 좋은 예: 독립적 단계마다 별도 try
```python
def _analyze_symbol(self, symbol):
    # 1단계: 분석 (실패하면 전체 스킵 — 맞는 동작)
    try:
        data = fetch_price(symbol)
        score = self.analyzer.analyze(data)
    except Exception as e:
        self.logger.error(f"분석 오류: {e}")
        return  # 데이터 없으면 매매 불가

    # 2단계: 로깅 (실패해도 매매는 진행)
    try:
        self.db.log_signal(symbol, score)
    except Exception as db_err:
        self.logger.warning(f"DB 로그 실패: {db_err}")
    
    # 3단계: 매매 실행 (DB와 독립적)
    if score > threshold:
        try:
            self._execute_buy(symbol)
        except Exception as trade_err:
            self.logger.error(f"매수 실행 오류: {trade_err}")
```

---

## 3. 폴백 체인 (Fallback Chain)

여러 소스를 순차적으로 시도하여 하나라도 성공하면 사용:

```python
def _get_stock_name(symbol):
    """종목명 조회 — 3단계 폴백"""
    
    # 1순위: yfinance API
    try:
        info = yf.Ticker(symbol).info
        name = info.get('shortName')
        if name:
            return name
    except:
        pass
    
    # 2순위: 하드코딩 딕셔너리
    fallback = {"AAPL": "Apple Inc.", "NVDA": "NVIDIA Corporation", ...}
    if symbol in fallback:
        return fallback[symbol]
    
    # 3순위: 심볼 그대로 반환 (최후의 보루)
    return symbol
```

---

## 4. 알림 시스템의 안전 설계

```python
class TelegramNotifier:
    def __init__(self):
        self.enabled = bool(TOKEN and CHAT_ID)
    
    def send_message(self, text):
        if not self.enabled:
            print(f"[Telegram OFF] {text}")  # 로그에만 출력
            return True  # ← 성공으로 처리! (호출자가 에러 처리 안 하도록)
        
        try:
            requests.post(url, json={"chat_id": CHAT_ID, "text": text})
        except Exception as e:
            print(f"[Telegram 에러] {e}")
            return False  # 실패해도 봇은 계속
```

**핵심:** 알림 실패가 매매를 중단시키면 안 된다.
`[Telegram OFF]`로 시작하는 로그는 텔레그램 미설정 시 출력.

---

## 5. 설정 로드의 방어적 코딩

```python
# hasattr()로 설정 필드 존재 여부 확인 (하위 호환성)
max_daily_loss = (
    settings.risk.max_daily_loss 
    if hasattr(settings.risk, 'max_daily_loss') 
    else 0.03  # 기본값 폴백
)
```

설정 구조가 바뀌어도 기존 설정 파일에서 크래시하지 않음.

---

## 6. 봇 스레드 안전 종료

```python
def stop_bot():
    global bot_instance
    if bot_instance:
        bot_instance.running = False  # while 루프 탈출 조건
        # 스레드가 자연스럽게 종료되길 기다림
        # daemon=True이므로 프로세스 종료 시 강제 종료됨
    bot_instance = None
```

**주의:**
- `thread.join()`으로 기다리면 Flask가 블로킹됨
- `daemon=True` + `running = False` 조합이 가장 안전
- 데이터 정합성이 중요하면 종료 전 DB commit 필요

---

## 7. 에러 복구 체크리스트

| 에러 유형 | 대응 |
|-----------|------|
| API 타임아웃 | 재시도 (최대 3회) + 간격 두기 |
| DB 손상 | 새 DB 생성 + 백업 보관 |
| 메모리 부족 | 캐시 크기 제한 + 주기적 정리 |
| 네트워크 단절 | 연결 복구까지 대기, 로컬 캐시 사용 |
| 예상 못한 예외 | 최상위 try-except + 로그 기록 |
| 파일 잘림/손상 | 백업에서 복원 or 재생성 |

---

## 핵심 교훈

1. **"조용히 실패"가 가장 위험** — 에러 시 반드시 로그를 남겨라
2. **부수 효과(로깅, 알림)가 핵심 로직을 차단하면 안 된다**
3. **외부 의존성(API, DB)은 반드시 실패한다** — 폴백을 준비해라
4. **금융 코드에서 에러 = 돈 손실** — 안전장치는 보수적으로 설계
5. **daemon 스레드 + running 플래그** — 안전한 백그라운드 작업 종료
