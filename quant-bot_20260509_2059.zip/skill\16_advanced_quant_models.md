# 16. 고급 퀀트 모델 (자본 분할, 섹터 로테이션, 거래비용)

대형 퀀트 펀드(Renaissance, Two Sigma, AQR)에서 사용하는 패턴을 개인 투자자 규모로 적용.

---

## 핵심 깨달음

**단일 전략은 시장 체제 변화에 무력하다.**
- 추세 추종: 횡보장에서 망함
- 평균 회귀: 강한 추세장에서 망함
- 팩터(Value): 성장주 강세장에서 부진

**해법**: 여러 전략을 동시 운용하여 분산 효과 → 어떤 시장에서도 한쪽은 작동.

---

## 1. 다중 전략 자본 분할 (Risk Parity)

### 기본 원리

자본을 여러 전략에 나눠 운용:
```
총자본 ₩10,000,000
├─ 50% (₩5M) → 모멘텀 전략 (추세 추종)
├─ 30% (₩3M) → 평균회귀 전략 (RSI 기반)
└─ 20% (₩2M) → 팩터 전략 (가치/품질 점수)
```

### Risk Parity 학술 모델

각 자산이 **동일한 위험 기여도** (Equal Risk Contribution):

```python
weight_i = (1 / sigma_i) / sum(1 / sigma_j)
```

예:
```
모멘텀 변동성 0.20 → inv = 5.0
평균회귀 변동성 0.15 → inv = 6.67
팩터 변동성 0.10 → inv = 10.0
합계 = 21.67

가중치:
모멘텀: 5.0 / 21.67 = 23%
평균회귀: 6.67 / 21.67 = 31%
팩터: 10.0 / 21.67 = 46%
```

→ 변동성 낮은 전략에 더 많은 자본 (위험 균등화)

### 학술 자료

- **DeMiguel et al. (2009)** "Optimal versus Naive Diversification"
  → 1/N 단순 분산이 마코위츠 평균-분산 최적화보다 out-of-sample 우월
  → **추정 오차 누적**이 최적화의 이점을 상쇄
- **AQR (2012)** "Understanding Risk Parity"
  → 각 자산 동일 위험 기여 → 샤프비 최대화

### 구현 패턴

```python
@dataclass
class StrategyAllocation:
    name: str
    weight: float          # 0.5
    capital: float         # 5_000_000
    used: float = 0.0      # 실제 사용 중 (포지션 평가액)
    realized_pnl: float = 0.0
    trade_count: int = 0
    
    @property
    def available(self):
        return max(0, self.capital - self.used)


class CapitalAllocator:
    def pick_strategy(self, symbol, signals):
        """같은 종목에 여러 전략이 BUY면 어떤 전략이 진입?"""
        candidates = []
        for strat, signal in signals.items():
            if signal != "BUY":
                continue
            alloc = self.allocations[strat]
            if alloc.available <= 0:
                continue
            # 점수 = 자본 활용 여유
            combined = (1 - alloc.utilization)
            candidates.append((strat, combined))
        
        if not candidates:
            return None
        return max(candidates, key=lambda x: x[1])[0]
```

### 실전 시그널 함수

#### 모멘텀 (Momentum)
```python
def momentum_signal(df):
    ma_short = df["Close"].rolling(20).mean().iloc[-1]
    ma_long = df["Close"].rolling(50).mean().iloc[-1]
    momentum_20d = (df["Close"].iloc[-1] / df["Close"].iloc[-20] - 1)
    
    if ma_short > ma_long * 1.01 and momentum_20d > 0.02:
        return "BUY"
    elif ma_short < ma_long * 0.99:
        return "SELL"
    return "HOLD"
```

#### 평균회귀 (Mean Reversion)
```python
def mean_reversion_signal(df):
    rsi = df["RSI"].iloc[-1]
    if rsi < 30:    # 과매도 → 반등 기대
        return "BUY"
    elif rsi > 70:  # 과매수 → 조정 기대
        return "SELL"
    return "HOLD"
```

---

## 2. 섹터 로테이션 (Sector Rotation)

### 이론적 배경

경기 사이클(Business Cycle)은 4국면:
```
회복(Recovery) → 호황(Peak) → 후퇴(Recession) → 침체(Trough) → 회복...
```

각 국면별 우세 섹터:

| 국면 | 우세 섹터 | 약세 섹터 |
|------|----------|----------|
| 회복 초기 | 경기소비재(XLY), 금융(XLF), 부동산(XLRE) | 필수소비재 |
| 호황 | 기술주(XLK), 산업재(XLI) | 유틸리티 |
| 정점 | 에너지(XLE), 원자재(XLB) | 임의소비재 |
| 후퇴 | 헬스케어(XLV), 필수소비재(XLP), 유틸리티(XLU) | 금융, 산업재 |

### 상대 강도(Relative Strength) 자동 선정

경기 국면 예측은 어려우므로, 데이터 기반으로 자동 선정:

```python
def analyze_sector_rotation():
    sectors = {
        "XLK": "Technology", "XLF": "Financials",
        "XLV": "Healthcare", "XLY": "Consumer Discretionary",
        "XLP": "Consumer Staples", "XLI": "Industrials",
        "XLE": "Energy", "XLB": "Materials",
        "XLU": "Utilities", "XLRE": "Real Estate",
    }
    benchmark = "SPY"
    
    bench_return = (spy[-1] / spy[-60] - 1) * 100  # 60일 수익률
    
    scores = []
    for sym in sectors:
        sector_return = (data[-1] / data[-60] - 1) * 100
        relative_strength = sector_return - bench_return
        scores.append((sym, relative_strength))
    
    scores.sort(key=lambda x: x[1], reverse=True)
    leading = scores[:3]    # 상위 3개 섹터
    lagging = scores[-3:]   # 하위 3개 섹터
    
    return leading, lagging
```

### 활용: 점수 보정

종목이 강세 섹터에 속하면 매수 신호 강화, 약세 섹터면 약화:

```python
def get_sector_boost(symbol, rotation_result):
    sector = yf.Ticker(symbol).info.get("sector", "")
    
    for s in rotation_result.leading_sectors:
        if sector in s.name:
            return +0.10   # 매수 신호 +10% 가중
    for s in rotation_result.lagging_sectors:
        if sector in s.name:
            return -0.10   # 매수 신호 -10% 약화
    return 0.0
```

### 학술 자료

- **Stovall (1996)** "Sector Investing" — 4국면 모델 원조
- **Faber (2007)** "The Best of Both Worlds" — 모멘텀 + 섹터 로테이션 결합
- **Two Sigma (2022)** "Sector Rotation Using Dynamic Factor Models"

---

## 3. 정교한 거래비용 모델

### 거래비용 = 수수료 + 스프레드 + 시장 충격 + 세금

```python
@dataclass
class CostBreakdown:
    commission: float          # 수수료 (편도)
    spread_cost: float         # 호가 스프레드
    slippage: float            # 일시적 시장 충격
    permanent_impact: float    # 영구적 시장 충격 (대량거래만)
    total: float
    total_pct: float
```

### 1. 수수료 (Commission)

| 시장 | 모의 | 실거래 | 비고 |
|------|-----|-------|------|
| 한국 (KIS) | 0.015% | 0.015% | 편도 (왕복 0.030%) |
| 미국 (Alpaca) | 0% | 0% | 무료 |
| 미국 (IBKR) | $0.005/주 | $0.005/주 | 최소 $1 |

### 2. 거래세 (Tax) — 한국만

- 매수: 0%
- **매도: 0.23%** (코스피/코스닥)
- → 한국 주식은 왕복 약 0.245% 비용

### 3. 호가 스프레드

```python
spread_pct = BASE_SPREAD * (1 + volatility)
# BASE_SPREAD = 0.05% (대형주)
# 변동성 20% 종목 → 0.06%
```

### 4. 시장 충격 (Almgren Square-Root Law)

```python
# Almgren et al. (2005)
impact_pct = Y * sigma * sqrt(quantity / avg_daily_volume)

# Y ≈ 0.10 (학술 추정)
# sigma = 연환산 변동성
# ADV = 일평균 거래량
```

예:
```
삼성전자 ADV: 10,000,000주
변동성: 20%
주문량: 100주

충격 = 0.10 × 0.20 × sqrt(100/10_000_000)
     = 0.10 × 0.20 × 0.00316
     = 0.0000632 (약 0.006%)
```

→ 100주는 거의 충격 없음. 하지만:

```
ADV의 1% 거래 (100,000주) 시:
충격 = 0.10 × 0.20 × sqrt(0.01) = 0.002 (0.2%)
```

→ 대량 거래는 시장 충격 누적되어 비용 급증.

### 5. 영구적 충격 (대량 거래만)

```python
# ADV의 1% 이상 거래 시
permanent_impact = 0.5 * Y * sigma * (Q / ADV) * notional
```

개인 투자자 규모에서는 거의 무시 가능.

### 거래 가치 판단

신호의 예상 수익이 거래비용을 충분히 상회하는지 체크:

```python
def is_trade_profitable(expected_return_pct, ...):
    round_trip_cost = round_trip_cost_pct(...)
    # 안전 마진 1.5배 (실제 비용은 추정치보다 큼)
    return expected_return_pct > round_trip_cost * 1.5
```

예시:
```
예상 수익: 1.2%
왕복 비용: 0.5%
마진 적용: 0.5 × 1.5 = 0.75%
1.2% > 0.75% → 거래 가치 있음 ✅
```

### 학술 자료

- **Almgren & Chriss (2000)** "Optimal Execution of Portfolio Transactions"
  → 시장 충격을 영구적 + 일시적으로 분해
- **Bertsimas & Lo (1998)** "Optimal Control of Execution Costs"
  → VWAP 분할 매매로 충격 최소화
- **Almgren et al. (2005)** "Direct Estimation of Equity Market Impact"
  → Square-Root Law (시장 충격 ≈ √Q)

---

## 통합: 봇 의사결정 흐름

```
1. 시장 체제 분석 (적응형 임계값)
   ├─ VIX 조회 → 4단계 분류
   ├─ SPY 200MA → Bull/Bear/Sideways
   └─ 임계값/포지션크기 자동 조정

2. 섹터 로테이션 분석
   ├─ 60일 모멘텀 계산
   ├─ 강세 섹터 상위 3개 선정
   └─ 종목별 점수 보정 ±0.10

3. 종목 분석 (앙상블)
   ├─ 기술적 분석 (RSI, MACD, BB)
   ├─ 팩터 분석 (Value, Quality)
   ├─ 뉴스 감성 분석
   └─ 종합 점수 계산

4. 자본 분할 결정
   ├─ 각 전략의 사용 가능 자본 확인
   ├─ pick_strategy(): 점수 + 자본 여유로 선택
   └─ Kelly + ATR + 적응형 배수로 사이즈 결정

5. 거래비용 검증
   ├─ 예상 수익 vs 왕복 비용 비교
   └─ 비용 초과 시 매매 차단

6. 매매 실행
   ├─ 안전장치 통과 (킬스위치, 한도)
   ├─ 매수/매도 주문
   └─ ExitManager에 진입 등록

7. 포지션 관리 (지속적)
   ├─ 1분마다 가격 갱신 (KIS/yfinance)
   ├─ ExitManager 청산 체크
   └─ 트레일링 스탑 갱신
```

---

## 흔한 실수

### ❌ 실수 1: 너무 많은 전략 동시 운용
- 전략 5개 이상 → 거래비용 누적, 신호 충돌
- 권장: 3개 (모멘텀 + 평균회귀 + 팩터)

### ❌ 실수 2: 같은 종목에 여러 전략 충돌
- 모멘텀 BUY, 평균회귀 SELL → 어떻게 처리?
- 해결: pick_strategy()에서 한 전략만 선택, 나머지는 무시

### ❌ 실수 3: 거래비용 무시
- 백테스트 +20%, 라이브 -5% → 비용 차이로 흔히 발생
- 해결: 백테스트 시 0.1% 왕복 비용 반드시 차감

### ❌ 실수 4: 섹터 로테이션을 너무 자주 변경
- 매일 바뀌면 매매 비용 폭증
- 권장: 60일 모멘텀, 1주일에 1번 갱신

---

## 대형 퀀트 펀드 사례

### Renaissance Technologies (Medallion Fund)
- 연평균 +66% (1988-2018)
- **수십 가지 모델 동시 운용**, 보유기간 수초~수분
- 데이터: 가격 + 기상, 위성사진, 항공편 등
- 개인이 따라할 수 없음 (인프라/데이터 격차)

### Two Sigma
- 600+ 박사급 연구원
- "**알파 카드**" 단위로 수백 개 전략 보유
- 자본 자동 배분 (포트폴리오 최적화)
- → **자본 분할 방식의 정수**

### AQR (Cliff Asness)
- 학계 출신, 팩터 투자 중심
- 5대 팩터: **Value, Momentum, Quality, Low-Vol, Size**
- 각 팩터 정해진 자본 비중, 분기 리밸런싱

### Citadel
- 멀티 매니저 모델 — 60+ 팀이 각자 전략 운용
- 각 팀에 자본 + 리스크 한도 부여
- **각 팀 내부에서 다시 앙상블 또는 분할 사용**

### Bridgewater (Ray Dalio)
- "**All Weather**" — 4개 경제 국면별 자산 배분
- 알고리즘이 아닌 **체계적 거시 투자**

### 공통점
1. 단일 전략 의존 금지
2. 포지션 사이징 알고리즘 (Kelly 변형)
3. 백테스팅 + 라이브 모니터링 (5년+ 검증)
4. 리스크 한도 (전략/섹터/종목별)
5. 거래비용 모델링

---

## 개인 투자자 적용 가능성

| 가능 ✅ | 어려움 ❌ |
|--------|----------|
| 팩터 투자 (AQR 스타일) | HFT (인프라 부족) |
| 자산배분 (Bridgewater 변형) | ML 알파 (데이터 한계) |
| 시간 분산 (DCA + 모멘텀) | 100+ 전략 동시 운용 |
| **단순 앙상블** ✓ | 시장 미시구조 알파 |
| **3-전략 자본 분할** ✓ | 전용 인프라 |
| **섹터 로테이션** ✓ | 알트 데이터 |

이 봇은 **AQR/Two Sigma의 단순 버전**을 구현한 것:
- 다중 알파 (technical + factor + sentiment)
- 자본 분할 (모멘텀/평균회귀/팩터)
- 섹터 로테이션 보정
- 적응형 임계값 (VIX 체제)

---

*핵심: 대형 퀀트 펀드를 "복제"는 못 하지만, 그들의 핵심 원칙(분산, 위험 관리, 비용 모델링)은 개인 규모로도 적용 가능. 단순함이 강건함이다.*
