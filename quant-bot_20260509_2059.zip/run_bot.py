"""
=============================================================================
run_bot.py - 퀀트봇 자동매매 모드 실행기
=============================================================================

스케줄러를 시작하여 정해진 시간에 분석 → 신호 생성 → 주문 실행을 자동화합니다.

실행 흐름:
1. 설정 로드 (자본금, 리스크, 전략 파라미터)
2. 브로커 연결 (Alpaca/KIS/Paper)
3. 스케줄러 시작
4. 정해진 시간에 자동으로:
   - 데이터 수집 → 분석 → 신호 생성
   - 리스크 체크 → 포지션 사이징
   - 주문 실행 → 알림 전송

사용법:
    python run_bot.py                         # 모의매매, 기본 설정
    python run_bot.py --capital 50000000      # ���본금 5천만원
    python run_bot.py --live                  # 실거래 모드 (주의!)
    python run_bot.py --broker alpaca         # Alpaca 사용
    python run_bot.py --broker kis            # 한국투자증권 사용
=============================================================================
"""

import argparse
import sys
import os
import time
import signal
import threading
from datetime import datetime
from typing import Dict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.settings import Settings, CapitalConfig, RiskConfig
from collectors.price_us import PriceCollectorUS
from collectors.price_kr import PriceCollectorKR
from analyzers.technical import TechnicalAnalyzer
from strategy.ensemble import EnsembleStrategy
from risk.position_sizer import PositionSizer
from risk.stop_loss import StopLossManager
from executor.paper_executor import PaperExecutor
from notifier.telegram_bot import TelegramNotifier
from notifier.discord_webhook import DiscordNotifier
from scheduler.job_manager import JobManager
from database.cache import DatabaseManager
from executor.safety_guard import SafetyGuard, SafetyConfig
from utils.logger import setup_logger
from utils.market import to_krw


class QuantBot:
    """
    퀀트봇 메인 오케스트레이터

    모든 모듈을 연결하고 전체 매매 프로세스를 관리합니다.
    """

    def __init__(self, settings: Settings, broker: str = "paper", live: bool = False):
        """
        Parameters:
            settings: 설정 객체
            broker: "paper", "alpaca", "kis"
            live: True=실거래 (주의!)
        """
        self.settings = settings
        self.logger = setup_logger(level="INFO", log_file=True)
        # ★ threading.Event: 스레드 안전한 stop 시그널
        self._stop_event = threading.Event()

        # 모듈 초기화
        self.analyzer = TechnicalAnalyzer(settings.technical)
        self.ensemble = EnsembleStrategy()

        # ── 모의매매 모드에서 앙상블 임계값 완화 ──
        if not live:
            self.ensemble.buy_threshold = 0.10
            self.ensemble.sell_threshold = -0.10
            self.logger.info(
                "[앙상블] 모의매매 모드: 임계값 완화 "
                f"(매수>{self.ensemble.buy_threshold}, "
                f"매도<{self.ensemble.sell_threshold})"
            )
        self.position_sizer = PositionSizer(
            capital=settings.capital.total_capital,
            risk_per_trade=settings.risk.risk_per_trade,
            max_position_pct=settings.risk.max_position_size,
            stop_loss_atr_mult=settings.risk.stop_loss_atr_multiplier,
            kelly_fraction=settings.risk.kelly_fraction
        )
        self.stop_manager = StopLossManager(
            atr_multiplier=settings.risk.stop_loss_atr_multiplier,
            risk_reward_ratio=settings.risk.risk_reward_ratio
        )
        # 알림: 텔레그램 + 디스코드 (설정된 것만 활성화됨)
        self.notifier = TelegramNotifier()
        self.discord = DiscordNotifier()
        self.db = DatabaseManager()
        self.db.initialize()

        # 브로커 실행기 선택
        self.executor = self._create_executor(broker, live)

        # 안전장치 (실거래 시 특히 중요)
        capital = settings.capital.total_capital
        max_order_val = capital * 0.20
        min_order_val = capital * 0.001

        self.safety = SafetyGuard(
            capital=capital,
            paper=(not live),
            config=SafetyConfig(
                max_daily_loss_pct=settings.risk.max_daily_loss if hasattr(settings.risk, 'max_daily_loss') else 0.03,
                max_order_pct=settings.risk.max_position_size if hasattr(settings.risk, 'max_position_size') else 0.10,
                max_positions=10,
                max_position_weight=0.20,
                max_daily_trades=50,
                consecutive_loss_limit=5,
                order_delay_sec=3 if live else 0,
                max_order_value=max_order_val,
                min_order_value=min_order_val,
            )
        )
        self.logger.info(
            f"[SafetyGuard] 주문 한도: "
            f"최소 {min_order_val:,.0f} / 최대 {max_order_val:,.0f} "
            f"(자본금 {capital:,.0f} 기준)"
        )

        # 스케줄러
        self.scheduler = JobManager()

        # ── 매도 후 쿨다운 (반복매매 방지) ──
        # 같은 종목을 매도 직후 다시 매수하면 수수료만 먹는 무의미한 거래가 됨
        # 매도 시점을 기록하고, 일정 시간(쿨다운) 동안 재매수를 차단
        self._sell_cooldowns: Dict[str, float] = {}  # {symbol: 매도 시각(timestamp)}
        self._cooldown_seconds = 3600  # 기본 1시간 쿨다운 (초)
        self._restore_sell_cooldowns()  # DB에서 최근 매도 기록 기반 쿨다운 복원

        # ── ExitManager: 손절/익절/트레일링 스탑 자동 청산 ──
        # 진입가 기반 자동 청산 의사결정. 앙상블 SELL 신호와 별개로
        # 매 분석 사이클에서 보유 포지션의 청산 조건을 체크합니다.
        # 학술적 근거:
        # - Le Beau Chandelier Exit: 22일 ATR × 3 (드로우다운 22% 감소)
        # - Half-Kelly + ATR 스탑: 약 75% 성장률, 변동성 대폭 감소
        from executor.exit_manager import ExitManager
        self.exit_manager = ExitManager(
            atr_stop_multiplier=getattr(settings.risk, 'stop_loss_atr_multiplier', 2.0),
            rr_ratio=getattr(settings.risk, 'risk_reward_ratio', 2.0),
            trailing_atr_multiplier=3.0,  # Chandelier Exit 표준
            enable_partial=True,
            enable_time_stop=False,
        )
        self._restore_exit_states()  # DB에서 ExitManager 상태 복원

        # ── 적응형 임계값: VIX/체제 기반 동적 매수/매도 임계값 ──
        # 변동성 ↑ → 임계값 ↑ (강한 신호만), 위기장 → 포지션 ↓
        # 5분마다 갱신, 분석 사이클 시작 시 자동 적용
        from strategy.adaptive_threshold import AdaptiveThresholdManager
        self.adaptive_thresholds = AdaptiveThresholdManager(paper=(not live))
        self._current_thresholds = None  # 분석 사이클에서 갱신

        # ── 종목 자동 발굴 시스템 ──
        # 워치리스트 외 유망 종목을 섹터/시장에서 탐색하여 분석 대상에 추가
        from config.settings import DiscoveryConfig
        self._discovery_config = getattr(settings, 'discovery', DiscoveryConfig())
        self._discovery_cycle_count = 0    # 발굴 주기 카운터
        self._discovered_us: list = []     # 자동 발굴된 미국 종목 리스트
        self._discovered_kr: list = []     # 자동 발굴된 한국 종목 리스트
        self._discovery_hold_counts: dict = {}  # {symbol: 연속 HOLD 횟수}
        self._load_discovered_from_db()    # DB에서 이전 발굴 결과 복원

    @property
    def running(self) -> bool:
        """하위호환: self.running 접근 시 Event 상태 반환"""
        return not self._stop_event.is_set()

    @running.setter
    def running(self, value: bool):
        """하위호환: self.running = True/False 지원"""
        if value:
            self._stop_event.clear()
        else:
            self._stop_event.set()

    def _create_executor(self, broker: str, live: bool):
        """
        브로커 실행기 생성

        지원 브로커:
        - "paper": 모의매매 (기본)
        - "alpaca": 미국 주식 (Alpaca Markets)
        - "kis": 한국 주식 (한국투자증권)
        - "dual": 듀얼 마켓 (KIS + Alpaca 동시 운용)
        """
        if broker == "dual":
            # ── 듀얼 모드: KIS(한국) + Alpaca(미국) 동시 운용 ──
            from executor.dual_executor import DualExecutor
            self.logger.info(
                "[실행기] 듀얼 마켓 모드 — KIS(한국) + Alpaca(미국) 동시 운용"
            )
            return DualExecutor(paper=not live)
        elif broker == "alpaca":
            from executor.alpaca_executor import AlpacaExecutor
            return AlpacaExecutor(paper=not live)
        elif broker == "kis":
            from executor.kis_executor import KISExecutor
            return KISExecutor(paper=not live)
        else:
            # DB를 PaperExecutor에 주입 → 거래 이력/포지션이 DB에 영속 저장됨
            # 봇 재시작 시 connect()에서 자동으로 이전 상태 복원
            return PaperExecutor(
                initial_capital=self.settings.capital.total_capital,
                currency=self.settings.capital.currency,
                db=self.db
            )

    def start(self):
        """봇 시작"""
        self.logger.info("=" * 50)
        self.logger.info("  퀀트봇 시작")
        self.logger.info("=" * 50)
        self.logger.info(self.settings.summary())

        # 브로커 연결
        if not self.executor.connect():
            self.logger.error("브로커 연결 실패! 종료합니다.")
            return

        # 스케줄 설정
        self.scheduler.setup_default_schedule(
            analyze_kr_func=self._analyze_kr_market,
            analyze_us_func=self._analyze_us_market,
            risk_check_func=self._check_risk,
        )

        # 시작 알림 (텔레그램 + 디스코드)
        self.notifier.send_message(
            f"🤖 <b>퀀트봇 시작</b>\n"
            f"모드: {'실거래' if not self.executor.paper else '모의매매'}\n"
            f"자본금: {self.settings.capital.total_capital:,.0f} "
            f"{self.settings.capital.currency}"
        )
        self.discord.send_bot_status(
            running=True,
            mode="live" if not self.executor.paper else "paper",
            equity=self.settings.capital.total_capital,
            pnl_pct=0.0
        )

        # 스케줄러 시작
        self.scheduler.start()
        self.running = True

        self.logger.info("봇이 실행 중입니다. Ctrl+C로 종료...")

        # 메인 루프 (에러 자동 복구 포함)
        # [에러 복구 전략]
        # - 일반 예외: 로그 후 계속 실행 (재시도 카운터 사용)
        # - 연속 5회 에러: 알림 전송 후 30초 대기
        # - KeyboardInterrupt/SystemExit: 정상 종료
        # - DB 연결 끊김: 자동 재연결
        error_count = 0
        MAX_ERRORS = 5

        try:
            while self.running:
                try:
                    time.sleep(1)
                    error_count = 0  # 정상 루프 → 에러 카운터 초기화
                except KeyboardInterrupt:
                    break
                except Exception as e:
                    error_count += 1
                    self.logger.error(f"[에러 복구] 메인 루프 에러 #{error_count}: {e}")

                    if error_count >= MAX_ERRORS:
                        self.logger.critical(f"[에러 복구] 연속 {MAX_ERRORS}회 에러 발생!")
                        self.notifier.send_risk_alert(
                            f"봇 연속 에러 {MAX_ERRORS}회!\n"
                            f"마지막 에러: {str(e)[:100]}\n"
                            f"30초 후 재시도합니다.",
                            level="CRITICAL"
                        )
                        error_count = 0
                        time.sleep(30)

                    # DB 재연결 시도
                    self._try_reconnect_db()
        except (KeyboardInterrupt, SystemExit):
            pass
        finally:
            self.stop()

    def stop(self):
        """봇 중지"""
        self.running = False
        self.scheduler.stop()
        self.notifier.send_message("🛑 <b>퀀트봇 종료</b>")
        # 디스코드 종료 알림
        account = self.executor.get_account()
        pnl_pct = (account.total_equity / self.settings.capital.total_capital - 1) * 100
        self.discord.send_bot_status(
            running=False,
            mode="live" if not self.executor.paper else "paper",
            equity=account.total_equity,
            pnl_pct=pnl_pct
        )
        self.db.close()
        self.logger.info("퀀트봇 종료됨")

    def _try_reconnect_db(self):
        """
        DB 연결 상태 확인 및 재연결

        SQLite 연결이 끊어지면 (파일 잠금, 디스크 오류 등)
        자동으로 재연결을 시도합니다.
        """
        try:
            # 간단한 쿼리로 연결 확인
            self.db.conn.execute("SELECT 1").fetchone()
        except Exception:
            self.logger.warning("[에러 복구] DB 연결 끊김, 재연결 시도...")
            try:
                self.db.initialize()
                self.logger.info("[에러 복구] DB 재연결 성공")
            except Exception as e:
                self.logger.error(f"[에러 복구] DB 재연결 실패: {e}")

    # ═══════════════════════════════════════════════════════════════════════
    # 시장 영업시간 체크 + 매도 쿨다운
    # ═══════════════════════════════════════════════════════════════════════

    def _is_market_open(self, market: str) -> bool:
        """
        시장이 현재 열려 있는지 확인

        한국 (KR): 평일 09:00~15:30 KST
        미국 (US): 평일 09:30~16:00 ET (한국시간 23:30~06:00, 서머타임 22:30~05:00)

        ★ 모의매매에서도 실제 시장 시간에만 거래해야 의미 있는 시뮬레이션이 됩니다.
          장 마감 중에 분석하면 가격이 안 변하므로 같은 신호가 반복 → 무의미한 매매

        Parameters:
            market: "KR" 또는 "US"

        Returns:
            True이면 거래 가능, False이면 장 마감 중
        """
        from datetime import timezone, timedelta as _td
        now_utc = datetime.now(timezone.utc)

        if market == "KR":
            # KST = UTC + 9
            kst = now_utc + _td(hours=9)
            weekday = kst.weekday()  # 0=월, 6=일
            if weekday >= 5:  # 주말
                return False
            hour, minute = kst.hour, kst.minute
            # 09:00 ~ 15:30 KST
            if hour < 9 or (hour == 15 and minute > 30) or hour >= 16:
                return False
            return True

        elif market == "US":
            # ET = UTC - 5 (겨울) / UTC - 4 (서머타임)
            # 간단하게 UTC - 4 (서머타임 기준, 3월~11월)으로 처리
            # 정확한 서머타임 판별은 복잡하므로, 보수적으로 넓은 범위 사용
            et = now_utc - _td(hours=4)
            weekday = et.weekday()
            if weekday >= 5:  # 주말
                return False
            hour, minute = et.hour, et.minute
            # 09:30 ~ 16:00 ET
            if hour < 9 or (hour == 9 and minute < 30) or hour >= 16:
                return False
            return True

        return True  # 알 수 없는 시장은 허용

    def _restore_sell_cooldowns(self):
        """
        DB의 최근 매도 기록에서 쿨다운 상태 복원 (서버 재시작 대응)

        서버를 재시작하면 메모리의 _sell_cooldowns가 사라져서
        최근에 매도한 종목을 바로 재매수하는 문제가 발생합니다.
        DB의 trades 테이블에서 최근 매도 기록을 읽어
        아직 쿨다운 기간 내인 종목을 복원합니다.
        """
        try:
            trades = self.db.get_trades(limit=200)  # 최근 200건
            now = time.time()
            restored = 0

            for trade in trades:
                if trade.get("side", "").upper() != "SELL":
                    continue

                symbol = trade.get("symbol", "")
                if not symbol:
                    continue

                # 이미 쿨다운에 등록된 종목은 건너뜀 (가장 최근 매도만 유효)
                if symbol in self._sell_cooldowns:
                    continue

                # 매도 시각 파싱
                try:
                    ts_str = trade.get("timestamp", "")
                    sell_time = datetime.fromisoformat(ts_str).timestamp()
                except (ValueError, TypeError):
                    continue

                # 아직 쿨다운 기간 내인지 확인
                elapsed = now - sell_time
                if elapsed < self._cooldown_seconds:
                    self._sell_cooldowns[symbol] = sell_time
                    remaining = int(self._cooldown_seconds - elapsed)
                    self.logger.info(
                        f"[쿨다운 복원] {symbol}: 매도 후 {int(elapsed)}초 경과, "
                        f"{remaining}초 남음"
                    )
                    restored += 1

            if restored > 0:
                self.logger.info(f"[쿨다운 복원] {restored}개 종목 쿨다운 상태 DB에서 복원 완료")

        except Exception as e:
            self.logger.warning(f"[쿨다운 복원] DB에서 복원 실패 (무시): {e}")

    def _restore_exit_states(self):
        """
        DB에서 ExitManager 상태 복원 (서버 재시작 대응)

        positions 테이블에서 진입 시점 ATR, 현재 손절선, 최고가, 분할 매도 비중을
        읽어와 ExitManager 메모리에 등록합니다.
        DB에 entry_atr=0인 구버전 포지션은 복원 시 ATR을 재추정합니다.
        """
        try:
            db_positions = self.db.load_positions()
            restored = 0

            for pos_data in db_positions:
                symbol = pos_data.get("symbol", "")
                if not symbol:
                    continue
                quantity = pos_data.get("quantity", 0)
                if isinstance(quantity, bytes):
                    import struct
                    quantity = struct.unpack('<q', quantity)[0]
                if quantity <= 0:
                    continue

                avg_price = float(pos_data.get("avg_price", 0))
                if avg_price <= 0:
                    continue

                # ExitManager 상태 필드들 (구버전 포지션은 0)
                entry_atr = float(pos_data.get("entry_atr", 0) or 0)
                current_stop = float(pos_data.get("current_stop", 0) or 0)
                highest = float(pos_data.get("highest_since_entry", 0) or 0)
                partial_sold = float(pos_data.get("partial_sold_pct", 0) or 0)
                target_1 = float(pos_data.get("target_1", 0) or 0)
                target_2 = float(pos_data.get("target_2", 0) or 0)
                stop_price = float(pos_data.get("stop_price", 0) or 0)
                bought_at = pos_data.get("bought_at", "")

                # ── 신규 포지션이거나 ATR 데이터가 없으면 추정 ──
                # 표준 가정: ATR = avg_price × 2% (대다수 종목의 일평균 변동폭)
                if entry_atr <= 0:
                    entry_atr = avg_price * 0.02
                if current_stop <= 0:
                    current_stop = stop_price if stop_price > 0 else (avg_price - entry_atr * 2.0)
                if target_1 <= 0:
                    target_1 = avg_price + entry_atr * 2.0 * 1.0  # 2× ATR (1R)
                if target_2 <= 0:
                    target_2 = avg_price + entry_atr * 2.0 * 2.0  # 2× ATR × 2 (2R)
                if highest <= 0:
                    highest = avg_price

                # 진입 시각 파싱
                from executor.exit_manager import PositionExitState
                try:
                    entry_time = datetime.fromisoformat(bought_at) if bought_at else datetime.now()
                except (ValueError, TypeError):
                    entry_time = datetime.now()

                state = PositionExitState(
                    symbol=symbol,
                    entry_price=avg_price,
                    entry_atr=entry_atr,
                    entry_time=entry_time,
                    initial_stop=current_stop,
                    target_1=target_1,
                    target_2=target_2,
                    current_stop=current_stop,
                    highest_price_since_entry=highest,
                    partial_sold_pct=partial_sold,
                )
                self.exit_manager.restore_state(state)
                restored += 1

            if restored > 0:
                self.logger.info(
                    f"[ExitManager 복원] {restored}개 포지션의 청산 상태 DB에서 복원"
                )

        except Exception as e:
            self.logger.warning(f"[ExitManager 복원] 실패 (무시, 신규로 시작): {e}")

    def _save_exit_state(self, symbol: str):
        """ExitManager 상태를 DB positions 테이블에 동기화"""
        if not self.db:
            return
        state_dict = self.exit_manager.get_state_dict(symbol)
        if not state_dict:
            return
        try:
            # positions 테이블의 ExitManager 필드 업데이트
            self.db.conn.execute(
                """UPDATE positions SET
                    entry_atr = ?, current_stop = ?, highest_since_entry = ?,
                    partial_sold_pct = ?, target_1 = ?, target_2 = ?,
                    stop_price = ?
                WHERE symbol = ?""",
                (
                    float(state_dict["entry_atr"]),
                    float(state_dict["current_stop"]),
                    float(state_dict["highest_since_entry"]),
                    float(state_dict["partial_sold_pct"]),
                    float(state_dict["target_1"]),
                    float(state_dict["target_2"]),
                    float(state_dict["current_stop"]),  # stop_price도 동기화
                    symbol,
                )
            )
            self.db.conn.commit()
        except Exception as e:
            self.logger.debug(f"[ExitManager 동기화] {symbol} 실패 (무시): {e}")

    def _is_in_cooldown(self, symbol: str) -> bool:
        """
        매도 후 쿨다운 중인지 확인

        같은 종목을 매도 직후 재매수하면 수수료만 낭비하는 무의미한 거래입니다.
        매도 후 일정 시간(기본 1시간) 동안 해당 종목 재매수를 차단합니다.

        Returns:
            True이면 쿨다운 중 (매수 차단), False이면 매수 허용
        """
        if symbol not in self._sell_cooldowns:
            return False

        elapsed = time.time() - self._sell_cooldowns[symbol]
        if elapsed < self._cooldown_seconds:
            remaining = int(self._cooldown_seconds - elapsed)
            self.logger.debug(
                f"[쿨다운] {symbol}: 매도 후 {int(elapsed)}초 경과, "
                f"{remaining}초 남음 (재매수 차단)"
            )
            return True

        # 쿨다운 만료 → 정리
        del self._sell_cooldowns[symbol]
        return False

    def _analyze_us_market(self):
        """
        미국 시장 분석 (스케줄 작업)

        통합 워치리스트 = 사용자 관심종목 + 자동 발굴 종목 + 보유 종목

        [v2.1] 발굴 시스템 주기적 호출 추가
        """
        # ── 종목 발굴 주기 체크 ──
        # cycle_multiplier회 분석마다 1번 발굴 실행
        self._discovery_cycle_count += 1
        if (self._discovery_config.enabled and
                self._discovery_cycle_count % self._discovery_config.cycle_multiplier == 0):
            try:
                self._run_discovery()
            except Exception as e:
                self.logger.error(f"[발굴] 실행 중 오류 (분석은 계속 진행): {e}")

        from config.settings import US_WATCHLIST
        watchlist = self._build_merged_watchlist("us", US_WATCHLIST)
        self.logger.info(f"[스케줄] 미국 시장 분석 시작... ({len(watchlist)}종목)")
        self._run_analysis(watchlist, market="US")
        # 분석 후 자동 발굴 종목 순환 (연속 HOLD 종목 제거)
        self._rotate_discovered("US")

    def _analyze_kr_market(self):
        """
        한국 시장 분석 (스케줄 작업)

        통합 워치리스트 = 사용자 관심종목 + 자동 발굴 종목 + 보유 종목
        """
        from config.settings import KR_WATCHLIST
        watchlist = self._build_merged_watchlist("kr", KR_WATCHLIST)
        self.logger.info(f"[스케줄] 한국 시장 분석 시작... ({len(watchlist)}종목)")
        self._run_analysis(watchlist, market="KR")
        self._rotate_discovered("KR")

    def _load_user_watchlist(self, market: str) -> list:
        """
        대시보드 user_settings.json에서 관심종목을 로드합니다.

        Args:
            market: "us" 또는 "kr"

        Returns:
            관심종목 리스트 (없으면 빈 리스트 → 호출측에서 기본값 사용)
        """
        import json
        settings_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "config", "user_settings.json"
        )
        try:
            if os.path.exists(settings_path):
                with open(settings_path, "r", encoding="utf-8") as f:
                    settings = json.load(f)

                key = f"{market}_watchlist"  # "us_watchlist" 또는 "kr_watchlist"
                user_list = settings.get(key, [])

                if user_list:
                    # 한국 종목은 .KS/.KQ 접미사 필요
                    if market == "kr":
                        formatted = []
                        for code in user_list:
                            code = str(code).strip()
                            # 이미 .KS/.KQ가 있으면 그대로, 없으면 .KS 추가
                            if not code.endswith((".KS", ".KQ")):
                                formatted.append(f"{code}.KS")
                            else:
                                formatted.append(code)
                        return formatted
                    return user_list
        except Exception as e:
            self.logger.debug(f"사용자 워치리스트 로드 실패: {e}")

        return []  # 빈 리스트 → 호출측에서 기본 리스트 사용

    # ═══════════════════════════════════════════════════════════════════════
    # 종목 자동 발굴 시스템
    # ═══════════════════════════════════════════════════════════════════════
    #
    # 워치리스트 고정 종목만 보는 한계를 벗어나,
    # 섹터 유니버스(~100종목) + 시장 상위 종목에서 유망 종목을 자동 탐색합니다.
    #
    # 흐름:
    # 1. _run_discovery()  — N번째 분석 사이클마다 발굴 실행
    # 2. _build_merged_watchlist() — 사용자 종목 + 발굴 종목 + 보유 종목 통합
    # 3. _rotate_discovered() — 연속 HOLD 종목 자동 제거
    # ═══════════════════════════════════════════════════════════════════════

    def _build_merged_watchlist(self, market: str, default_list: list) -> list:
        """
        통합 워치리스트 구성

        = 사용자 관심종목 (항상 포함)
        + 자동 발굴 종목 (discovery_enabled 시)
        + 현재 보유 종목 (매도 신호 감지를 위해 반드시 포함)

        Returns:
            중복 제거된 종목 리스트 (최대 max_total_watchlist개)
        """
        from utils.market import is_us_stock, is_kr_stock

        # 1. 사용자 관심종목 (기본)
        user_list = self._load_user_watchlist(market.lower()) or default_list
        merged = list(user_list)  # 복사

        # 2. 자동 발굴 종목 추가
        if self._discovery_config.enabled:
            discovered = self._discovered_us if market == "US" else self._discovered_kr
            for sym in discovered:
                if sym not in merged:
                    merged.append(sym)

        # 3. 현재 보유 종목 추가 (매도 누락 방지)
        # 보유 중인데 워치리스트에 없으면 SELL 신호를 받을 수 없음
        try:
            positions = self.executor.get_positions()
            for pos in positions:
                sym = pos.symbol
                if sym not in merged:
                    is_target = (
                        (market == "US" and is_us_stock(sym)) or
                        (market == "KR" and is_kr_stock(sym))
                    )
                    if is_target:
                        merged.append(sym)
                        self.logger.debug(f"[워치리스트] 보유종목 추가: {sym}")
        except Exception as e:
            self.logger.debug(f"보유종목 워치리스트 추가 실패: {e}")

        # 4. 최대 크기 제한
        max_size = self._discovery_config.max_total_watchlist
        if len(merged) > max_size:
            # 사용자 종목 + 보유 종목은 유지, 발굴 종목에서 자름
            merged = merged[:max_size]

        return merged

    def _run_discovery(self):
        """
        종목 자동 발굴 실행

        섹터 유니버스(~100종목) + 시장 거래량 상위종목을 빠르게 스크리닝하여
        유망 종목을 찾아 _discovered_us / _discovered_kr에 저장합니다.

        빠른 기술적 스크리닝만 사용 (뉴스/팩터 분석은 정기 분석에서 수행)
        """
        if not self._discovery_config.enabled:
            return

        self.logger.info("[발굴] ═══ 종목 자동 발굴 시작 ═══")
        start_time = time.time()

        from config.settings import SECTOR_UNIVERSE, TechnicalConfig
        from collectors.scanner import MarketScanner
        from utils.market import detect_market, is_us_stock, is_kr_stock

        scanner = MarketScanner()
        analyzer = TechnicalAnalyzer(TechnicalConfig())

        # ── 1. 스캔 대상 종목 수집 ──
        # 사용자 관심 섹터의 종목 + 선택적으로 시장 상위 종목
        scan_targets = set()

        # 1a. 섹터 유니버스에서 수집
        user_sectors = self._load_user_interest_sectors()
        if user_sectors:
            for sector_key in user_sectors:
                sector = SECTOR_UNIVERSE.get(sector_key, {})
                for sym in sector.get("stocks", []):
                    scan_targets.add(sym)
        else:
            # 관심 섹터 미설정 시 전체 유니버스 스캔
            for sector in SECTOR_UNIVERSE.values():
                for sym in sector.get("stocks", []):
                    scan_targets.add(sym)

        # 1b. 시장 거래량 상위 종목 (선택)
        if self._discovery_config.include_market_movers:
            movers = self._fetch_market_movers()
            scan_targets.update(movers)

        # 기존 사용자 워치리스트 제외 (이미 분석 대상)
        from config.settings import US_WATCHLIST, KR_WATCHLIST
        user_us = set(self._load_user_watchlist("us") or US_WATCHLIST)
        user_kr = set(self._load_user_watchlist("kr") or KR_WATCHLIST)
        scan_targets -= user_us
        scan_targets -= user_kr

        self.logger.info(f"[발굴] 스캔 대상: {len(scan_targets)}개 종목")

        # ── 2. 빠른 기술적 스크리닝 ──
        us_candidates = []
        kr_candidates = []
        scanned = 0
        failed = 0

        for symbol in scan_targets:
            try:
                market = detect_market(symbol)
                if market == "KR":
                    collector = PriceCollectorKR()
                else:
                    collector = PriceCollectorUS()

                df = collector.safe_collect(symbol, period="3mo")
                if df is None or df.empty or len(df) < 20:
                    failed += 1
                    continue

                # 기술적 지표 계산 + 스캐너 스크리닝
                df_analyzed = analyzer.calculate_all(df)
                scan_result = scanner.scan_symbol(symbol, df_analyzed)
                scanned += 1

                # 최소 우선순위 필터
                if scan_result.priority >= self._discovery_config.min_priority_score:
                    entry = {
                        "symbol": symbol,
                        "priority": scan_result.priority,
                        "signals": scan_result.signals[:3],  # 상위 3개 신호
                        "price": scan_result.latest_price,
                        "change_pct": scan_result.change_pct,
                    }
                    if market == "US":
                        us_candidates.append(entry)
                    else:
                        kr_candidates.append(entry)

            except Exception as e:
                self.logger.debug(f"[발굴] {symbol} 스크리닝 실패: {e}")
                failed += 1
                continue

        # ── 3. 우선순위 정렬 → 상위 N개 선택 ──
        max_per_market = self._discovery_config.max_discovered_per_market

        us_candidates.sort(key=lambda x: x["priority"], reverse=True)
        kr_candidates.sort(key=lambda x: x["priority"], reverse=True)

        self._discovered_us = [c["symbol"] for c in us_candidates[:max_per_market]]
        self._discovered_kr = [c["symbol"] for c in kr_candidates[:max_per_market]]

        # 새로 발굴된 종목의 HOLD 카운터 초기화
        all_discovered = set(self._discovered_us + self._discovered_kr)
        for sym in list(self._discovery_hold_counts.keys()):
            if sym not in all_discovered:
                del self._discovery_hold_counts[sym]
        for sym in all_discovered:
            if sym not in self._discovery_hold_counts:
                self._discovery_hold_counts[sym] = 0

        # ── 4. DB에 저장 (봇 재시작 시 복원용) ──
        self._save_discovered_to_db()

        elapsed = time.time() - start_time
        self.logger.info(
            f"[발굴] ═══ 발굴 완료 ({elapsed:.0f}초) ═══\n"
            f"  스캔: {scanned}개 성공 / {failed}개 실패\n"
            f"  발굴 US: {len(self._discovered_us)}개 {self._discovered_us[:5]}\n"
            f"  발굴 KR: {len(self._discovered_kr)}개 {self._discovered_kr[:5]}"
        )

        # 발굴 결과 상세 로그
        for c in us_candidates[:max_per_market]:
            self.logger.info(
                f"  [US] {c['symbol']}: 우선순위 {c['priority']:.1f} "
                f"({', '.join(c['signals'][:2])})"
            )
        for c in kr_candidates[:max_per_market]:
            self.logger.info(
                f"  [KR] {c['symbol']}: 우선순위 {c['priority']:.1f} "
                f"({', '.join(c['signals'][:2])})"
            )

    def _rotate_discovered(self, market: str):
        """
        자동 발굴 종목 순환 — 연속 HOLD 종목 자동 제거

        정기 분석 결과를 기반으로, 연속으로 HOLD 판정된 종목은
        발굴 리스트에서 제거하여 새 종목에 자리를 양보합니다.
        """
        if not self._discovery_config.enabled:
            return

        discovered = self._discovered_us if market == "US" else self._discovered_kr
        if not discovered:
            return

        limit = self._discovery_config.rotation_hold_limit
        removed = []

        for sym in list(discovered):
            # DB에서 최근 신호 조회
            try:
                cursor = self.db.conn.execute(
                    "SELECT signal_type FROM signals WHERE symbol = ? "
                    "ORDER BY timestamp DESC LIMIT ?",
                    (sym, limit)
                )
                recent_signals = [row["signal_type"] for row in cursor.fetchall()]

                # 최근 N개가 전부 HOLD면 제거
                if len(recent_signals) >= limit and all(s == "HOLD" for s in recent_signals):
                    discovered.remove(sym)
                    self._discovery_hold_counts.pop(sym, None)
                    removed.append(sym)
            except Exception:
                pass

        if removed:
            self.logger.info(
                f"[발굴 순환] {market} 연속 HOLD 제거: {removed}"
            )
            self._save_discovered_to_db()

    def _fetch_market_movers(self) -> set:
        """
        시장 거래량 상위 종목 조회

        한국: pykrx에서 KOSPI/KOSDAQ 거래량 상위 N개
        미국: 사전 정의된 확장 유니버스에서 선택
        """
        movers = set()
        count = self._discovery_config.market_movers_count

        # ── 한국: pykrx 거래량 상위 ──
        try:
            from pykrx import stock as pykrx_stock
            from datetime import datetime as _dt
            today_str = _dt.now().strftime("%Y%m%d")

            for mkt in ("KOSPI", "KOSDAQ"):
                try:
                    df = pykrx_stock.get_market_ohlcv_by_ticker(today_str, market=mkt)
                    if df is not None and not df.empty and "거래량" in df.columns:
                        # 거래량 상위 N개
                        top = df.nlargest(count, "거래량")
                        suffix = ".KS" if mkt == "KOSPI" else ".KQ"
                        for ticker in top.index:
                            movers.add(f"{ticker}{suffix}")
                except Exception as e:
                    self.logger.debug(f"[발굴] pykrx {mkt} 상위종목 실패: {e}")
        except ImportError:
            self.logger.debug("[발굴] pykrx 미설치 → 한국 상위종목 스킵")

        # ── 미국: 확장 유니버스 (S&P 500 주요 대형주) ──
        # yfinance에는 "전체 종목 거래량 순위" API가 없으므로
        # 주요 대형주 중 섹터 유니버스에 없는 종목을 추가 스캔 대상으로
        _US_EXPANDED = [
            "PANW", "NOW", "SHOP", "XYZ", "UBER", "ABNB", "DDOG", "ZS",
            "CRWD", "NET", "FTNT", "MELI", "SE", "SNAP", "PINS",
            "ROKU", "TTD", "BILL", "HUBS", "TWLO", "OKTA", "ZM",
            "DASH", "RBLX", "U", "HOOD", "SOFI", "AFRM", "UPST",
            "CELH", "AXON", "DECK", "ON", "GFS", "WOLF",
        ]
        movers.update(_US_EXPANDED[:count])

        self.logger.debug(f"[발굴] 시장 상위종목: {len(movers)}개 수집")
        return movers

    def _load_user_interest_sectors(self) -> list:
        """대시보드 설정에서 사용자 관심 섹터 로드"""
        import json as _json
        settings_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "config", "user_settings.json"
        )
        try:
            if os.path.exists(settings_path):
                with open(settings_path, "r", encoding="utf-8") as f:
                    settings = _json.load(f)
                return settings.get("interest_sectors", [])
        except Exception:
            pass
        return []

    def _save_discovered_to_db(self):
        """발굴 결과를 DB 캐시에 저장 (봇 재시작 시 복원용)"""
        try:
            import json as _json
            data = {
                "us": self._discovered_us,
                "kr": self._discovered_kr,
                "hold_counts": self._discovery_hold_counts,
                "updated_at": datetime.now().isoformat(),
            }
            self.db.set_cache("discovery_results", data, ttl=86400)  # 24시간
        except Exception as e:
            self.logger.debug(f"[발굴] DB 저장 실패: {e}")

    def _load_discovered_from_db(self):
        """DB에서 이전 발굴 결과 복원"""
        try:
            data = self.db.get_cache("discovery_results")
            if data:
                self._discovered_us = data.get("us", [])
                self._discovered_kr = data.get("kr", [])
                self._discovery_hold_counts = data.get("hold_counts", {})
                self.logger.info(
                    f"[발굴] DB에서 복원: US {len(self._discovered_us)}개, "
                    f"KR {len(self._discovered_kr)}개"
                )
        except Exception as e:
            self.logger.debug(f"[발굴] DB 복원 실패: {e}")

    def get_discovery_status(self) -> dict:
        """발굴 시스템 현재 상태 (대시보드 API용)"""
        return {
            "enabled": self._discovery_config.enabled,
            "discovered_us": self._discovered_us,
            "discovered_kr": self._discovered_kr,
            "total_discovered": len(self._discovered_us) + len(self._discovered_kr),
            "cycle_count": self._discovery_cycle_count,
            "cycle_multiplier": self._discovery_config.cycle_multiplier,
            "next_discovery_in": max(0, self._discovery_config.cycle_multiplier - (self._discovery_cycle_count % self._discovery_config.cycle_multiplier)),
            "hold_counts": self._discovery_hold_counts,
            "config": {
                "max_per_market": self._discovery_config.max_discovered_per_market,
                "max_watchlist": self._discovery_config.max_total_watchlist,
                "min_priority": self._discovery_config.min_priority_score,
                "include_movers": self._discovery_config.include_market_movers,
                "rotation_limit": self._discovery_config.rotation_hold_limit,
            }
        }

    def _run_analysis(self, watchlist: list, market: str):
        """
        감시 종목 분석 + 신호에 따른 주문

        [v2.0] 앙상블 통합 분석:
        1. 기술적 분석 → ModuleScore (technical)
        2. 뉴스 감성 분석 → ModuleScore (sentiment)
        3. ensemble.combine() → 최종 BUY/SELL/HOLD

        [v2.2] 시장 영업시간 체크 + 매도 쿨다운:
        - 장 마감 중에는 분석만 하고 매매 실행은 건너뜀
        - 매도 후 1시간 쿨다운 동안 같은 종목 재매수 차단
        """
        from strategy.ensemble import ModuleScore
        from collectors.news import NewsCollector
        from strategy.factor import FactorAnalyzer

        # ── 시장 영업시간 체크 ──
        # 장 마감 중에 분석은 하되, 매매 실행은 건너뛰어 무의미한 거래 방지
        market_open = self._is_market_open(market)
        if not market_open:
            self.logger.info(
                f"[{market}] 장 마감 중 → 분석만 실행, 매매 주문은 건너뜀 "
                f"(수수료 낭비 방지)"
            )

        # ── 적응형 임계값 갱신 (분석 사이클당 1회) ──
        # VIX/시장체제에 따라 매수 임계값/신뢰도/포지션 크기 자동 조정
        try:
            self._current_thresholds = self.adaptive_thresholds.compute()
            self.logger.info(f"[적응형 임계값] {self._current_thresholds.detail}")
        except Exception as e:
            self.logger.debug(f"[적응형 임계값] 계산 실패 (기본값 유지): {e}")
            self._current_thresholds = None

        news_collector = NewsCollector()
        factor_analyzer = FactorAnalyzer()
        results = []

        # [FIX] Collector를 루프 밖에서 1회만 생성 (매 종목마다 생성하면 낭비)
        collector_us = PriceCollectorUS()
        collector_kr = PriceCollectorKR()

        skipped = 0  # 데이터 수집 실패한 종목 수 추적

        for symbol in watchlist:
            try:
                # ── 1. 가격 데이터 수집 ──
                collector = collector_us if market == "US" else collector_kr

                df = collector.safe_collect(symbol, period="6mo")
                if df is None or df.empty:
                    self.logger.warning(
                        f"[{market}] {symbol} 데이터 수집 실패 → 건너뜀"
                    )
                    skipped += 1
                    continue

                # ── 2. 기술적 분석 → ModuleScore ──
                df_analyzed = self.analyzer.calculate_all(df)
                tech_signal = self.analyzer.generate_signal(df_analyzed)

                # 기술적 분석 점수를 -1~+1 범위로 변환
                # BUY: +strength, SELL: -strength, HOLD: 0
                if tech_signal.signal == "BUY":
                    tech_score = tech_signal.strength
                elif tech_signal.signal == "SELL":
                    tech_score = -tech_signal.strength
                else:
                    tech_score = 0.0

                module_scores = [
                    ModuleScore(
                        name="technical",
                        score=tech_score,
                        confidence=min(tech_signal.strength + 0.3, 1.0),
                        reasons=tech_signal.reasons
                    )
                ]

                # ── 3. 팩터 분석 → ModuleScore ──
                try:
                    factor_scores = factor_analyzer.analyze(symbol, df=df_analyzed)
                    if abs(factor_scores.combined) > 0.01:
                        module_scores.append(
                            ModuleScore(
                                name="factor",
                                score=factor_scores.combined,
                                confidence=0.7,
                                reasons=factor_scores.reasons
                            )
                        )
                except Exception as e:
                    self.logger.debug(f"팩터 분석 실패 ({symbol}): {e}")

                # ── 4. 뉴스 감성 분석 → ModuleScore ──
                try:
                    sentiment = news_collector.get_sentiment_summary(symbol)
                    avg_sent = sentiment.get("avg_sentiment", 0.0)
                    news_count = sentiment.get("news_count", 0)

                    # 뉴스가 있을 때만 감성 모듈 추가
                    # 신뢰도: 뉴스 수가 많을수록 높음 (최소 3개는 있어야 의미)
                    if news_count > 0:
                        sent_confidence = min(news_count / 10, 1.0)
                        sent_reasons = []
                        if avg_sent > 0.2:
                            sent_reasons.append(f"뉴스 긍정적 ({avg_sent:.2f})")
                        elif avg_sent < -0.2:
                            sent_reasons.append(f"뉴스 부정적 ({avg_sent:.2f})")
                        else:
                            sent_reasons.append(f"뉴스 중립 ({avg_sent:.2f})")

                        module_scores.append(
                            ModuleScore(
                                name="sentiment",
                                score=avg_sent,  # -1~+1
                                confidence=sent_confidence,
                                reasons=sent_reasons
                            )
                        )
                except Exception as e:
                    self.logger.debug(f"뉴스 감성 수집 실패 ({symbol}): {e}")

                # ── 5. 앙상블 결합 ──
                ensemble_signal = self.ensemble.combine(module_scores)

                # 신호 로그 DB 저장 (앙상블 결과)
                # [안전장치] DB 저장 실패해도 매매 실행은 계속 진행
                # DB가 손상되면 log_signal에서 exception이 발생하는데,
                # 이것이 매매 실행까지 차단하면 안 되므로 별도 try-except 처리
                try:
                    self.db.log_signal(
                        symbol=symbol,
                        signal_type=ensemble_signal.action,
                        confidence=ensemble_signal.confidence,
                        score=ensemble_signal.score,
                        components=ensemble_signal.components,
                        reasons=ensemble_signal.reasons
                    )
                except Exception as db_err:
                    self.logger.warning(
                        f"[DB] 신호 로그 저장 실패 ({symbol}): {db_err} "
                        f"→ 매매 실행은 계속 진행"
                    )

                results.append({
                    "symbol": symbol,
                    "signal": ensemble_signal.action,
                    "strength": abs(ensemble_signal.score),
                    "reasons": ensemble_signal.reasons,
                    "price": float(df_analyzed["Close"].iloc[-1]),
                    "atr": float(df_analyzed["ATR"].iloc[-1]) if "ATR" in df_analyzed.columns else 0,
                    "status": "success",
                    "components": ensemble_signal.components,
                })

                # ── 6. 매매 신호 시 처리 ──
                # 상세 로그: 각 종목의 앙상블 판단 과정을 투명하게 기록
                # → 매매가 왜 안 되는지 사용자가 파악할 수 있도록
                self.logger.info(
                    f"[신호] {symbol}: {ensemble_signal.action} "
                    f"(점수={ensemble_signal.score:+.3f}, "
                    f"신뢰도={ensemble_signal.confidence:.2f}, "
                    f"임계값=±0.2) "
                    f"{'→ 매수 시도!' if ensemble_signal.action == 'BUY' and ensemble_signal.confidence > (0.03 if self.executor.paper else 0.15) else ''}"
                    f"{'→ 매도 시도!' if ensemble_signal.action == 'SELL' else ''}"
                    f"{'→ HOLD (관망)' if ensemble_signal.action == 'HOLD' else ''}"
                )
                # 모듈별 기여도도 디버그 로그로 기록
                for comp_name, comp_val in ensemble_signal.components.items():
                    self.logger.debug(f"  └ {comp_name}: {comp_val:+.3f}")

                # ── ★ ExitManager 자동 청산 체크 (앙상블 신호 이전) ──
                # 보유 종목이라면 손절/익절/트레일링 스탑을 우선 체크
                # 청산 조건 발동 시 즉시 매도하고 다음 종목으로
                if market_open:
                    current_price = float(df_analyzed["Close"].iloc[-1])
                    exit_decision = self.exit_manager.evaluate(symbol, current_price)
                    if exit_decision.should_exit:
                        # ExitManager 상태 업데이트 (트레일링 갱신 등)
                        self._save_exit_state(symbol)
                        self.logger.info(
                            f"[자동 청산] {symbol}: {exit_decision.reason.value} | "
                            f"{exit_decision.detail}"
                        )
                        if exit_decision.sell_ratio >= 1.0:
                            # 전량 매도
                            self._execute_sell(
                                symbol, exit_reason=exit_decision.reason.value
                            )
                        else:
                            # 분할 매도
                            self._execute_partial_sell(
                                symbol,
                                ratio=exit_decision.sell_ratio,
                                exit_reason=exit_decision.reason.value,
                            )
                        # 청산 처리 후 이번 사이클은 더 이상 신호 처리 안 함
                        continue

                # ── 매수/매도 실행 조건 ──
                # [v2.2] 장 마감 중에는 매매 실행을 건너뜀
                if not market_open:
                    if ensemble_signal.action in ("BUY", "SELL"):
                        self.logger.info(
                            f"[{market} 장외] {symbol}: {ensemble_signal.action} "
                            f"신호 감지 → 장 마감 중이므로 매매 보류"
                        )
                    # 분석 결과는 기록하되, 매매는 실행하지 않음
                elif ensemble_signal.action == "BUY":
                    # ── 적응형 임계값 적용 ──
                    # VIX/시장체제에 따라 매수 임계값 + 신뢰도 + 포지션 크기 조절
                    if self._current_thresholds is None:
                        self._current_thresholds = self.adaptive_thresholds.compute()
                    th = self._current_thresholds
                    min_confidence = th.min_confidence

                    # 위기장(VIX>30) + Bear장에서는 매수 차단 가능
                    if th.regime_volatility == "crisis" and th.regime_market == "bear":
                        self.logger.warning(
                            f"[적응형] {symbol}: {th.detail} → 매수 차단 (위기+약세)"
                        )
                        continue

                    if ensemble_signal.confidence > min_confidence:
                        # [v2.2] 매도 쿨다운 체크
                        if self._is_in_cooldown(symbol):
                            self.logger.info(
                                f"[쿨다운] {symbol}: 최근 매도 후 재매수 대기 중 → 건너뜀"
                            )
                        else:
                            self._execute_buy(symbol, df_analyzed, tech_signal,
                                              ensemble_signal, module_scores,
                                              size_multiplier=th.position_size_multiplier)
                elif ensemble_signal.action == "SELL":
                    self._execute_sell(symbol)

            except Exception as e:
                self.logger.error(f"분석 오류 ({symbol}): {e}")

        # ── 분석 결과 요약 로그 ──
        total = len(watchlist)
        analyzed = len(results)
        self.logger.info(
            f"[{market}] 분석 완료: {analyzed}/{total}개 성공, "
            f"{skipped}개 데이터 실패"
        )

        # 전체 실패 시 경고 (데이터 소스 문제일 가능성 높음)
        if analyzed == 0 and total > 0:
            self.logger.error(
                f"[{market}] ⚠️ 모든 종목 분석 실패! "
                f"데이터 소스(pykrx/yfinance) 상태를 확인하세요."
            )

        # 일일 리포트 전송
        if results:
            self.notifier.send_daily_report(results)

    def _execute_buy(self, symbol: str, df, signal,
                     ensemble_signal=None, module_scores=None,
                     size_multiplier: float = 1.0):
        """
        매수 실행 (안전장치 체크 + 포지션 유형 분류 포함)

        Parameters:
            size_multiplier: 포지션 크기 배수 (적응형 임계값에서 0.5~1.0 전달)
                             변동성이 높으면 1.0 미만으로 포지션 축소
        """
        # ── 이미 보유 중인 종목이면 추가 매수 건너뛰기 ──
        # 같은 종목을 반복 매수하면 포지션이 무한 누적됩니다.
        # 추후 "피라미딩(추가 매수)" 전략이 필요하면 이 로직을 수정하세요.
        existing_positions = self.executor.get_positions()
        for pos in existing_positions:
            if pos.symbol == symbol:
                self.logger.info(
                    f"[매수 스킵] {symbol}: 이미 {pos.quantity}주 보유 중 "
                    f"(평균가 {pos.avg_price:,.0f})"
                )
                return

        # ★ float() 변환: pandas/numpy int64/float64 → Python native
        # JSON 직렬화 실패 + 타입 에러 방지 (WebSocket 브로드캐스트용)
        price = float(df["Close"].iloc[-1])
        atr = float(df["ATR"].iloc[-1]) if "ATR" in df.columns else price * 0.02

        self.logger.info(
            f"[매수 시도] {symbol}: 현재가={price:,.0f}, ATR={atr:,.0f}, "
            f"신호강도={signal.strength:.2f}"
        )

        # 포지션 사이징
        pos_size = self.position_sizer.calculate(
            price=price,
            atr=atr,
            method=self.settings.risk.sizing_method,
            confidence=signal.strength,
            symbol=symbol,  # ★ 환율 변환: USD 종목이면 KRW 환산 후 사이징
        )

        # ── 적응형 사이즈 배수 적용 ──
        # 변동성 高 / Bear 체제 시 0.5~0.7로 축소
        if size_multiplier < 1.0 and pos_size.shares > 0:
            original_shares = pos_size.shares
            pos_size.shares = max(1, int(pos_size.shares * size_multiplier))
            pos_size.value = pos_size.shares * price
            self.logger.info(
                f"[적응형] {symbol}: 포지션 축소 "
                f"{original_shares}주 → {pos_size.shares}주 "
                f"(배수 {size_multiplier:.2f})"
            )

        if pos_size.shares <= 0:
            self.logger.warning(
                f"[매수 취소] {symbol}: 포지션 사이징 결과 0주 "
                f"(가격={price:,.0f}, ATR={atr:,.0f})"
            )
            return

        self.logger.info(
            f"[포지션 사이징] {symbol}: {pos_size.shares}주 × {price:,.0f} = "
            f"{pos_size.shares * price:,.0f}"
        )

        # ── 안전장치 체크 (SafetyGuard) ──
        # ★ 핵심: check_order()는 이제 (bool, str, int) 3개 값을 반환
        # - 한도 초과 시 수량을 자동으로 줄여서라도 매수 진행
        # - 수량 조정으로도 해결 불가능한 경우에만 거부 (킬 스위치, 일일 손실 등)
        account = self.executor.get_account()
        positions = self.executor.get_positions()
        safe, reason, adjusted_shares = self.safety.check_order(
            symbol=symbol,
            side="BUY",
            quantity=pos_size.shares,
            price=price,
            account_equity=account.total_equity,
            positions=positions,
        )
        if not safe:
            self.logger.warning(f"[매수 거부] {symbol}: {reason}")
            self.notifier.send_risk_alert(f"⚠️ 매수 거부: {symbol}\n{reason}")
            return

        # ★ SafetyGuard가 수량을 조정했으면 반영
        if adjusted_shares != pos_size.shares:
            self.logger.info(
                f"[수량 조정] {symbol}: {pos_size.shares}주 → {adjusted_shares}주 "
                f"(SafetyGuard 한도 적용)"
            )
            pos_size.shares = adjusted_shares
            pos_size.value = adjusted_shares * price
            pos_size.pct_of_capital = pos_size.value / account.total_equity

        # ── 실거래 시 대기 (취소 기회) ──
        self.safety.wait_before_order()

        # 모의매매기에 현재가 설정
        if hasattr(self.executor, 'set_current_price'):
            self.executor.set_current_price(symbol, price)

        # 주문 실행
        order = self.executor.buy_market(symbol, pos_size.shares, strategy="ensemble")

        if order.status.value == "filled":
            self.logger.info(
                f"[매수 체결] {symbol} {pos_size.shares}주 @ {price:.2f}"
            )
            # 알림 금액은 KRW 기준 (USD 종목이면 환산)
            total_krw = to_krw(symbol, pos_size.shares * price)
            self.notifier.send_trade_executed(symbol, "BUY", pos_size.shares, price, total_krw)
            self.discord.send_trade_executed(symbol, "BUY", pos_size.shares, price, total_krw)
            # DB 저장은 paper_executor._execute_order() 내부에서 이미 처리됨
            # 안전장치에 거래 기록
            self.safety.record_trade(symbol, "BUY", value=total_krw)

            # ── 포지션 유형 분류 + 목표가/손절가 계산 ──
            try:
                from strategy.ensemble import classify_position_type
                import json as _json

                pos_info = {"position_type": "스윙", "position_type_en": "swing",
                            "holding_period": "1~4주", "atr_stop_multiplier": 2.0,
                            "rr_ratio": 2.0, "classification_reason": "기본값"}
                reasons_list = []

                if ensemble_signal and module_scores:
                    pos_info = classify_position_type(module_scores, ensemble_signal)
                    reasons_list = ensemble_signal.reasons[:5]

                # 유형별 목표가/손절가 계산
                type_atr_mult = pos_info["atr_stop_multiplier"]
                type_rr = pos_info["rr_ratio"]
                stop_price = price - (atr * type_atr_mult)
                target_price = price + (atr * type_atr_mult * type_rr)

                self.logger.info(
                    f"[포지션 유형] {symbol}: {pos_info['position_type']} "
                    f"({pos_info['holding_period']}) | "
                    f"목표 {target_price:,.0f} / 손절 {stop_price:,.0f} | "
                    f"분류근거: {pos_info['classification_reason']}"
                )

                # DB에 포지션 메타데이터 저장
                # [FIX] self.db를 사용 (별도 연결 생성 -> 기존 연결 재사용)
                if self.db:
                    self.db.update_position(
                        symbol=symbol,
                        quantity=pos_size.shares,
                        avg_price=price,
                        current_price=price,
                        position_type=pos_info["position_type"],
                        position_type_en=pos_info["position_type_en"],
                        target_price=round(target_price, 2),
                        stop_price=round(stop_price, 2),
                        reasons_json=_json.dumps(reasons_list, ensure_ascii=False),
                        holding_period=pos_info["holding_period"],
                        bought_at=__import__("datetime").datetime.now().isoformat(),
                    )

                # ── ExitManager에 진입 등록 (자동 청산용) ──
                # 이후 매 분석 사이클에서 _check_exit_conditions()가
                # 손절/익절/트레일링 스탑을 자동 체크합니다.
                holding_days_max = {"단타": 5, "스윙": 30, "장기": 180}.get(
                    pos_info["position_type"], 30
                )
                self.exit_manager.register_entry(
                    symbol=symbol,
                    entry_price=price,
                    atr=atr,
                    atr_stop_mult=type_atr_mult,
                    rr_ratio=type_rr,
                    holding_days_max=holding_days_max,
                )
                self._save_exit_state(symbol)  # DB 동기화
            except Exception as e:
                self.logger.warning(
                    f"[포지션 유형] {symbol}: 분류/저장 실패 (매수 자체는 성공): {e}"
                )

    def _execute_sell(self, symbol: str, exit_reason: str = "signal_sell"):
        """
        매도 실행 (보유 시, 안전장치 체크 포함)

        Parameters:
            symbol: 종목 코드
            exit_reason: 청산 사유 ("signal_sell", "stop_loss", "take_profit_2",
                         "trailing_stop", "time_stop")
        """
        # 보유하지 않은 종목이면 스킵
        existing_positions = self.executor.get_positions()
        held = None
        for pos in existing_positions:
            if pos.symbol == symbol and pos.quantity > 0:
                held = pos
                break
        if not held:
            self.logger.debug(f"[매도 스킵] {symbol}: 미보유")
            return

        # 매도도 안전장치 기본 체크 (킬스위치, 일일 횟수 등)
        account = self.executor.get_account()
        safe, reason, _ = self.safety.check_order(
            symbol=symbol,
            side="SELL",
            quantity=held.quantity,
            price=held.current_price,
            account_equity=account.total_equity,
            positions=existing_positions,
        )
        if not safe:
            self.logger.warning(f"[매도 거부] {symbol}: {reason}")
            return

        # 모의매매기에 현재가 설정 (최신 가격으로 매도)
        if hasattr(self.executor, 'set_current_price'):
            self.executor.set_current_price(symbol, held.current_price)

        order = self.executor.close_position(symbol, strategy=exit_reason)
        if order and order.status.value == "filled":
            price = order.filled_price
            # 알림 금액은 KRW 기준 (USD 종목이면 환산)
            total_krw = to_krw(symbol, held.quantity * price)
            self.logger.info(
                f"[매도 체결] {symbol} {held.quantity}주 @ {price:,.2f} 전량 청산 "
                f"({exit_reason})"
            )
            self.notifier.send_trade_executed(symbol, "SELL", held.quantity, price, total_krw)
            self.discord.send_trade_executed(symbol, "SELL", held.quantity, price, total_krw)
            # DB 저장은 paper_executor._execute_order() 내부에서 이미 처리됨
            self.safety.record_trade(symbol, "SELL", value=total_krw)

            # ── ExitManager 상태 정리 (전량 청산이므로 등록 해제) ──
            self.exit_manager.unregister(symbol)

            # ── [v2.2] 매도 쿨다운 등록 (반복매매 방지) ──
            # 매도 직후 같은 종목을 재매수하면 수수료만 먹는 무의미한 거래
            # 일정 시간(기본 1시간) 동안 해당 종목 재매수를 차단
            self._sell_cooldowns[symbol] = time.time()
            self.logger.info(
                f"[쿨다운] {symbol}: 매도 후 {self._cooldown_seconds // 60}분 "
                f"재매수 쿨다운 시작"
            )

    def _execute_partial_sell(
        self, symbol: str, ratio: float, exit_reason: str = "take_profit_1"
    ):
        """
        분할 매도 실행 (1차 익절 등)

        전량 매도(_execute_sell)와 달리:
        - 일부만 매도 → ExitManager 상태 유지 (등록 해제 안 함)
        - 쿨다운 등록 안 함 (잔여 포지션 추가 매수 가능)

        Parameters:
            symbol: 종목 코드
            ratio: 매도 비중 (0.5 = 50%)
            exit_reason: 청산 사유
        """
        existing_positions = self.executor.get_positions()
        held = None
        for pos in existing_positions:
            if pos.symbol == symbol and pos.quantity > 0:
                held = pos
                break
        if not held:
            return

        # 안전장치 체크
        account = self.executor.get_account()
        safe, reason, _ = self.safety.check_order(
            symbol=symbol,
            side="SELL",
            quantity=int(held.quantity * ratio),
            price=held.current_price,
            account_equity=account.total_equity,
            positions=existing_positions,
        )
        if not safe:
            self.logger.warning(f"[부분 매도 거부] {symbol}: {reason}")
            return

        if hasattr(self.executor, 'set_current_price'):
            self.executor.set_current_price(symbol, held.current_price)

        order = self.executor.close_partial(symbol, ratio=ratio, strategy=exit_reason)
        if order and order.status.value == "filled":
            sold_qty = order.quantity
            price = order.filled_price
            total_krw = to_krw(symbol, sold_qty * price)
            self.logger.info(
                f"[부분 매도] {symbol} {sold_qty}주 @ {price:,.2f} "
                f"(전체의 {ratio*100:.0f}%, {exit_reason})"
            )
            self.notifier.send_trade_executed(symbol, "SELL", sold_qty, price, total_krw)
            self.discord.send_trade_executed(symbol, "SELL", sold_qty, price, total_krw)
            self.safety.record_trade(symbol, "SELL", value=total_krw)
            # ExitManager 상태는 그대로 유지 (잔여 포지션 트레일링 계속)
            self._save_exit_state(symbol)

    def _check_risk(self):
        """리스크 모니터링 (30분마다)"""
        try:
            account = self.executor.get_account()
            positions = self.executor.get_positions()

            # MDD 체크
            if self.db:
                mdd = self.db.calculate_max_drawdown(days=30)
                if mdd > 0.15:  # MDD 15% 초과
                    msg = f"⚠️ MDD 경고: {mdd*100:.1f}% (한도: 15%)"
                    self.logger.warning(msg)
                    self.notifier.send_risk_alert(msg)
                    self.discord.send_risk_alert(msg)

            # 포지션별 손절 체크
            for pos in positions:
                if pos.unrealized_pnl_pct < -0.05:  # -5% 이하
                    msg = (f"⚠️ 손절 경고: {pos.symbol} "
                           f"{pos.unrealized_pnl_pct*100:.1f}%")
                    self.logger.warning(msg)

            # equity 스냅샷 저장 (5분마다)
            if self.db:
                pnl_pct = (account.total_equity / self.settings.capital.total_capital - 1)
                self.db.save_equity_snapshot(
                    total_equity=account.total_equity,
                    cash=account.cash,
                    positions_value=account.positions_value,
                    daily_pnl=account.daily_pnl,
                    cumulative_return=pnl_pct,
                )

        except Exception as e:
            self.logger.error(f"리스크 체크 오류: {e}")


def main():
    """CLI 진입점"""
    parser = argparse.ArgumentParser(description="퀀트봇 자동매매")
    parser.add_argument("--capital", type=float, default=10_000_000,
                        help="투자 자본금 (기본: 10,000,000)")
    parser.add_argument("--currency", default="KRW", choices=["KRW", "USD"],
                        help="통화 단위")
    parser.add_argument("--broker", default="paper",
                        choices=["paper", "alpaca", "kis", "dual"],
                        help="브로커 선택 (dual=KIS+Alpaca 동시 운용)")
    parser.add_argument("--live", action="store_true",
                        help="실거래 모드 (주의!)")
    parser.add_argument("--risk-per-trade", type=float, default=0.02,
                        help="1회 거래당 최대 리스크 비율")
    args = parser.parse_args()

    settings = Settings(
        capital=CapitalConfig(
            total_capital=args.capital,
            currency=args.currency
        ),
        risk=RiskConfig(
            risk_per_trade=args.risk_per_trade
        )
    )

    bot = QuantBot(settings=settings, broker=args.broker, live=args.live)

    # Ctrl+C 시그널 핸들러
    def signal_handler(sig, frame):
        print("\n종료 신호 수신...")
        bot.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    bot.start()


if __name__ == "__main__":
    main()
