# 18. 프로젝트 전체 구조도 v2 (2026-05-08 기준)

이번 세션 후 전체 프로젝트 구조 + 각 파일의 역할 정리.

---

## 디렉토리 트리

```
X:\QQQ\quant-bot\
│
├── 📄 run_bot.py                  # 봇 메인 진입점 (분석 + 매매 루프)
├── 📄 main.py                     # CLI 분석 도구 (단일 종목)
├── 📄 .env                        # 환경변수 (KIS 자격증명 등) ★깃 미커밋
├── 📄 .env.example                # .env 템플릿
├── 📄 .gitignore                  # 보안용 (data, reports, .env 제외)
├── 📄 requirements.txt
├── 📄 README.md
├── 📄 USER_GUIDE.md
├── 📄 CLAUDE.md                   # AI 협업 가이드
│
├── 📁 config/
│   ├── settings.py                # 모든 매직넘버 + 설정 중앙 관리
│   └── __init__.py
│
├── 📁 collectors/                 # 데이터 수집 계층
│   ├── price_kr.py                # 한국 주가 (pykrx)
│   ├── price_us.py                # 미국 주가 (yfinance)
│   ├── news.py                    # 뉴스 (Google RSS)
│   ├── macro.py                   # 거시경제 (FRED)
│   ├── dart.py                    # 한국 공시 (DART API)
│   ├── scanner.py                 # 종목 자동 발굴 (6가지 신호)
│   └── base.py
│
├── 📁 analyzers/                  # 분석 엔진
│   ├── technical.py               # 기술적 지표 (RSI, MACD, BB, ATR 등)
│   └── news_llm.py                # LLM 뉴스 영향도 분석 (옵션)
│
├── 📁 strategy/                   # 매매 전략
│   ├── ensemble.py                # 앙상블 (technical + factor + sentiment)
│   ├── factor.py                  # 팩터 분석 (Value, Quality)
│   ├── pair_trading.py            # 페어 트레이딩 (z-score 기반)
│   ├── optimizer.py               # 파라미터 최적화 (그리드 서치)
│   ├── adaptive_threshold.py      # ★신규 적응형 임계값 (VIX 기반)
│   ├── capital_allocator.py       # ★신규 다중 전략 자본 분할 (Risk Parity)
│   └── sector_rotation.py         # ★신규 섹터 로테이션 알파
│
├── 📁 risk/                       # 리스크 관리
│   ├── position_sizer.py          # 포지션 사이징 (Kelly, ATR, Fixed)
│   └── stop_loss.py               # (구버전 손절 로직, ExitManager로 대체됨)
│
├── 📁 executor/                   # 주문 실행 계층
│   ├── base.py                    # 추상 BaseExecutor + Order/Position 정의
│   ├── paper_executor.py          # 모의매매기 (DB 영속성)
│   ├── kis_executor.py            # 한국투자증권 KIS Open API
│   ├── alpaca_executor.py         # Alpaca (미국 무료 브로커)
│   ├── dual_executor.py           # KR=KIS, US=Alpaca 자동 라우팅
│   ├── exit_manager.py            # ★신규 손절/익절/트레일링 자동 청산
│   ├── safety_guard.py            # 실거래 안전장치 (한도, 킬스위치)
│   ├── transaction_cost.py        # ★신규 정교한 거래비용 모델
│   └── order_splitter.py          # 대량 주문 분할 매매 (VWAP)
│
├── 📁 backtest/                   # 백테스트 엔진
│   ├── engine.py                  # 벡터 기반 백테스트
│   └── metrics.py                 # 성과 지표 (Sharpe, MDD, Calmar)
│
├── 📁 reporter/                   # 보고서 생성
│   ├── daily_report.py            # 일일 보고서 (HTML)
│   ├── weekly_report.py           # 주간/월간 보고서
│   ├── market_report.py           # 시장 보고서
│   ├── market_briefing.py         # 일일 시장 브리핑
│   ├── benchmark.py               # ★신규 Buy-and-Hold 벤치마크 비교
│   └── html_report.py             # HTML 템플릿 헬퍼
│
├── 📁 notifier/                   # 알림
│   ├── discord_bot.py             # 디스코드 봇 (슬래시 명령어)
│   ├── discord_webhook.py         # 디스코드 웹후크 (단방향)
│   └── telegram_bot.py            # 텔레그램 봇
│
├── 📁 scheduler/
│   └── job_manager.py             # APScheduler 래퍼 (분석 주기 관리)
│
├── 📁 dashboard/                  # 웹 대시보드
│   ├── app.py                     # Flask + SocketIO 서버
│   ├── healthcheck.py             # 헬스체크 엔드포인트
│   ├── templates/
│   │   └── index.html             # 메인 UI
│   └── static/
│       ├── js/
│       │   └── main.js            # 프론트엔드 로직
│       └── css/
│           └── main.css
│
├── 📁 database/
│   └── cache.py                   # SQLite 매니저 (positions, trades, signals 등)
│
├── 📁 utils/
│   ├── logger.py                  # 로깅 설정
│   └── market.py                  # 시장 판별, 환율 변환 (to_krw 등)
│
├── 📁 tests/
│   ├── test_database.py           # DB 단위 테스트
│   ├── test_ensemble.py           # 앙상블 시그널 결합 테스트
│   ├── test_safety_guard.py       # 안전장치 테스트
│   ├── test_settings.py
│   ├── test_utils.py
│   ├── test_regression_bugs.py    # ★신규 회귀 테스트 (18개)
│   └── conftest.py                # pytest 픽스처
│
├── 📁 scripts/                    # 유틸 스크립트
│   ├── run_backtest.py            # ★신규 자동 백테스트 CLI
│   └── test_kis_connection.py     # ★신규 KIS 자격증명 검증
│
├── 📁 skill/                      # 학습 노트 (이 폴더)
│   ├── 00_INDEX.md
│   ├── 01_project_architecture.md
│   ├── 02_python_flask_websocket.md
│   ├── 03_quant_finance_concepts.md
│   ├── 04_data_collection_api.md
│   ├── 05_database_sqlite.md
│   ├── 06_debugging_problem_solving.md
│   ├── 07_frontend_ui_ux.md
│   ├── 08_error_handling_resilience.md
│   ├── 09_file_encoding_truncation.md
│   ├── 10_agent_ai_workflow.md
│   ├── 11_scheduler_timer.md
│   ├── 12_security_safety.md
│   ├── 13_position_management.md          # ★신규
│   ├── 14_strategy_validation.md          # ★신규
│   ├── 15_kis_realtime_integration.md     # ★신규
│   ├── 16_advanced_quant_models.md        # ★신규
│   ├── 17_session_log_2026_05_08.md       # ★신규
│   └── 18_project_structure_v2.md         # ★신규 (현재 문서)
│
├── 📁 data/                       # 런타임 (깃 미포함)
│   ├── quantbot.db                # 메인 DB
│   └── *.db                       # 백업/테스트 DB
│
├── 📁 reports/                    # 생성된 HTML 보고서 (깃 미포함)
│   ├── daily_*.html
│   ├── weekly_*.html
│   └── market_*.html
│
└── 📁 logs/                       # 로그 파일 (깃 미포함)
```

---

## 데이터 흐름도

```
┌────────────────────────────────────────────────────────────────┐
│                     사용자 (브라우저)                           │
│                  http://localhost:5000                          │
└───────────────────────────┬────────────────────────────────────┘
                            │ WebSocket
┌───────────────────────────▼────────────────────────────────────┐
│              Flask Dashboard (dashboard/app.py)                 │
│  - REST API + WebSocket emit                                    │
│  - 실시간 포지션/PnL 브로드캐스트 (2초 간격)                     │
│  - 1분마다 보유 포지션 가격 갱신 (KIS/yfinance)                 │
│  - 5분마다 equity 스냅샷 저장                                   │
└───────────────────────────┬────────────────────────────────────┘
                            │
                ┌───────────┴───────────┐
                │                        │
┌───────────────▼──────────┐  ┌─────────▼──────────────────────┐
│   QuantBot (run_bot.py)   │  │  Notifiers                     │
│  - 분석 사이클 실행        │  │  - Telegram                    │
│  - ExitManager 자동 청산   │  │  - Discord (Webhook + Bot)     │
│  - 적응형 임계값 적용      │  └────────────────────────────────┘
└──────┬─────────────┬──────┘
       │             │
       │             │
┌──────▼──┐    ┌─────▼─────────────────────┐
│Strategy │    │  Executor                  │
│         │    │  - PaperExecutor (모의)    │
│- Ensemble│   │  - KISExecutor (한국)      │
│- Factor │    │  - AlpacaExecutor (미국)   │
│- Adapt. │    │  - ExitManager (청산)      │
│- Capital│    │  - SafetyGuard (안전)      │
│  Alloc. │    │  - TransactionCost (비용)  │
│- Sector │    └────────┬───────────────────┘
│  Rotate │             │
└──────┬──┘             │
       │                │
┌──────▼────────────┐   │
│  Analyzers         │  │
│  - Technical       │  │
│  - News LLM        │  │
└──────┬─────────────┘  │
       │                │
┌──────▼────────────────▼──────────────────────────────────────┐
│  Collectors (데이터 수집)                                      │
│  - PriceCollectorKR (pykrx)                                    │
│  - PriceCollectorUS (yfinance)                                 │
│  - NewsCollector (Google RSS)                                  │
│  - MacroCollector (FRED)                                       │
│  - DARTCollector (한국 공시)                                   │
│  - Scanner (종목 자동 발굴)                                    │
└──────┬─────────────────────────────────────────────────────────┘
       │
┌──────▼─────────────────────────────────────────────────────────┐
│  Database (SQLite)                                              │
│  - cache (TTL 캐시)                                             │
│  - trades (거래 이력)                                           │
│  - positions (포지션 + ExitManager 상태)                        │
│  - signals (분석 신호)                                          │
│  - equity_history (시간별 자산 스냅샷)                          │
│  - portfolio_snapshots (일별 자산)                              │
└─────────────────────────────────────────────────────────────────┘
```

---

## 모듈별 역할 + 의존성

### 🟦 핵심 모듈 (의존성 없음)
- `config/settings.py` — 모든 설정값 중앙 관리
- `utils/market.py` — 시장 판별, 환율 변환
- `utils/logger.py` — 로깅 설정

### 🟩 데이터 계층
- `collectors/*` — 외부 API 호출
- `database/cache.py` — SQLite 영속성

### 🟨 분석 계층
- `analyzers/technical.py` — 기술적 지표 계산
- `strategy/factor.py` — 팩터 점수
- `strategy/pair_trading.py` — 페어 트레이딩

### 🟧 의사결정 계층
- `strategy/ensemble.py` — 종합 신호
- `strategy/adaptive_threshold.py` — VIX 기반 임계값 조정
- `strategy/sector_rotation.py` — 섹터 가중치 보정
- `strategy/capital_allocator.py` — 다중 전략 자본 할당

### 🟥 실행 계층
- `executor/base.py` — 추상 인터페이스
- `executor/paper_executor.py` — 모의매매기
- `executor/kis_executor.py` — 한국 실거래
- `executor/alpaca_executor.py` — 미국 실거래
- `executor/dual_executor.py` — 라우팅
- `executor/exit_manager.py` — 자동 청산
- `executor/safety_guard.py` — 안전장치
- `executor/transaction_cost.py` — 비용 모델

### 🟪 전체 통합
- `run_bot.py` — 모든 계층 조립
- `main.py` — CLI 단일 분석
- `dashboard/app.py` — 웹 인터페이스

### ⬜ 검증/보고
- `backtest/engine.py` — 백테스트
- `reporter/daily_report.py` — 일일 보고서
- `reporter/benchmark.py` — Buy-and-Hold 비교
- `tests/*` — 단위 + 회귀 테스트

---

## DB 스키마 (현재 v2)

### `cache`
```sql
key TEXT PRIMARY KEY
value TEXT NOT NULL
expires_at TEXT NOT NULL
created_at TEXT
```

### `trades`
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
timestamp TEXT NOT NULL
symbol TEXT NOT NULL
market TEXT DEFAULT 'US'
side TEXT NOT NULL                  -- "BUY" / "SELL" (대문자)
quantity INTEGER NOT NULL
price REAL NOT NULL                 -- native currency
total_value REAL NOT NULL           -- ★ KRW 환산 금액 (v2부터)
strategy TEXT DEFAULT ''
signal_score REAL DEFAULT 0
status TEXT DEFAULT 'filled'
order_id TEXT DEFAULT ''
notes TEXT DEFAULT ''
pnl REAL DEFAULT 0                  -- 매도 시 실현손익 (KRW)
position_type TEXT DEFAULT ''       -- 단타/스윙/장기
reasons_json TEXT DEFAULT '[]'
exit_reason TEXT DEFAULT ''         -- ★신규 stop_loss/take_profit_1 등
```

### `positions`
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
symbol TEXT NOT NULL UNIQUE
quantity INTEGER NOT NULL
avg_price REAL NOT NULL             -- native currency
current_price REAL DEFAULT 0
updated_at TEXT
position_type TEXT DEFAULT ''
position_type_en TEXT DEFAULT ''
target_price REAL DEFAULT 0         -- 목표가 (구버전 단일 목표)
stop_price REAL DEFAULT 0
reasons_json TEXT DEFAULT '[]'
holding_period TEXT DEFAULT ''
bought_at TEXT DEFAULT ''
-- ★ ExitManager 필드 (v2부터)
entry_atr REAL DEFAULT 0            -- 진입 시점 ATR
current_stop REAL DEFAULT 0         -- 현재 활성 손절선 (트레일링 갱신)
highest_since_entry REAL DEFAULT 0  -- 최고가 (Chandelier용)
partial_sold_pct REAL DEFAULT 0     -- 0/0.5/1.0
target_1 REAL DEFAULT 0             -- 1차 목표가
target_2 REAL DEFAULT 0             -- 2차 목표가
```

### `signals`
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
timestamp TEXT NOT NULL
symbol TEXT NOT NULL
signal_type TEXT NOT NULL           -- "BUY" / "SELL" / "HOLD"
confidence REAL DEFAULT 0
score REAL DEFAULT 0
components_json TEXT DEFAULT '{}'   -- 각 모듈 점수
reasons_json TEXT DEFAULT '[]'
acted_on INTEGER DEFAULT 0          -- 매매 실행 여부
```

### `equity_history` (시간별 자산 스냅샷)
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
timestamp TEXT NOT NULL
total_equity REAL NOT NULL          -- KRW
cash REAL NOT NULL                  -- KRW
positions_value REAL DEFAULT 0      -- KRW
daily_pnl REAL DEFAULT 0
cumulative_return REAL DEFAULT 0
```

### `portfolio_snapshots` (일별)
```sql
id INTEGER PRIMARY KEY AUTOINCREMENT
date TEXT NOT NULL UNIQUE
total_value REAL NOT NULL
cash REAL NOT NULL
positions_json TEXT DEFAULT '{}'
daily_return REAL DEFAULT 0
cumulative_return REAL DEFAULT 0
max_drawdown REAL DEFAULT 0
notes TEXT DEFAULT ''
```

---

## 실행 명령어 모음

### 일상 운영
```bash
# 봇 시작 (대시보드 포함)
python dashboard/app.py

# 단일 종목 분석
python main.py --symbol AAPL

# 백테스트 (전략 검증)
python scripts/run_backtest.py --symbol SPY --period 1y

# 회귀 테스트
pytest tests/test_regression_bugs.py -v

# KIS 자격증명 검증
python scripts/test_kis_connection.py

# 모든 테스트
pytest tests/ -v
```

### 환경 설정
```bash
# 가상환경 활성화 (Windows)
.\venv\Scripts\activate

# 의존성 설치
pip install -r requirements.txt

# 환경변수 편집 (메모장)
notepad .env
```

---

## 보안 체크리스트

```
[✓] .gitignore에 .env 포함
[✓] .gitignore에 data/ 포함 (DB 개인정보)
[✓] .gitignore에 reports/ 포함 (거래 정보)
[✓] .gitignore에 *.db 포함
[✓] KIS 자격증명 .env에서만 로드
[✓] 키 출력 시 마스킹 (앞 4자리 + ****)
[✓] API 호출 한도 보호 (분당 18회 + 1초 대기)
[✓] 토큰 자동 갱신 (만료 1시간 전)
[✓] 모의투자 우선 검증 (실거래 전 2-4주)
```

---

## 성능 모니터링 지표

매일 보고서에서 확인할 것:

| 지표 | 합격 기준 |
|------|----------|
| 알파 (vs 벤치마크) | > 0% |
| 정보비율 | > 0.3 (이상적 0.5+) |
| 샤프비 | > 1.0 |
| 최대 낙폭(MDD) | < 15% |
| 승률 | > 50% |
| 손익비 (Profit Factor) | > 1.5 |
| 거래비용 / 알파 | < 50% |

위 7개 중 5개 이상 통과하면 라이브 운영 권장.

---

*v2 변경 사항: 손절/익절/트레일링 자동화, 적응형 임계값, 자본 분할/섹터 로테이션 모듈, KIS 실시간 연동, 회귀 테스트 18개. 다음 v3에서는 자본 분할/섹터 로테이션 실제 통합 + 머신러닝 알파 추가 예정.*
