# 13. 포지션 관리 (Exit Manager + ATR 스탑)

진입 후 포지션을 어떻게 관리할 것인가? 손절/익절/트레일링 스탑의 실전 구현.

---

## 핵심 깨달음

**알고리즘 매매에서 가장 위험한 결함은 "매수만 잘하고 매도를 못 하는 것"** 입니다.

이번 세션에서 발견한 가장 심각한 결함이 바로 이것이었습니다:
- DB에 `stop_price`, `target_price` 가 저장되어 있었음
- 하지만 `_execute_sell()` 에서 사용 안 됨
- 결과: 봇은 ensemble 신호가 SELL일 때만 매도 → 진입가 대비 -50% 손실에도 청산 안 함

이 깨달음 자체가 이 문서의 핵심 가치입니다.

---

## 5가지 매도 트리거

봇은 5가지 독립적인 조건으로 매도를 결정합니다:

```
┌──────────────────────────────────────┐
│  매 분석 사이클(5~30분)마다 체크     │
└──────────────────────────────────────┘
        ▼
   ① ExitManager 평가 (가격 기반)
        ▼
   ┌─ 🔴 손절가 도달        → STOP_LOSS (전량)
   ├─ 🟢 1차 목표 도달      → TAKE_PROFIT_1 (50%)
   ├─ 🟢🟢 2차 목표 도달    → TAKE_PROFIT_2 (잔여)
   ├─ 📉 트레일링 스탑      → TRAILING_STOP (잔여)
   ├─ ⏰ 보유기간 초과       → TIME_STOP (옵션)
        ▼ (위 조건 미충족 시)
   ② 앙상블 SELL 신호 체크
        ▼
   └─ 📊 종합 판단 매도     → SIGNAL_SELL (전량)
```

**ExitManager가 앙상블 신호보다 항상 우선** — 안전이 최우선이기 때문.

---

## ATR 손절 이론

### Le Beau Chandelier Exit (1992)

```
손절가 = 진입가 - ATR × 2~3
```

- 22일 ATR 기준
- 멀티플라이어 2~3 (스윙 2, 트렌드 3)
- 백테스트: 3× ATR이 profit factor 1.61로 최적
- 드로우다운 22% 감소 효과

### 왜 ATR을 쓰는가?

**고정 % 손절(예: -5%)의 문제**:
- 변동성 낮은 종목: 너무 멀리 → 손실 누적
- 변동성 높은 종목: 너무 가깝게 → 노이즈에 자주 발동

**ATR 기반 손절의 장점**:
- 종목별 변동성에 자동 적응
- 노이즈와 진짜 추세 전환 구분 가능

```python
# 변동성 차이 예시
삼성전자 ATR ≈ ₩2,500 → 손절 ₩5,000 거리
바이오 ATR ≈ ₩8,000  → 손절 ₩16,000 거리
```

---

## Risk-Reward (RR) 비율

```
1차 목표 = 진입가 + (ATR × stop_mult × RR)
2차 목표 = 진입가 + (ATR × stop_mult × RR × 2)
```

기본값:
- `stop_mult = 2.0` (ATR × 2 손절)
- `RR = 2.0` (손절폭의 2배가 1차 목표)

예: 진입 ₩100,000, ATR ₩2,000일 때
- 손절: ₩96,000 (ATR × 2 = ₩4,000 거리)
- 1차 목표: ₩108,000 (1R = ₩8,000 이익)
- 2차 목표: ₩116,000 (2R = ₩16,000 이익)

---

## 분할 청산 전략

1차 목표 도달 시 **50%만 매도**하고 나머지는 추세에 맡깁니다:

```
진입 → 1차 목표 도달
     ↓
     50% 매도 + 손절선을 본전(진입가)으로 상향
     ↓
     무위험 거래 모드 (잔여 50%는 절대 손실 안 봄)
     ↓
     트레일링 스탑 활성화
     ↓
     가격 상승 → 트레일링 손절선도 따라 상승
     가격 하락 → 트레일링 손절선 도달 시 매도
```

**효과**:
- 1차 목표에서 보장된 수익 확보
- 잔여로 추세 수익 추격
- "Cut your losses, let your profits run" 원칙 준수

---

## 트레일링 스탑 (Chandelier Exit)

```python
trailing_stop = max(
    current_stop,                                              # 절대 하향 안 함
    highest_price_since_entry - ATR × trailing_multiplier      # 갱신
)
```

- `trailing_multiplier = 3.0` (Le Beau 표준)
- **상향만, 하향 금지** (이익 보호 핵심)
- 1차 익절 후에만 활성화 (그 전엔 단순 손절)

예시 흐름:
```
Day 1: 진입 ₩100, 손절 ₩96
Day 5: ₩110 → 1차 익절 50% + 손절 ₩100으로 상향
Day 7: ₩120 (최고가) → 트레일링 ₩114(120-2*3)
Day 10: ₩125 (최고 갱신) → 트레일링 ₩119
Day 12: ₩117 → 트레일링 ₩119 도달 → 잔여 매도
        총 수익: 50% × 10% + 50% × 19% ≈ +14.5%
```

---

## 구현 패턴: ExitManager 클래스

```python
@dataclass
class PositionExitState:
    symbol: str
    entry_price: float
    entry_atr: float
    entry_time: datetime
    initial_stop: float
    target_1: float
    target_2: float
    current_stop: float = 0.0          # 트레일링으로 변경 가능
    highest_price_since_entry: float = 0.0
    partial_sold_pct: float = 0.0      # 0.0/0.5/1.0
```

평가 메서드 (우선순위 순):

```python
def evaluate(self, symbol, current_price) -> ExitDecision:
    state = self.states.get(symbol)
    
    # 0. 최고가 갱신 (트레일링용)
    state.highest_price_since_entry = max(
        state.highest_price_since_entry, current_price
    )
    
    # 1. 트레일링 손절선 갱신 (1차 익절 후만)
    if state.partial_sold_pct >= 0.5:
        chandelier = state.highest - state.entry_atr * 3
        state.current_stop = max(state.current_stop, chandelier)
    
    # 2. 손절/트레일링 발동 체크
    if current_price <= state.current_stop:
        return STOP_LOSS or TRAILING_STOP  # 분할 익절 여부에 따라
    
    # 3. 1차 익절 (분할 50%) - 첫 진입 후 처음 발동
    if state.partial_sold_pct < 0.5 and current_price >= state.target_1:
        state.current_stop = state.entry_price  # 본전 상향!
        state.partial_sold_pct = 0.5
        return TAKE_PROFIT_1 (sell_ratio=0.5)
    
    # 4. 2차 익절 (전량)
    if current_price >= state.target_2:
        return TAKE_PROFIT_2 (sell_ratio=1.0)
    
    return NO_EXIT
```

---

## DB 스키마 확장

ExitManager 상태를 DB에 저장하여 재시작 시 복원:

```sql
-- positions 테이블에 추가된 컬럼
entry_atr            REAL DEFAULT 0  -- 진입 시점 ATR
current_stop         REAL DEFAULT 0  -- 현재 활성 손절선
highest_since_entry  REAL DEFAULT 0  -- 최고가 (Chandelier용)
partial_sold_pct     REAL DEFAULT 0  -- 0/0.5/1.0
target_1             REAL DEFAULT 0
target_2             REAL DEFAULT 0
```

재시작 시 복원 로직:

```python
def _restore_exit_states(self):
    for pos_data in self.db.load_positions():
        # 구버전 포지션은 entry_atr=0이므로 추정
        entry_atr = pos_data.get("entry_atr") or pos_data["avg_price"] * 0.02
        current_stop = pos_data.get("current_stop") or (avg_price - entry_atr * 2)
        # ...
        self.exit_manager.restore_state(state)
```

---

## 분할 매도 구현 (close_partial)

```python
def close_partial(self, symbol, ratio: float, strategy: str):
    """비중 기반 분할 매도 (1주 단위 절삭)"""
    for pos in self.get_positions():
        if pos.symbol == symbol and pos.quantity > 0:
            sell_qty = int(pos.quantity * ratio)
            if sell_qty < 1:
                # 1주 미만이면 ratio>=0.5일 때만 강제 1주
                sell_qty = 1 if ratio >= 0.5 and pos.quantity >= 1 else 0
            return self.sell_market(symbol, sell_qty, strategy=strategy)
```

**주의**: 1주 단위 절삭이므로 10주 × 0.5 = 5주는 정확하지만, 1주 × 0.5 = 0.5는 1주로 강제 처리.

---

## 시각화: 진행률 게이지

대시보드 포지션 카드에 두 종류의 막대 표시:

```javascript
// 진입가 → 현재가 → 1차 목표가 진행률
const progress = (current_price - avg_price) / (target_1 - avg_price)

// 진입가 → 현재가 → 손절선 진행률  
const stopProgress = (avg_price - current_price) / (avg_price - stop_price)
```

- 가격이 진입가보다 위 → 🟢 초록 (목표가 향해)
- 가격이 진입가보다 아래 → 🔴 빨강 (손절가 향해)
- 둘은 상호 배타적 (현재가는 한 방향)

---

## 회귀 테스트 (필수)

`tests/test_regression_bugs.py` 에 포함된 ExitManager 테스트:

```python
def test_register_entry_creates_state():
    """진입 등록 시 손절/목표 가격 정확히 계산"""
    state = em.register_entry("AAPL", 100.0, atr=2.0)
    assert state.initial_stop == 96.0    # 100 - 2*2
    assert state.target_1 == 108.0       # 100 + 2*2*2
    assert state.target_2 == 116.0       # 100 + 2*2*2*2

def test_take_profit_1_triggers_partial_sell():
    """1차 목표 도달 시 50% + 본전 상향"""
    state = em.register_entry("AAPL", 100.0, atr=2.0)
    decision = em.evaluate("AAPL", 109.0)
    assert decision.sell_ratio == 0.5
    assert state.current_stop == 100.0   # 본전 상향

def test_trailing_stop_after_partial_exit():
    """1차 익절 후 가격 하락 시 트레일링 발동"""
    em.evaluate("AAPL", 109.0)           # 1차 익절
    em.evaluate("AAPL", 120.0)           # 최고가 갱신
    decision = em.evaluate("AAPL", 113.0)  # 트레일링 ≤ 114 도달
    assert decision.reason == ExitReason.TRAILING_STOP
```

---

## 흔한 실수 (피하기)

### ❌ 실수 1: 매수 시점 ATR을 저장 안 함
```python
# 나쁜 예
self.update_position(symbol, qty, avg_price=price)
# 재시작 시 ATR을 모름 → 손절선 추정 불가
```

```python
# 좋은 예
self.update_position(symbol, qty, avg_price=price, entry_atr=atr)
self.exit_manager.register_entry(symbol, price, atr)
self._save_exit_state(symbol)  # DB 동기화
```

### ❌ 실수 2: 손절선을 매번 새로 계산
```python
# 나쁜 예: 매 사이클마다 stop = current_price - ATR × 2
# → 가격이 떨어지면 손절선도 함께 떨어짐 (의미 없음)
```

```python
# 좋은 예: 진입 시점에 한 번만 계산, 트레일링은 상향만
state.initial_stop = entry_price - entry_atr * 2  # 고정
state.current_stop = max(state.current_stop, chandelier_stop)  # 상향만
```

### ❌ 실수 3: 분할 매도 후 ExitManager 등록 해제
```python
# 나쁜 예
def _execute_partial_sell(symbol, ratio):
    self.executor.close_partial(symbol, ratio)
    self.exit_manager.unregister(symbol)  # ← 잘못!
```

```python
# 좋은 예
def _execute_partial_sell(symbol, ratio):
    self.executor.close_partial(symbol, ratio)
    self._save_exit_state(symbol)  # 상태만 동기화, unregister는 전량 청산 시에만
```

---

## 학술 자료

- **Le Beau, C. & Lucas, D. (1992)** "Technical Traders Guide to Computer Analysis of the Futures Markets" — Chandelier Exit 원조
- **Kaufman, P. (2013)** "Trading Systems and Methods" — ATR 스탑의 통계적 근거
- **Quantified Strategies (2024)** — 3× ATR 트레일링이 profit factor 1.61로 최적

---

*핵심: 매수보다 매도가 훨씬 어렵다. ExitManager는 감정 배제 + 객관적 가격 기준으로 자동 청산하는 안전장치다.*
