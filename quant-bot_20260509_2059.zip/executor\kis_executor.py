"""
=============================================================================
executor/kis_executor.py - 한국투자증권 주문 실행기
=============================================================================

한국투자증권 Open API를 통해 한국 주식(KOSPI/KOSDAQ)을 자동 매매합니다.

한국투자증권 Open API란?
- 국내 유일한 REST API 방식 증권사 API
- Windows/Mac/Linux 모두 사용 가능 (키움은 Windows만)
- 2022년 4월 서비스 시작, 활발한 커뮤니티

시작 방법:
1. 한국투자증권 계좌 개설
2. https://apiportal.koreainvestment.com 에서 API 신청
3. APP KEY, APP SECRET 발급
4. .env에 KIS_APP_KEY, KIS_APP_SECRET, KIS_ACCOUNT 저장
5. 모의투자 먼저 신청하여 테스트

API 특징:
- REST API (HTTP 요청/응답)
- OAuth2 토큰 인증 (토큰 유효기간 24시간)
- 실시간 데이터: WebSocket
- 주문: POST 요청
=============================================================================
"""

import os
import json
import time
import logging
from typing import List, Optional, Dict
from datetime import datetime, timedelta

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base import (
    BaseExecutor, Order, Position, AccountInfo,
    OrderSide, OrderType, OrderStatus
)

logger = logging.getLogger(__name__)


class KISExecutor(BaseExecutor):
    """
    한국투자증권 REST API 기반 주문 실행기

    사용법:
        executor = KISExecutor(paper=True)
        executor.connect()  # 토큰 발급

        # 시장가 매수 (삼성전자 10주)
        order = executor.buy_market("005930", 10)

        # 포지션 확인
        positions = executor.get_positions()
    """

    # API 엔드포인트
    BASE_URL_REAL = "https://openapi.koreainvestment.com:9443"
    BASE_URL_PAPER = "https://openapivts.koreainvestment.com:29443"

    def __init__(
        self,
        app_key: Optional[str] = None,
        app_secret: Optional[str] = None,
        account: Optional[str] = None,
        paper: bool = True
    ):
        """
        Parameters:
            app_key: 한투 APP KEY
            app_secret: 한투 APP SECRET
            account: 계좌번호 (예: "50012345-01")
            paper: True=모의투자, False=실거래
        """
        super().__init__(name="kis", paper=paper)

        self.app_key = app_key or os.environ.get("KIS_APP_KEY")
        self.app_secret = app_secret or os.environ.get("KIS_APP_SECRET")
        self.account = account or os.environ.get("KIS_ACCOUNT", "")
        self.base_url = self.BASE_URL_PAPER if paper else self.BASE_URL_REAL

        # 인증 토큰 (connect()에서 발급)
        self.access_token: Optional[str] = None
        self.token_expires: Optional[datetime] = None

        # 계좌번호 분리 (CANO-ACNT_PRDT_CD 형식)
        parts = self.account.split("-")
        self.cano = parts[0] if parts else ""
        self.acnt_prdt_cd = parts[1] if len(parts) > 1 else "01"

    @staticmethod
    def _strip_suffix(symbol: str) -> str:
        """
        종목 코드에서 .KS/.KQ 접미사 제거 (KIS API용)

        KIS API는 순수 6자리 종목코드만 허용:
        - "005930.KS" -> "005930"
        - "035720.KS" -> "035720"
        - "005930"    -> "005930" (이미 순수 코드)
        """
        if symbol.endswith(".KS") or symbol.endswith(".KQ"):
            return symbol[:-3]
        return symbol

    def connect(self) -> bool:
        """
        API 연결: OAuth2 접근 토큰 발급

        토큰은 24시간 유효하며, 만료 시 자동 재발급됩니다.
        """
        if not REQUESTS_AVAILABLE:
            logger.error("[KIS] requests 미설치")
            return False

        if not all([self.app_key, self.app_secret]):
            logger.error("[KIS] API 키가 설정되지 않았습니다. .env 파일을 확인하세요.")
            return False

        return self._request_token()

    def _request_token(self) -> bool:
        """OAuth2 토큰 발급/갱신 (내부 메서드)"""
        try:
            url = f"{self.base_url}/oauth2/tokenP"
            body = {
                "grant_type": "client_credentials",
                "appkey": self.app_key,
                "appsecret": self.app_secret,
            }

            response = requests.post(url, json=body, timeout=10)
            if response.status_code == 200:
                data = response.json()
                self.access_token = data.get("access_token")
                # 토큰 만료 시간 기록 (24시간 유효, 안전하게 23시간으로 설정)
                self.token_expires = datetime.now() + timedelta(hours=23)

                mode = "모의투자" if self.paper else "실거래"
                logger.info(
                    f"[KIS] {mode} 모드 연결 성공 "
                    f"(토큰 만료: {self.token_expires.strftime('%H:%M')})"
                )
                return True
            else:
                logger.error(f"[KIS] 토큰 발급 실패: {response.status_code}")
                return False

        except Exception as e:
            logger.error(f"[KIS] 연결 실패: {e}")
            return False

    def _ensure_token(self) -> bool:
        """
        토큰이 유효한지 확인하고, 만료 임박 시 자동 갱신

        KIS 토큰은 24시간 유효. 만료 1시간 전(23시간 후)에 갱신하여
        거래 중 인증 실패를 방지합니다.
        """
        if not self.access_token:
            return False
        if self.token_expires and datetime.now() >= self.token_expires:
            logger.info("[KIS] 토큰 만료 임박 -> 자동 갱신 중...")
            return self._request_token()
        return True

    def _get_headers(self, tr_id: str) -> Dict:
        """API 요청 헤더 생성"""
        return {
            "Content-Type": "application/json; charset=utf-8",
            "authorization": f"Bearer {self.access_token}",
            "appkey": self.app_key,
            "appsecret": self.app_secret,
            "tr_id": tr_id,
        }

    def submit_order(self, order: Order) -> Order:
        """
        한국투자증권에 주문 제출

        한국 주식 주문 tr_id:
        - 모의: VTTC0802U(매수), VTTC0801U(매도)
        - 실전: TTTC0802U(매수), TTTC0801U(매도)

        [v2.1] 토큰 자동 갱신 + 심볼 접미사 자동 제거
        """
        # 토큰 유효성 확인 (만료 시 자동 갱신)
        if not self._ensure_token():
            order.status = OrderStatus.REJECTED
            logger.error("[KIS] 토큰 없음/갱신 실패 -> 주문 거부")
            return order

        try:
            # tr_id 결정
            if self.paper:
                tr_id = "VTTC0802U" if order.side == OrderSide.BUY else "VTTC0801U"
            else:
                tr_id = "TTTC0802U" if order.side == OrderSide.BUY else "TTTC0801U"

            # 주문 유형 코드
            # "01"=지정가, "05"=시장가
            if order.order_type == OrderType.MARKET:
                ord_dvsn = "05"
                ord_unpr = "0"  # 시장가는 가격 0
            else:
                ord_dvsn = "01"
                ord_unpr = str(int(order.price)) if order.price else "0"

            # [FIX] 종목코드에서 .KS/.KQ 접미사 제거
            # KIS API는 순수 6자리 코드만 허용 (예: "005930")
            # 봇 내부에서 "005930.KS" 형식을 사용하므로 변환 필요
            kis_symbol = self._strip_suffix(order.symbol)

            # 주문 요청
            url = f"{self.base_url}/uapi/domestic-stock/v1/trading/order-cash"
            body = {
                "CANO": self.cano,
                "ACNT_PRDT_CD": self.acnt_prdt_cd,
                "PDNO": kis_symbol,             # 종목코드 (6자리, 접미사 제거됨)
                "ORD_DVSN": ord_dvsn,           # 주문구분
                "ORD_QTY": str(order.quantity),  # 주문수량
                "ORD_UNPR": ord_unpr,           # 주문단가
            }

            headers = self._get_headers(tr_id)
            response = requests.post(url, headers=headers, json=body, timeout=10)

            if response.status_code == 200:
                data = response.json()
                if data.get("rt_cd") == "0":  # 성공
                    order.order_id = data.get("output", {}).get("ODNO", "")
                    order.status = OrderStatus.SUBMITTED
                    order.submitted_at = datetime.now()
                else:
                    order.status = OrderStatus.REJECTED
                    logger.error(f"[KIS] 주문 거부: {data.get('msg1', '')}")
            else:
                order.status = OrderStatus.REJECTED

            self.orders.append(order)
            return order

        except Exception as e:
            logger.error(f"[KIS] 주문 실패: {e}")
            order.status = OrderStatus.REJECTED
            return order

    def cancel_order(self, order_id: str) -> bool:
        """주문 취소"""
        if not self._ensure_token():
            return False

        try:
            tr_id = "VTTC0803U" if self.paper else "TTTC0803U"
            url = f"{self.base_url}/uapi/domestic-stock/v1/trading/order-rvsecncl"

            body = {
                "CANO": self.cano,
                "ACNT_PRDT_CD": self.acnt_prdt_cd,
                "KRX_FWDG_ORD_ORGNO": "",
                "ORGN_ODNO": order_id,
                "ORD_DVSN": "01",
                "RVSE_CNCL_DVSN_CD": "02",  # 02=취소
                "ORD_QTY": "0",              # 전량
                "ORD_UNPR": "0",
                "QTY_ALL_ORD_YN": "Y",      # 전량 취소
            }

            headers = self._get_headers(tr_id)
            response = requests.post(url, headers=headers, json=body, timeout=10)
            return response.status_code == 200

        except Exception:
            return False

    def get_order_status(self, order_id: str) -> OrderStatus:
        """
        주문 체결 상태 조회

        KIS 체결 조회 API (VTTC8001R/TTTC8001R)를 호출하여
        주문의 실제 상태를 확인합니다.
        조회 실패 시 안전하게 SUBMITTED 반환 (보수적 접근)
        """
        if not self._ensure_token():
            return OrderStatus.REJECTED

        try:
            tr_id = "VTTC8001R" if self.paper else "TTTC8001R"
            url = f"{self.base_url}/uapi/domestic-stock/v1/trading/inquire-daily-ccld"

            params = {
                "CANO": self.cano,
                "ACNT_PRDT_CD": self.acnt_prdt_cd,
                "INQR_STRT_DT": datetime.now().strftime("%Y%m%d"),
                "INQR_END_DT": datetime.now().strftime("%Y%m%d"),
                "SLL_BUY_DVSN_CD": "00",  # 전체 (매수+매도)
                "INQR_DVSN": "00",
                "PDNO": "",
                "CCLD_DVSN": "00",
                "ORD_GNO_BRNO": "",
                "ODNO": order_id,
                "INQR_DVSN_3": "00",
                "INQR_DVSN_1": "",
                "CTX_AREA_FK100": "",
                "CTX_AREA_NK100": "",
            }

            headers = self._get_headers(tr_id)
            response = requests.get(url, headers=headers, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()
                for item in data.get("output1", []):
                    if item.get("odno") == order_id:
                        filled_qty = int(item.get("tot_ccld_qty", 0))
                        ord_qty = int(item.get("ord_qty", 0))
                        if filled_qty >= ord_qty and ord_qty > 0:
                            return OrderStatus.FILLED
                        elif filled_qty > 0:
                            return OrderStatus.PARTIAL
                        # 취소/정정 여부 확인
                        cncl_yn = item.get("cncl_yn", "N")
                        if cncl_yn == "Y":
                            return OrderStatus.CANCELLED
                        return OrderStatus.SUBMITTED

        except Exception as e:
            logger.debug(f"[KIS] 체결 조회 실패 (안전하게 SUBMITTED 반환): {e}")

        return OrderStatus.SUBMITTED

    def get_positions(self) -> List[Position]:
        """보유 포지션 조회"""
        if not self._ensure_token():
            return []

        try:
            tr_id = "VTTC8434R" if self.paper else "TTTC8434R"
            url = f"{self.base_url}/uapi/domestic-stock/v1/trading/inquire-balance"

            params = {
                "CANO": self.cano,
                "ACNT_PRDT_CD": self.acnt_prdt_cd,
                "AFHR_FLPR_YN": "N",
                "OFL_YN": "",
                "INQR_DVSN": "02",
                "UNPR_DVSN": "01",
                "FUND_STTL_ICLD_YN": "N",
                "FNCG_AMT_AUTO_RDPT_YN": "N",
                "PRCS_DVSN": "01",
                "CTX_AREA_FK100": "",
                "CTX_AREA_NK100": "",
            }

            headers = self._get_headers(tr_id)
            response = requests.get(url, headers=headers, params=params, timeout=10)

            if response.status_code != 200:
                return []

            data = response.json()
            positions = []

            for item in data.get("output1", []):
                qty = int(item.get("hldg_qty", 0))
                if qty > 0:
                    # KIS는 순수 6자리 코드를 반환 -> .KS 접미사 추가하여
                    # 봇 내부의 심볼 포맷과 일치시킴
                    raw_symbol = item.get("pdno", "")
                    symbol = f"{raw_symbol}.KS" if raw_symbol.isdigit() else raw_symbol

                    positions.append(Position(
                        symbol=symbol,
                        quantity=qty,
                        avg_price=float(item.get("pchs_avg_pric", 0)),
                        current_price=float(item.get("prpr", 0)),
                        unrealized_pnl=float(item.get("evlu_pfls_amt", 0)),
                        market_value=float(item.get("evlu_amt", 0)),
                    ))

            return positions

        except Exception as e:
            logger.error(f"[KIS] 포지션 조회 실패: {e}")
            return []

    def get_current_price(self, symbol: str) -> Optional[float]:
        """
        실시간 현재가 조회 (한국 주식 전용)

        KIS의 inquire-price API를 사용하여 약 1초 지연 수준의
        실시간 시세를 조회합니다. yfinance는 15-20분 지연이라
        KIS가 훨씬 정확한 가격을 제공합니다.

        Parameters:
            symbol: 종목코드 (".KS"/".KQ" 접미사 자동 제거)

        Returns:
            현재가 (KRW). 실패 시 None.

        호출 한도:
            - 모의투자: 1초당 20회
            - 실거래: 1초당 20회
            대시보드 1분 갱신은 충분히 여유로움.
        """
        if not self._ensure_token():
            return None

        try:
            kis_symbol = self._strip_suffix(symbol)

            url = f"{self.base_url}/uapi/domestic-stock/v1/quotations/inquire-price"
            headers = self._get_headers("FHKST01010100")
            params = {
                "FID_COND_MRKT_DIV_CODE": "J",  # J=주식
                "FID_INPUT_ISCD": kis_symbol,
            }
            response = requests.get(url, headers=headers, params=params, timeout=5)
            if response.status_code != 200:
                return None
            data = response.json()
            if data.get("rt_cd") != "0":
                return None
            price_str = data.get("output", {}).get("stck_prpr", "")
            if not price_str:
                return None
            return float(price_str)

        except Exception as e:
            logger.debug(f"[KIS] 시세 조회 실패 {symbol}: {e}")
            return None

    def get_index_quote(self, index_code: str) -> Optional[Dict]:
        """
        시장 지수 조회 (KOSPI=0001, KOSDAQ=1001)

        KIS의 inquire-index-price API를 사용하여 실시간 지수와
        전일 대비 변동률을 반환합니다.

        Parameters:
            index_code: "0001"(KOSPI), "1001"(KOSDAQ), "2001"(KOSPI200)

        Returns:
            {"price": float, "change": float, "change_pct": float} 또는 None
        """
        if not self._ensure_token():
            return None

        try:
            url = f"{self.base_url}/uapi/domestic-stock/v1/quotations/inquire-index-price"
            headers = self._get_headers("FHPUP02100000")
            params = {
                "FID_COND_MRKT_DIV_CODE": "U",  # U=업종/지수
                "FID_INPUT_ISCD": index_code,
            }
            response = requests.get(url, headers=headers, params=params, timeout=5)
            if response.status_code != 200:
                return None
            data = response.json()
            if data.get("rt_cd") != "0":
                return None
            output = data.get("output", {})
            return {
                "price": float(output.get("bstp_nmix_prpr", 0)),
                "change": float(output.get("bstp_nmix_prdy_vrss", 0)),
                "change_pct": float(output.get("prdy_ctrt", 0)),
            }
        except Exception as e:
            logger.debug(f"[KIS] 지수 조회 실패 {index_code}: {e}")
            return None

    def get_current_prices(self, symbols: List[str]) -> Dict[str, float]:
        """
        여러 종목 현재가 일괄 조회

        KIS는 일괄 조회 API가 없어서 각 종목을 순차 호출합니다.
        1초당 20회 제한이 있으므로 종목 수가 20개를 넘으면 100ms 대기.

        Returns:
            {symbol: price} 딕셔너리. 실패한 종목은 제외.
        """
        result = {}
        for i, sym in enumerate(symbols):
            price = self.get_current_price(sym)
            if price is not None:
                result[sym] = price
            # API 한도 보호: 매 20개마다 1초 대기
            if (i + 1) % 18 == 0 and i < len(symbols) - 1:
                time.sleep(1.0)
        return result

    def get_account(self) -> AccountInfo:
        """계좌 정보 조회"""
        if not self._ensure_token():
            return AccountInfo(currency="KRW")

        try:
            tr_id = "VTTC8434R" if self.paper else "TTTC8434R"
            url = f"{self.base_url}/uapi/domestic-stock/v1/trading/inquire-balance"

            params = {
                "CANO": self.cano,
                "ACNT_PRDT_CD": self.acnt_prdt_cd,
                "AFHR_FLPR_YN": "N",
                "OFL_YN": "",
                "INQR_DVSN": "02",
                "UNPR_DVSN": "01",
                "FUND_STTL_ICLD_YN": "N",
                "FNCG_AMT_AUTO_RDPT_YN": "N",
                "PRCS_DVSN": "01",
                "CTX_AREA_FK100": "",
                "CTX_AREA_NK100": "",
            }

            headers = self._get_headers(tr_id)
            response = requests.get(url, headers=headers, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()
                output2 = data.get("output2", [{}])
                if output2:
                    summary = output2[0]
                    return AccountInfo(
                        total_equity=float(summary.get("tot_evlu_amt", 0)),
                        cash=float(summary.get("dnca_tot_amt", 0)),
                        buying_power=float(summary.get("nass_amt", 0)),
                        positions_value=float(summary.get("scts_evlu_amt", 0)),
                        currency="KRW",
                    )

            return AccountInfo(currency="KRW")

        except Exception as e:
            logger.error(f"[KIS] 계좌 조회 실패: {e}")
            return AccountInfo(currency="KRW")
