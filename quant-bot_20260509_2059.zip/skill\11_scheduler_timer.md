# 11. 스케줄링 & 타이머 (백그라운드 작업 관리)

## 배운 것

봇이 5분마다 분석을 실행하려면 스케줄링이 필요하다.
APScheduler를 시도했다가 문제가 생겨서 직접 타이머로 교체한 경험.

---

## 1. APScheduler (시도 → 폐기)

### 사용법
```python
from apscheduler.schedulers.background import BackgroundScheduler

scheduler = BackgroundScheduler()
scheduler.add_job(
    func=analyze,
    trigger='interval',
    minutes=5,
    id='analysis_job'
)
scheduler.start()
```

### 문제점
```python
# scheduler/job_manager.py
try:
    from apscheduler.schedulers.background import BackgroundScheduler
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False

class JobManager:
    def __init__(self):
        if APSCHEDULER_AVAILABLE:
            self.scheduler = BackgroundScheduler()
            self.scheduler.start()
        else:
            self.scheduler = None  # ← 여기가 문제
    
    def add_interval_job(self, func, minutes, job_id):
        if self.scheduler is None:
            return False  # ← 조용히 실패! 에러 로그도 없음!
        self.scheduler.add_job(func, 'interval', minutes=minutes, id=job_id)
        return True
```

**근본 원인:** APScheduler가 설치되었지만 특정 환경에서 import 실패.
`return False`만 하고 로그를 남기지 않아서 발견하기 어려웠음.

### 교훈
- 라이브러리 의존성은 반드시 실패 시 로그를 남겨야 함
- 선택적 의존성(optional dependency)은 명확한 폴백이 있어야 함
- "조용히 실패"는 가장 위험한 패턴

---

## 2. 직접 타이머 구현 (최종 채택)

### 코드
```python
import time, threading

def _run_bot_thread():
    """봇 분석 루프 (Flask 백그라운드 스레드)"""
    interval_seconds = interval_minutes * 60  # 예: 5분 = 300초
    
    # ── 초기 분석 1회 실행 ──
    _run_one_cycle("초기 분석")
    
    last_analysis_time = time.time()
    cycle_count = 0
    
    logger.info(f"반복 분석 타이머 시작: {interval_minutes}분({interval_seconds}초) 간격")
    
    # ── 반복 분석 루프 ──
    while bot_instance and bot_instance.running:
        time.sleep(1)  # 1초마다 체크 (CPU 부하 최소)
        
        elapsed = time.time() - last_analysis_time
        if elapsed >= interval_seconds:
            cycle_count += 1
            logger.info(f"정기 분석 #{cycle_count} 시작 ({interval_minutes}분 경과)")
            _run_one_cycle(f"정기 분석 #{cycle_count}")
            last_analysis_time = time.time()
```

### 왜 이게 APScheduler보다 나았나?

| 항목 | APScheduler | 직접 타이머 |
|------|-------------|-------------|
| 의존성 | pip install 필요 | 없음 (표준 라이브러리) |
| 실패 모드 | import 실패 시 조용히 무시 | 코드가 곧 로직, 실패하면 바로 보임 |
| 디버깅 | 내부 동작 추적 어려움 | print 한 줄이면 충분 |
| 복잡도 | 과한 기능 (cron, 이벤트 등) | 필요한 것만 구현 |
| 스레드 안전 | 자체 스레드풀 관리 | Flask 스레드에서 직접 실행 |

### 핵심 포인트

```python
# ❌ 나쁜 방법: time.sleep(300) — 5분 동안 블로킹
time.sleep(300)  # → bot.running = False 해도 5분 기다려야 종료

# ✅ 좋은 방법: time.sleep(1) + elapsed 체크
while bot.running:
    time.sleep(1)  # 1초 단위로 체크 → 종료 반응 1초 이내
    if time.time() - last >= 300:
        run_analysis()
        last = time.time()
```

`sleep(1)` + elapsed 패턴의 장점:
1. **빠른 종료 반응** — stop 신호 후 최대 1초 내 종료
2. **정확한 간격** — sleep(300)은 분석 시간만큼 밀리지만, elapsed는 실제 경과 시간 기준
3. **상태 모니터링 가능** — 루프 내에서 다른 체크 추가 가능

---

## 3. 분석 주기 설계

```
봇 시작
  ├→ 초기 분석 (즉시 1회)
  │    ├→ US 시장 분석
  │    └→ KR 시장 분석
  │
  └→ 반복 타이머 시작
       ├→ 5분 경과 → 정기 분석 #1
       ├→ 10분 경과 → 정기 분석 #2
       └→ ... (봇 종료까지 반복)
```

### _run_one_cycle() 공유 함수
```python
def _run_one_cycle(label):
    """초기 분석과 정기 분석이 같은 로직 공유"""
    logger.info(f"[{label}] US 시장 분석...")
    bot_instance._analyze_us_market()
    
    logger.info(f"[{label}] KR 시장 분석...")
    bot_instance._analyze_kr_market()
    
    # 활동 로그 기록
    _log_activity(f"{label} 완료")
    
    # WebSocket으로 대시보드에 알림
    socketio.emit('analysis_complete', {"label": label})
```

초기 분석과 정기 분석의 로직이 같으므로 하나의 함수로 통일.
코드 중복 제거 + 수정 시 한 곳만 고치면 됨.

---

## 4. 시장 운영시간 고려

```python
# 한국 시장: 09:00 ~ 15:30 KST
# 미국 시장: 22:30 ~ 05:00 KST (서머타임 시 23:30)

# 장이 닫혀있을 때도 분석은 실행하되, 실매매는 안 함
# → 모의매매기는 24시간 동작 가능
# → 실거래기는 장 운영시간 체크 필요
```

---

## 핵심 교훈

1. **단순한 것이 더 낫다** — APScheduler보다 직접 타이머가 더 안정적이었음
2. **sleep(1) + elapsed 패턴** — 반응성과 정확성 모두 확보
3. **조용한 실패 방지** — 스케줄러가 작동 안 하면 반드시 로그
4. **초기/반복 로직 통일** — 공유 함수로 중복 제거
5. **daemon 스레드** — 메인 프로세스 종료 시 자동 정리
