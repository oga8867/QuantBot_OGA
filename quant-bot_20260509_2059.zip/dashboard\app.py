"""
=============================================================================
dashboard/app.py - 퀀트봇 웹 대시보드 서버
=============================================================================

Flask + Flask-SocketIO 기반 실시간 웹 대시보드입니다.
브라우저에서 봇 상태를 모니터링하고, 설정을 변경하고, 매매를 제어합니다.

주요 기능:
┌───────────────────────────────────────────────────────────┐
│ 1. 실시간 상태 모니터링 (WebSocket으로 1초마다 업데이트)  │
│ 2. 모의매매 ↔ 실거래 전환                                 │
│ 3. 전략 파라미터 설정 (자본금, 리스크, 종목 리스트 등)    │
│ 4. 거래 이력 조회                                         │
│ 5. 수익 차트 (equity curve)                               │
│ 6. 봇 시작/중지 제어                                      │
│ 7. 알림 설정 (텔레그램 토큰 등)                           │
└───────────────────────────────────────────────────────────┘

아키텍처:
    [브라우저] ←── WebSocket ──→ [Flask 서버] ←→ [QuantBot 인스턴스]
                                      ↕
                                 [SQLite DB]

사용법:
    python dashboard/app.py          # http://localhost:5000 에서 실행
    python dashboard/app.py --port 8080  # 포트 변경
=============================================================================
"""

import sys
import os
import json
import threading
import time
import numpy as np
from datetime import datetime, timedelta
from typing import Optional

# 프로젝트 루트를 path에 추가
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ─── .env 로드 (KIS API 키 등) ───
# Flask가 자동으로 .env를 로드하지만, 명시적으로 호출하여
# 다른 모듈(executor.kis_executor)이 import 시점에 환경변수를
# 읽을 수 있도록 보장
try:
    from dotenv import load_dotenv
    _env_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        ".env"
    )
    if os.path.exists(_env_path):
        load_dotenv(_env_path)
except ImportError:
    pass  # python-dotenv 미설치 시 환경변수만 사용

from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit

from config.settings import (
    Settings, CapitalConfig, RiskConfig, DashboardConfig,
    US_WATCHLIST, KR_WATCHLIST,
    SECTOR_UNIVERSE, AVAILABLE_SECTORS
)
from database.cache import DatabaseManager
from utils.logger import setup_logger
from utils.market import detect_market, is_kr_stock, is_us_stock, get_exchange_rate
from reporter.daily_report import DailyReportGenerator

# ── 대시보드 운영 파라미터 (매직넘버 중앙 관리) ──
_dash_cfg = DashboardConfig()

# ─── Flask 앱 초기화 ─────────────────────────────────────────────────────
app = Flask(
    __name__,
    template_folder="templates",
    static_folder="static"
)
# ★ SECRET_KEY: 하드코딩 대신 환경변수 또는 랜덤 생성
# 하드코딩된 키는 세션 위조(session forgery) 가능 → 보안 위험
app.config["SECRET_KEY"] = os.environ.get(
    "FLASK_SECRET_KEY",
    os.urandom(32).hex()  # 서버 시작마다 새로 생성 (개발용)
)
# 정적 파일(JS/CSS) 브라우저 캐시 비활성화 (개발 모드)
# 0초 = 매번 서버에서 최신 파일을 확인하도록 강제
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

# ── numpy 타입 안전 JSON 인코더 ──
# pandas/numpy 데이터가 WebSocket으로 전송될 때
# int64, float64 등이 json.dumps()에서 실패하는 것을 방지합니다.
class NumpySafeJSON(json.JSONEncoder):
    """numpy 타입을 Python native로 자동 변환하는 JSON 인코더"""
    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        if isinstance(obj, bytes):
            return obj.decode('utf-8', errors='replace')
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

# ── SocketIO가 사용할 커스텀 JSON 래퍼 ──
# socketio.emit()은 내부적으로 json.dumps()를 호출합니다.
# 이 래퍼를 전달하면 numpy 타입이 섞여 있어도 직렬화가 실패하지 않습니다.
class _SafeJSON:
    """SocketIO에 주입할 json 호환 모듈 래퍼"""
    @staticmethod
    def dumps(*args, **kwargs):
        kwargs.setdefault('cls', NumpySafeJSON)
        return json.dumps(*args, **kwargs)

    @staticmethod
    def loads(*args, **kwargs):
        return json.loads(*args, **kwargs)

# SocketIO: WebSocket 실시간 통신
# ★ CORS를 localhost만 허용 (같은 네트워크의 악성 페이지가 WebSocket 접근 차단)
_CORS_ORIGINS = os.environ.get(
    "CORS_ORIGINS",
    "http://localhost:5000,http://127.0.0.1:5000"
).split(",")
socketio = SocketIO(
    app,
    cors_allowed_origins=_CORS_ORIGINS,
    async_mode="threading",
    json=_SafeJSON,  # ★ numpy int64/float64 안전 직렬화
)

# ─── 전역 상태 ───────────────────────────────────────────────────────────
logger = setup_logger(level="INFO")

# 봇 인스턴스 (None = 아직 시작 안 됨)
bot_instance = None
bot_thread = None

# 디스코드 봇 인스턴스 (양방향 명령)
discord_bot_instance = None

# ── 봇 인스턴스 보호 Lock ──
# Flask는 멀티스레드로 요청을 처리하므로,
# /api/bot/start 와 /api/bot/stop 이 동시에 호출되면
# bot_instance가 두 번 생성되거나 불완전하게 파괴될 수 있음.
# 이 Lock은 봇 생성/파괴를 원자적으로 만든다.
_bot_lock = threading.Lock()

# ═══════════════════════════════════════════════════════════════════════════
# 설정 영속화 (JSON 파일)
# ═══════════════════════════════════════════════════════════════════════════
#
# 사용자가 대시보드에서 변경한 설정(관심종목, 자본금, 리스크 등)을
# config/user_settings.json 파일에 저장합니다.
# 서버를 재시작해도 마지막으로 저장한 설정이 자동으로 복원됩니다.
#
# 저장 시점:
#   - /api/settings POST (설정 저장 버튼 클릭) 시 자동 호출
#   - 관심종목 추가/제거 시 자동 호출
#
# 파일 위치: quant-bot/config/user_settings.json
# ═══════════════════════════════════════════════════════════════════════════

# 설정 파일 경로 (프로젝트 루트/config/user_settings.json)
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_SETTINGS_FILE = os.path.join(_PROJECT_ROOT, "config", "user_settings.json")


def _get_default_settings() -> dict:
    """
    기본 설정값 반환

    최초 실행이거나 설정 파일이 없을 때 사용되는 기본값입니다.
    이 값들은 코드에서만 정의되며, user_settings.json에 저장되면
    이후부터는 저장된 값이 우선 적용됩니다.
    """
    return {
        "capital": 10_000_000,           # 초기 자본금 (원)
        "currency": "KRW",               # 통화 단위
        "risk_per_trade": 0.02,          # 거래당 리스크 (2%)
        "max_position_size": 0.10,       # 최대 포지션 크기 (10%)
        "max_daily_loss": 0.03,          # 일일 최대 손실 (3%)
        "max_drawdown": 0.15,            # 최대 드로우다운 (15%)
        "stop_loss_atr_multiplier": 2.0, # 손절 ATR 배수
        "risk_reward_ratio": 2.0,        # 위험보상비율
        "sizing_method": "kelly",        # 포지션 사이징 방법
        "kelly_fraction": 0.5,           # 켈리 비율 (하프 켈리)
        "broker": "paper",               # 브로커 (paper/alpaca/kis)
        "live_mode": False,              # 실거래 모드 여부
        "us_watchlist": US_WATCHLIST.copy(),   # 미국 관심종목
        "kr_watchlist": KR_WATCHLIST.copy(),   # 한국 관심종목
        "telegram_token": "",            # 텔레그램 봇 토큰
        "telegram_chat_id": "",          # 텔레그램 채팅 ID
        "discord_webhook_url": "",       # 디스코드 웹훅 URL
        "discord_bot_token": "",         # 디스코드 봇 토큰 (양방향 명령용)
        "discord_bot_channel_id": "",    # 명령 허용 채널 ID (빈값이면 전체 허용)
        "discord_bot_autostart": False,  # 대시보드 시작 시 봇 자동 시작
        "dart_api_key": "",              # DART 공시 API 키
        # ── 브로커 API 키 (실거래용) ──
        "kis_app_key": "",               # 한국투자증권 APP KEY
        "kis_app_secret": "",            # 한국투자증권 APP SECRET
        "kis_account": "",               # 한국투자증권 계좌번호 (예: 50012345-01)
        "alpaca_api_key": "",            # Alpaca API Key
        "alpaca_secret_key": "",         # Alpaca Secret Key
        "analysis_interval": "60",       # 분석 주기 (분 단위)
        "schedule_kr_start": "09:05",    # 한국 시장 분석 시작 시간
        "schedule_kr_end": "15:20",      # 한국 시장 분석 종료 시간
        "schedule_us_start": "22:35",    # 미국 시장 분석 시작 시간 (한국시간)
        "schedule_us_end": "05:00",      # 미국 시장 분석 종료 시간
        "interest_sectors": ["semiconductor_ai", "bigtech_platform", "energy_battery"],
        # 종목 자동 발굴 설정
        "discovery_enabled": True,              # 자동 발굴 활성화
        "discovery_cycle_multiplier": 4,        # N번째 분석마다 발굴 실행
        "discovery_max_per_market": 10,         # 시장당 최대 발굴 수
        "discovery_max_watchlist": 35,          # 통합 워치리스트 최대 크기
        "discovery_include_movers": True,       # 시장 거래량 상위종목 포함
    }


def _load_saved_settings() -> dict:
    """
    저장된 설정 파일(user_settings.json)에서 설정을 로드합니다.

    동작 흐름:
    1. 기본값으로 시작
    2. user_settings.json 파일이 있으면 읽어서 기본값에 덮어쓰기(merge)
    3. 파일이 없거나 읽기 실패 시 기본값 그대로 사용

    merge 방식이므로, 새로운 설정 키가 코드에 추가되어도
    기존 저장 파일에 없는 키는 기본값이 자동 적용됩니다.
    """
    defaults = _get_default_settings()

    if not os.path.exists(_SETTINGS_FILE):
        logger.info("[설정] 저장된 설정 파일 없음 → 기본값 사용")
        return defaults

    try:
        with open(_SETTINGS_FILE, "r", encoding="utf-8") as f:
            saved = json.load(f)

        # 기본값에 저장된 값을 덮어쓰기 (새 키는 기본값 유지)
        for key in defaults:
            if key in saved:
                defaults[key] = saved[key]

        logger.info(f"[설정] 저장된 설정 로드 완료: {_SETTINGS_FILE}")
        return defaults

    except Exception as e:
        logger.warning(f"[설정] 설정 파일 로드 실패 (기본값 사용): {e}")
        return defaults


def _save_settings_to_file():
    """
    현재 설정을 user_settings.json 파일에 저장합니다.

    JSON 형식으로 저장하며, ensure_ascii=False로 한글이
    깨지지 않고 읽기 쉽게 저장됩니다.

    호출 시점:
    - 설정 저장 API (/api/settings POST) 처리 후
    - 관심종목 변경 API 처리 후
    """
    try:
        # config 디렉토리가 없으면 생성
        os.makedirs(os.path.dirname(_SETTINGS_FILE), exist_ok=True)

        with open(_SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(current_settings, f, ensure_ascii=False, indent=2)

        logger.debug(f"[설정] 설정 파일 저장 완료: {_SETTINGS_FILE}")
    except Exception as e:
        logger.warning(f"[설정] 설정 파일 저장 실패: {e}")


# 현재 설정 (대시보드에서 수정 가능, 서버 재시작 시 파일에서 복원)
current_settings = _load_saved_settings()

# 봇 런타임 상태
bot_status = {
    "running": False,
    "mode": "paper",           # paper / alpaca / kis
    "live": False,
    "started_at": None,
    "last_analysis": None,
    "total_equity": 0,
    "cash": 0,
    "positions": {},
    "daily_pnl": 0,
    "total_pnl": 0,
    "total_trades": 0,
    "win_rate": 0,
    "signals_today": [],
}

# ── 실시간 거래 감지를 위한 상태 추적 ──
# _status_broadcaster에서 trade_history 길이를 비교해 새 거래를 감지함
_last_trade_count = 0
_trade_count_lock = threading.Lock()  # ★ 동시 수정 방지
_last_snapshot_time = 0  # equity 스냅샷 마지막 저장 시각 (time.time())
_last_price_refresh = 0  # 보유 포지션 가격 새로고침 마지막 시각

# 시장 지수 캐시 (KOSPI, NASDAQ 등)
_market_indices_cache = {}
_market_indices_cache_time = 0

# ── KIS API 시세 조회용 싱글톤 ──
# 매번 토큰을 발급받지 않고 24시간 동안 1개 인스턴스를 재사용
# (토큰 발급 자체에 호출 한도가 있음)
_kis_price_client = None
_kis_price_client_lock = threading.Lock()


def get_kis_price_client():
    """
    KIS 시세 조회용 싱글톤 클라이언트 반환

    .env에 KIS_APP_KEY/KIS_APP_SECRET가 설정되어 있으면
    1회 토큰을 발급받아 인스턴스를 캐싱하여 반환합니다.
    토큰 만료 시 자동 갱신됩니다.

    실거래/모의투자 구분: KIS_PAPER 환경변수 (기본 true=모의투자)

    Returns:
        KISExecutor 인스턴스 또는 None (자격증명 없음/연결 실패)
    """
    global _kis_price_client

    # 빠른 경로: 이미 생성됨
    if _kis_price_client is not None:
        return _kis_price_client

    with _kis_price_client_lock:
        # 더블 체크 락
        if _kis_price_client is not None:
            return _kis_price_client

        app_key = os.environ.get("KIS_APP_KEY", "")
        app_secret = os.environ.get("KIS_APP_SECRET", "")
        if not app_key or not app_secret:
            return None

        try:
            from executor.kis_executor import KISExecutor
            paper_str = os.environ.get("KIS_PAPER", "true").lower()
            paper = paper_str in ("true", "1", "yes")
            client = KISExecutor(paper=paper)
            if client.connect():
                _kis_price_client = client
                logger.info(
                    f"[KIS 시세] {'모의투자' if paper else '실거래'} 클라이언트 초기화 완료"
                )
                return client
            else:
                logger.warning("[KIS 시세] 토큰 발급 실패 - yfinance로 fallback")
                return None
        except Exception as e:
            logger.warning(f"[KIS 시세] 초기화 실패: {e} - yfinance로 fallback")
            return None

# ── 일일 보고서 생성기 ──
# DailyReportGenerator: 봇 중지 시 또는 수동 API 호출 시 일일 보고서 HTML 생성
# reports/ 폴더에 daily_YYYY-MM-DD.html 형태로 저장됨
_report_generator = DailyReportGenerator()

# ── .env 파일 저장 (텔레그램/디스코드 토큰 영속화) ──

def _save_env_file():
    """
    텔레그램/디스코드/DART API 키를 .env 파일에 저장합니다.
    설정 변경 시 호출되어, 알림 관련 토큰을 환경 변수 파일에 영속화합니다.
    """
    env_path = os.path.join(_PROJECT_ROOT, ".env")
    env_lines = {}

    # 기존 .env 파일 읽기
    if os.path.exists(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    key, val = line.split("=", 1)
                    env_lines[key.strip()] = val.strip()

    # 현재 설정에서 토큰 업데이트
    if current_settings.get("telegram_token"):
        env_lines["TELEGRAM_TOKEN"] = current_settings["telegram_token"]
    if current_settings.get("telegram_chat_id"):
        env_lines["TELEGRAM_CHAT_ID"] = current_settings["telegram_chat_id"]
    if current_settings.get("discord_webhook_url"):
        env_lines["DISCORD_WEBHOOK_URL"] = current_settings["discord_webhook_url"]
    if current_settings.get("dart_api_key"):
        env_lines["DART_API_KEY"] = current_settings["dart_api_key"]

    # ── 브로커 API 키 ──
    if current_settings.get("kis_app_key"):
        env_lines["KIS_APP_KEY"] = current_settings["kis_app_key"]
    if current_settings.get("kis_app_secret"):
        env_lines["KIS_APP_SECRET"] = current_settings["kis_app_secret"]
    if current_settings.get("kis_account"):
        env_lines["KIS_ACCOUNT"] = current_settings["kis_account"]
    if current_settings.get("alpaca_api_key"):
        env_lines["ALPACA_API_KEY"] = current_settings["alpaca_api_key"]
    if current_settings.get("alpaca_secret_key"):
        env_lines["ALPACA_SECRET_KEY"] = current_settings["alpaca_secret_key"]

    # .env 파일 쓰기
    try:
        with open(env_path, "w", encoding="utf-8") as f:
            for key, val in env_lines.items():
                f.write(f"{key}={val}\n")
        logger.debug("[설정] .env 파일 업데이트 완료")
    except Exception as e:
        logger.warning(f"[설정] .env 파일 저장 실패: {e}")


# ── 실시간 활동 로그 (프론트엔드 피드에 표시) ──
# 최대 50개까지 유지. 봇 분석/매수/매도 등 주요 이벤트를 기록
_activity_log = []
_activity_log_lock = threading.Lock()

def _add_activity(action: str, detail: str, level: str = "info"):
    """
    봇 활동을 로그에 추가하고 WebSocket으로 실시간 전송

    Parameters:
        action: 활동 종류 ("analyzing", "buy", "sell", "signal", "risk_check", "start", "stop")
        detail: 상세 설명 텍스트
        level: "info", "success", "warning", "danger" 중 하나 (UI 색상 결정)
    """
    entry = {
        "action": action,
        "detail": detail,
        "level": level,
        "timestamp": datetime.now().isoformat(),
    }
    with _activity_log_lock:
        _activity_log.append(entry)
        # 최대 N개만 유지 (오래된 것부터 제거)
        if len(_activity_log) > _dash_cfg.activity_log_max:
            _activity_log[:] = _activity_log[-_dash_cfg.activity_log_max:]
    # WebSocket으로 즉시 브로드캐스트
    try:
        socketio.emit("bot_activity", entry)
    except Exception:
        pass


# =============================================================================
# 라우트 (페이지)
# =============================================================================

@app.route("/")
def index():
    """
    메인 대시보드 페이지

    cache_bust: 서버 시작 시각 기반 타임스탬프를 전달하여
    브라우저가 항상 최신 JS/CSS를 로드하도록 강제합니다.
    (개발 중 캐시 문제 방지)
    """
    import time as _time
    return render_template("index.html", cache_bust=int(_time.time()))


# =============================================================================
# REST API 엔드포인트
# =============================================================================

@app.route("/api/status")
def api_status():
    """현재 봇 상태 반환"""
    return jsonify(bot_status)


@app.route("/api/settings", methods=["GET"])
def api_get_settings():
    """현재 설정 조회"""
    return jsonify(current_settings)


@app.route("/api/settings", methods=["POST"])
def api_save_settings():
    """
    설정 저장 (JSON body)

    프론트엔드에서 설정 폼을 제출하면 여기로 옵니다.
    봇이 실행 중이면 일부 설정은 즉시 반영, 일부는 재시작 필요.
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data"}), 400

    # ── 분석 간격 변경 감지 (봇 실행 중 스케줄러 동적 업데이트용) ──
    old_interval = current_settings.get("analysis_interval", "60")
    new_interval = data.get("analysis_interval", old_interval)
    interval_changed = (str(old_interval) != str(new_interval))

    # 설정 업데이트
    for key in current_settings:
        if key in data:
            current_settings[key] = data[key]

    # .env 파일에 텔레그램 정보 저장
    _save_env_file()

    # ── 봇 실행 중이면 분석 간격 즉시 반영 ──
    # 스케줄러에 등록된 분석 작업의 주기를 동적으로 변경합니다.
    # 봇 재시작 없이도 설정 탭에서 변경한 간격이 바로 적용됩니다.
    reschedule_msg = ""
    if interval_changed and bot_status["running"] and bot_instance:
        try:
            new_minutes = _parse_interval(new_interval)
            _reschedule_analysis(new_minutes)
            reschedule_msg = f" (분석 간격 {new_minutes}분으로 즉시 변경됨)"
            _add_activity("settings", f"분석 간격 → {new_minutes}분 변경 적용", "info")
            logger.info(f"[대시보드] 분석 간격 동적 변경: {old_interval} → {new_interval} ({new_minutes}분)")
        except Exception as e:
            logger.warning(f"[대시보드] 분석 간격 동적 변경 실패 (재시작 필요): {e}")
            reschedule_msg = " (간격 변경은 봇 재시작 후 적용됩니다)"

    # ── 설정을 파일에 영속화 (서버 재시작 후에도 유지) ──
    _save_settings_to_file()

    logger.info(f"[대시보드] 설정 업데이트 + 파일 저장: {json.dumps(data, ensure_ascii=False)}{reschedule_msg}")
    return jsonify({"success": True, "settings": current_settings, "message": reschedule_msg})


@app.route("/api/bot/start", methods=["POST"])
def api_start_bot():
    """
    봇 시작

    현재 설정으로 QuantBot을 생성하고 별도 스레드에서 실행합니다.
    이미 실행 중이면 에러 반환.
    """
    global bot_instance, bot_thread

    # ★ Lock으로 start/stop 동시 호출 방지
    if not _bot_lock.acquire(blocking=False):
        return jsonify({"error": "다른 작업이 진행 중입니다"}), 409

    try:
        if bot_status["running"]:
            return jsonify({"error": "Bot is already running"}), 400

        # 설정 객체 생성
        settings = Settings(
            capital=CapitalConfig(
                total_capital=current_settings["capital"],
                currency=current_settings["currency"]
            ),
            risk=RiskConfig(
                risk_per_trade=current_settings["risk_per_trade"],
                max_position_size=current_settings["max_position_size"],
                max_daily_loss=current_settings["max_daily_loss"],
                max_drawdown=current_settings["max_drawdown"],
                stop_loss_atr_multiplier=current_settings["stop_loss_atr_multiplier"],
                risk_reward_ratio=current_settings["risk_reward_ratio"],
                sizing_method=current_settings["sizing_method"],
                kelly_fraction=current_settings["kelly_fraction"],
            )
        )

        # 종목 발굴 설정 반영
        from config.settings import DiscoveryConfig
        settings.discovery = DiscoveryConfig(
            enabled=current_settings.get("discovery_enabled", True),
            cycle_multiplier=current_settings.get("discovery_cycle_multiplier", 4),
            max_discovered_per_market=current_settings.get("discovery_max_per_market", 10),
            max_total_watchlist=current_settings.get("discovery_max_watchlist", 35),
            include_market_movers=current_settings.get("discovery_include_movers", True),
        )

        # ── 브로커 API 키를 환경변수에 설정 (실거래 시 필요) ──
        # 대시보드에서 입력한 API 키를 os.environ에 반영하여
        # KISExecutor/AlpacaExecutor가 자동으로 읽을 수 있게 함
        _broker_env_keys = {
            "KIS_APP_KEY": current_settings.get("kis_app_key", ""),
            "KIS_APP_SECRET": current_settings.get("kis_app_secret", ""),
            "KIS_ACCOUNT": current_settings.get("kis_account", ""),
            "ALPACA_API_KEY": current_settings.get("alpaca_api_key", ""),
            "ALPACA_SECRET_KEY": current_settings.get("alpaca_secret_key", ""),
        }
        for env_key, env_val in _broker_env_keys.items():
            if env_val:
                os.environ[env_key] = env_val

        # QuantBot 임포트 및 생성
        from run_bot import QuantBot
        bot_instance = QuantBot(
            settings=settings,
            broker=current_settings["broker"],
            live=current_settings["live_mode"]
        )

        # 상태 업데이트 (스레드 시작 전에 먼저 설정 → UI 즉시 반응)
        bot_status["running"] = True
        bot_status["mode"] = current_settings["broker"]
        bot_status["live"] = current_settings["live_mode"]
        bot_status["started_at"] = datetime.now().isoformat()
        bot_status["total_equity"] = current_settings["capital"]
        bot_status["cash"] = current_settings["capital"]

        # 별도 스레드에서 봇 실행 (_run_bot_thread가 직접 connect/schedule/분석 담당)
        bot_thread = threading.Thread(target=_run_bot_thread, daemon=True)
        bot_thread.start()

        # 거래 감지 카운터는 _run_bot_thread 내에서 connect() 직후에 동기화
        # (과거 DB 복원 거래가 "새 거래"로 알림되는 것 방지)

        logger.info(f"[대시보드] 봇 시작 - 모드: {current_settings['broker']}, "
                    f"실거래: {current_settings['live_mode']}")
        return jsonify({"success": True, "status": bot_status})

    except Exception as e:
        logger.error(f"[대시보드] 봇 시작 실패: {e}")
        bot_status["running"] = False
        return jsonify({"error": str(e)}), 500
    finally:
        _bot_lock.release()


@app.route("/api/broker/test", methods=["POST"])
def api_test_broker():
    """
    브로커 API 연결 테스트

    현재 설정된 API 키로 KIS/Alpaca에 연결을 시도하고
    성공 여부를 반환합니다. 실제 주문은 하지 않습니다.
    """
    broker = current_settings.get("broker", "paper")
    result = {"success": True, "kr_status": False, "us_status": False,
              "kr_connected": False, "us_connected": False,
              "kr_error": "", "us_error": ""}

    if broker == "paper":
        return jsonify({"success": True, "message": "Paper 모드는 연결 테스트가 필요 없습니다."})

    # ── API 키를 환경변수에 설정 ──
    _env_map = {
        "KIS_APP_KEY": current_settings.get("kis_app_key", ""),
        "KIS_APP_SECRET": current_settings.get("kis_app_secret", ""),
        "KIS_ACCOUNT": current_settings.get("kis_account", ""),
        "ALPACA_API_KEY": current_settings.get("alpaca_api_key", ""),
        "ALPACA_SECRET_KEY": current_settings.get("alpaca_secret_key", ""),
    }
    for k, v in _env_map.items():
        if v:
            os.environ[k] = v

    # ── KIS 테스트 ──
    if broker in ("kis", "dual"):
        result["kr_status"] = True
        try:
            from executor.kis_executor import KISExecutor
            kis = KISExecutor(paper=True)  # 항상 모의투자로 테스트
            if kis.connect():
                result["kr_connected"] = True
            else:
                result["kr_error"] = "API 키 또는 계좌번호를 확인하세요"
        except Exception as e:
            result["kr_error"] = str(e)[:100]

    # ── Alpaca 테스트 ──
    if broker in ("alpaca", "dual"):
        result["us_status"] = True
        try:
            from executor.alpaca_executor import AlpacaExecutor
            alp = AlpacaExecutor(paper=True)  # 항상 Paper로 테스트
            if alp.connect():
                result["us_connected"] = True
            else:
                result["us_error"] = "API 키를 확인하세요 (alpaca.markets → API Keys)"
        except Exception as e:
            result["us_error"] = str(e)[:100]

    return jsonify(result)


@app.route("/api/bot/stop", methods=["POST"])
def api_stop_bot():
    """봇 중지 + 일일 보고서 자동 생성"""
    global bot_instance

    # ★ Lock으로 start/stop 동시 호출 방지
    if not _bot_lock.acquire(blocking=False):
        return jsonify({"error": "다른 작업이 진행 중입니다"}), 409

    try:
        if not bot_status["running"]:
            return jsonify({"error": "Bot is not running"}), 400

        # ── 봇 중지 전에 일일 보고서 생성 ──
        # 중지 시점의 거래 이력/포지션/계좌 정보를 스냅샷으로 보고서에 기록
        report_path = None
        if bot_instance:
            try:
                report_path = _generate_daily_report()
                if report_path:
                    _add_activity("analyzing", f"일일 보고서 생성 완료", "success")
                    logger.info(f"[대시보드] 일일 보고서 생성: {report_path}")
            except Exception as re:
                logger.warning(f"[대시보드] 보고서 생성 실패 (무시): {re}")

        if bot_instance:
            bot_instance.stop()
            bot_instance = None

        bot_status["running"] = False
        _add_activity("stop", "봇이 중지되었습니다", "warning")
        logger.info("[대시보드] 봇 중지됨")

        result = {"success": True}
        if report_path:
            result["report"] = report_path
        return jsonify(result)

    except Exception as e:
        logger.error(f"[대시보드] 봇 중지 실패: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        _bot_lock.release()


@app.route("/api/report/generate", methods=["POST"])
def api_generate_report():
    """
    일일 보고서 수동 생성 API

    봇이 실행 중일 때 수동으로 보고서를 생성합니다.
    대시보드 UI의 '보고서 생성' 버튼에서 호출됩니다.
    """
    try:
        report_path = _generate_daily_report()
        if report_path:
            return jsonify({"success": True, "path": report_path})
        else:
            return jsonify({"error": "보고서 생성에 필요한 데이터가 없습니다"}), 400
    except Exception as e:
        logger.error(f"[대시보드] 보고서 생성 실패: {e}")
        return jsonify({"error": str(e)}), 500




@app.route("/api/report/market", methods=["POST"])
def api_generate_market_report():
    """
    시장 동향 보고서 생성 API

    주요 지수 + 섹터 + 거시경제 + 뉴스를 종합 분석한
    시장 보고서를 별도 HTML 파일로 생성합니다.
    대시보드 UI의 '시장 보고서 생성' 버튼에서 호출됩니다.
    """
    try:
        from reporter.market_report import MarketReportGenerator
        gen = MarketReportGenerator()
        filename = gen.generate(settings=current_settings)
        logger.info(f"[대시보드] 시장 보고서 생성 완료: {filename}")
        return jsonify({"success": True, "filename": filename})
    except Exception as e:
        logger.error(f"[대시보드] 시장 보고서 생성 실패: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/reports")
def api_list_reports():
    """
    저장된 보고서 목록 조회 API

    reports/ 폴더에 있는 HTML 보고서 파일 목록을 반환합니다.
    최신순으로 정렬되어 반환됩니다.
    """
    try:
        reports_dir = _report_generator.reports_dir
        if not os.path.exists(reports_dir):
            return jsonify({"reports": []})

        files = []
        for f in os.listdir(reports_dir):
            if f.endswith(".html") and (f.startswith("daily_") or f.startswith("market_")):
                filepath = os.path.join(reports_dir, f)
                stat = os.stat(filepath)
                files.append({
                    "filename": f,
                    "date": f.replace("daily_", "").replace("market_", "").replace(".html", ""),
                    "size": stat.st_size,
                    "created": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                })

        # 최신순 정렬
        files.sort(key=lambda x: x["date"], reverse=True)
        return jsonify({"reports": files})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/reports/<filename>")
def serve_report(filename):
    """
    보고서 HTML 파일을 직접 서빙

    /reports/daily_2026-05-06.html 형태로 접근 가능합니다.
    대시보드에서 보고서 목록의 링크를 클릭하면 새 탭으로 열립니다.
    """
    from flask import send_from_directory, abort
    # ★ Path Traversal 방지: 파일명에 '..' 또는 '/' 포함 차단
    # 예: /reports/../../etc/passwd → 서버 파일 유출 가능
    from werkzeug.utils import secure_filename
    safe_name = secure_filename(filename)
    if not safe_name or safe_name != filename:
        abort(400, "잘못된 파일명입니다")
    reports_dir = _report_generator.reports_dir
    return send_from_directory(reports_dir, safe_name)


@app.route("/api/trades")
def api_trades():
    """
    거래 이력 조회

    DB에서 거래 이력을 가져오고, 한국 종목에는 종목명을 추가합니다.
    프론트엔드에서 name 필드를 사용해 종목명을 표시합니다.
    """
    limit = request.args.get("limit", 50, type=int)
    try:
        with DatabaseManager() as db:
            trades = db.get_trades(limit=limit)

        # ── 각 거래에 종목명 추가 + side 대문자 통일 + 포지션 유형 파싱 ──
        for t in trades:
            if isinstance(t, dict):
                if "symbol" in t and not t.get("name"):
                    t["name"] = get_stock_display_name(t["symbol"])
                # ★ side를 대문자로 통일 (DB에 "buy"/"sell" 소문자로 저장됨)
                if "side" in t:
                    t["side"] = t["side"].upper()
                # 매매 이유 JSON 파싱
                if "reasons_json" in t and t["reasons_json"]:
                    try:
                        t["reasons"] = json.loads(t["reasons_json"])
                    except (json.JSONDecodeError, TypeError):
                        t["reasons"] = []

        return jsonify(trades)
    except Exception as e:
        return jsonify({"error": str(e), "trades": []}), 500


@app.route("/api/positions")
def api_positions():
    """
    현재 보유 포지션 조회 (REST API)

    WebSocket이 끊어져도 포지션을 확인할 수 있도록 REST 엔드포인트 제공.
    봇이 실행 중이면 executor에서 실시간 포지션을 가져오고,
    봇이 꺼져있으면 DB 캐시에서 마지막 저장된 포지션을 반환.
    """
    try:
        # 봇이 실행 중이면 executor에서 직접 조회
        if bot_instance and hasattr(bot_instance, 'executor'):
            from utils.market import get_position_attr as _gpa
            positions = bot_instance.executor.get_positions()
            result = []

            # DB에서 포지션 메타데이터 한번에 조회
            db_meta = {}
            try:
                with DatabaseManager() as _db:
                    for db_pos in _db.load_positions():
                        db_meta[db_pos["symbol"]] = db_pos
            except Exception:
                pass

            for p in positions:
                sym = _gpa(p, 'symbol', '')
                meta = db_meta.get(sym, {})
                # reasons_json → 리스트로 파싱
                reasons = []
                try:
                    raw = meta.get("reasons_json", "[]")
                    if raw:
                        reasons = json.loads(raw) if isinstance(raw, str) else raw
                except (json.JSONDecodeError, TypeError):
                    reasons = []

                result.append({
                    "symbol": sym,
                    "name": get_stock_display_name(sym),
                    "shares": _gpa(p, 'quantity', 0),
                    "avg_price": _gpa(p, 'avg_price', 0),
                    "current_price": _gpa(p, 'current_price', 0),
                    "market_value": _gpa(p, 'market_value', 0),
                    "pnl": _gpa(p, 'unrealized_pnl', 0),
                    "pnl_pct": _gpa(p, 'unrealized_pnl_pct', 0),
                    # ── 포지션 메타데이터 (DB에서 병합) ──
                    "position_type": meta.get("position_type", ""),
                    "position_type_en": meta.get("position_type_en", ""),
                    "target_price": meta.get("target_price", 0),
                    "stop_price": meta.get("stop_price", 0),
                    "holding_period": meta.get("holding_period", ""),
                    "bought_at": meta.get("bought_at", ""),
                    "reasons": reasons,
                })
            return jsonify(result)

        # 봇이 꺼져있으면 DB 캐시에서 조회
        with DatabaseManager() as db:
            cached = db.load_positions() if hasattr(db, 'load_positions') else []
        return jsonify(cached if cached else [])

    except Exception as e:
        logger.error(f"[API] 포지션 조회 오류: {e}")
        return jsonify([])


@app.route("/api/equity")
def api_equity():
    """
    포트폴리오 가치 히스토리 (차트용)

    equity_history 테이블에서 시간별 자산 데이터를 가져옵니다.
    portfolio_snapshots(일별)가 없으면 equity_history(시간별)를 사용합니다.
    """
    days = request.args.get("days", 90, type=int)
    try:
        with DatabaseManager() as db:
            # 먼저 equity_history (시간별 상세 데이터) 시도
            eq_history = db.get_equity_history(days=days)
            if eq_history:
                return jsonify(eq_history)

            # 없으면 portfolio_snapshots (일별) 폴백
            snapshots = db.get_snapshots(days=days)
            rows = [
                {"date": s["date"], "total_value": s["total_value"],
                 "daily_return": s.get("daily_return", 0),
                 "cumulative_return": s.get("cumulative_return", 0)}
                for s in snapshots
            ]
        return jsonify(rows)
    except Exception as e:
        return jsonify({"error": str(e), "data": []}), 500


@app.route("/api/performance")
def api_performance():
    """
    성과 통계 API (승률, 샤프비, MDD, 손익비 등)

    대시보드에서 실시간으로 성과 지표를 보여주기 위한 엔드포인트.
    DB에서 거래 기록 + equity history를 가져와 계산합니다.

    Returns:
        {win_rate, profit_factor, sharpe_ratio, max_drawdown_pct,
         avg_win, avg_loss, calmar_ratio, win_count, loss_count, ...}
    """
    try:
        with DatabaseManager() as db:
            # 매도 거래에서 승률/손익비 계산
            trades = db.get_trades(limit=10000)
            sell_trades = [t for t in trades if t.get("side", "").upper() == "SELL"]

            win_count = 0
            loss_count = 0
            total_win = 0.0
            total_loss = 0.0

            for t in sell_trades:
                pnl = t.get("pnl", 0) or 0
                if pnl > 0:
                    win_count += 1
                    total_win += pnl
                elif pnl < 0:
                    loss_count += 1
                    total_loss += abs(pnl)

            total_sells = len(sell_trades)
            win_rate = (win_count / total_sells * 100) if total_sells > 0 else 0
            profit_factor = (total_win / total_loss) if total_loss > 0 else 0
            avg_win = (total_win / win_count) if win_count > 0 else 0
            avg_loss = (total_loss / loss_count) if loss_count > 0 else 0

            # MDD 계산
            mdd = db.calculate_max_drawdown(days=90)

            # 샤프비 계산
            eq_history = db.get_equity_history(days=90)
            sharpe = 0.0
            calmar = 0.0
            if len(eq_history) >= 2:
                import statistics
                equities = [h["total_equity"] for h in eq_history]
                daily_returns = []
                for i in range(1, len(equities)):
                    if equities[i - 1] > 0:
                        daily_returns.append(equities[i] / equities[i - 1] - 1)
                if daily_returns and len(daily_returns) > 1:
                    mean_r = statistics.mean(daily_returns)
                    std_r = statistics.stdev(daily_returns)
                    risk_free = _dash_cfg.risk_free_rate / 252
                    if std_r > 0:
                        sharpe = (mean_r - risk_free) / std_r * (252 ** 0.5)

                    # 칼마비
                    if mdd > 0 and equities[0] > 0:
                        total_return = equities[-1] / equities[0] - 1
                        n_days = len(equities)
                        annual_return = (1 + total_return) ** (252 / n_days) - 1
                        calmar = annual_return / mdd
        return jsonify({
            "win_rate": round(win_rate, 2),
            "profit_factor": round(profit_factor, 2),
            "sharpe_ratio": round(sharpe, 2),
            "calmar_ratio": round(calmar, 2),
            "max_drawdown_pct": round(mdd * 100, 2),
            "avg_win": round(avg_win, 0),
            "avg_loss": round(avg_loss, 0),
            "win_count": win_count,
            "loss_count": loss_count,
            "total_trades": len(trades),
            "total_sells": total_sells,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/signals")
def api_signals():
    """
    최근 신호 로그

    DB에서 신호를 가져오고 한국 종목에는 종목명을 추가합니다.
    """
    limit = request.args.get("limit", 30, type=int)
    try:
        with DatabaseManager() as db:
            cursor = db.conn.execute(
                "SELECT * FROM signals ORDER BY timestamp DESC LIMIT ?", (limit,)
            )
            rows = [dict(row) for row in cursor.fetchall()]

        # ── 각 신호에 종목명 추가 (DB 해제 후 처리) ──
        for r in rows:
            if "symbol" in r and not r.get("name"):
                r["name"] = get_stock_display_name(r["symbol"])

        return jsonify(rows)
    except Exception as e:
        return jsonify({"error": str(e), "signals": []}), 500


@app.route("/api/analyze", methods=["POST"])
def api_analyze_now():
    """즉시 분석 실행 (수동 트리거)"""
    data = request.get_json() or {}
    symbol = data.get("symbol", "")

    if not symbol:
        return jsonify({"error": "Symbol required"}), 400

    # 비동기로 분석 실행
    threading.Thread(
        target=_run_single_analysis,
        args=(symbol,),
        daemon=True
    ).start()

    return jsonify({"success": True, "message": f"Analyzing {symbol}..."})


@app.route("/api/sectors")
def api_sectors():
    """
    사용 가능한 섹터 목록 반환

    프론트엔드에서 관심 분야 선택 UI를 렌더링할 때 사용합니다.
    각 섹터의 키, 이름(한/영), 아이콘, 종목 수를 반환합니다.
    """
    sectors = []
    for key, data in SECTOR_UNIVERSE.items():
        sectors.append({
            "key": key,
            "name_ko": data["name_ko"],
            "name_en": data["name_en"],
            "icon": data["icon"],
            "stock_count": len(data["stocks"]),
        })
    return jsonify({
        "sectors": sectors,
        "selected": current_settings.get("interest_sectors", [])
    })


@app.route("/api/scanner")
def api_scanner():
    """
    시장 스캐너 - 관심 분야에서 "주목할 종목" 추출

    선택된 섹터의 종목들을 분석하여 신호 강도 기준 상위 종목을 반환합니다.
    결과는 캐시되어 반복 요청 시 빠르게 응답합니다.

    Returns:
        {
            "results": [{ symbol, name, market, sector, signal, strength, price, change_1d, rsi }],
            "scanned_at": "ISO timestamp",
            "total_scanned": N
        }
    """
    # 캐시 확인 (설정된 TTL 이내 결과가 있으면 재사용)
    global _scanner_cache
    now = datetime.now()
    if (_scanner_cache and
        _scanner_cache.get("scanned_at") and
        (now - datetime.fromisoformat(_scanner_cache["scanned_at"])).seconds < _dash_cfg.scanner_cache_ttl):
        return jsonify(_scanner_cache)

    # 관심 섹터에서 종목 리스트 추출
    selected_sectors = current_settings.get("interest_sectors", [])
    if not selected_sectors:
        selected_sectors = AVAILABLE_SECTORS[:3]  # 기본값: 처음 3개 섹터

    stocks_to_scan = []
    for sector_key in selected_sectors:
        sector_data = SECTOR_UNIVERSE.get(sector_key, {})
        for symbol in sector_data.get("stocks", []):
            if symbol not in [s["symbol"] for s in stocks_to_scan]:
                stocks_to_scan.append({
                    "symbol": symbol,
                    "sector_key": sector_key,
                    "sector_name": sector_data.get("name_ko", sector_key),
                })

    # 비동기로 스캔 실행 (이미 진행 중이 아니면, Lock으로 동시 시작 방지)
    with _scanner_lock:
        should_start = not _scanner_running
    if should_start:
        threading.Thread(
            target=_run_scanner,
            args=(stocks_to_scan,),
            daemon=True
        ).start()
        # 아직 결과 없으면 빈 결과 + scanning 상태 반환
        if not _scanner_cache:
            return jsonify({
                "results": [],
                "scanning": True,
                "total_scanned": 0,
                "scanned_at": None
            })

    return jsonify(_scanner_cache or {"results": [], "scanning": True})


# 스캐너 캐시 & 상태 (Lock으로 동시 실행 방지)
_scanner_cache = None
_scanner_running = False
_scanner_lock = threading.Lock()

# ── 전역 한국 종목명 캐시 ──────────────────────────────────────────────
# pykrx에서 한 번 로드하면 앱 전체에서 재사용 (스캐너, 분석, 포지션 표시 등)
# { "005930": "삼성전자", "035720": "카카오", ... }
_kr_name_cache = {}
_kr_name_cache_loaded = False

def _load_kr_name_cache():
    """
    한국 주식 종목명을 pykrx에서 한 번에 로드하여 전역 캐시에 저장.
    코스피 + 코스닥 전체 종목을 로드합니다.
    이미 로드됐으면 즉시 반환합니다.

    pykrx가 실패할 경우를 대비해 주요 종목 폴백 딕셔너리를 사용합니다.
    """
    global _kr_name_cache, _kr_name_cache_loaded
    if _kr_name_cache_loaded and len(_kr_name_cache) > 0:
        return _kr_name_cache

    # ── 폴백: 주요 한국 종목 (pykrx 로드 실패 시 최소한 이 종목들은 표시) ──
    _FALLBACK_NAMES = {
        "005930": "삼성전자", "000660": "SK하이닉스", "035720": "카카오",
        "035420": "NAVER", "005380": "현대차", "051910": "LG화학",
        "006400": "삼성SDI", "003670": "포스코퓨처엠", "028260": "삼성물산",
        "105560": "KB금융", "055550": "신한지주", "086790": "하나금융지주",
        "066570": "LG전자", "012330": "현대모비스", "003550": "LG",
        "096770": "SK이노베이션", "034730": "SK", "015760": "한국전력",
        "032830": "삼성생명", "090430": "아모레퍼시픽", "018260": "삼성에스디에스",
        "033780": "KT&G", "030200": "KT", "017670": "SK텔레콤",
        "000270": "기아", "009150": "삼성전기", "010130": "고려아연",
        "034020": "두산에너빌리티", "003490": "대한항공", "011200": "HMM",
        "259960": "크래프톤", "352820": "하이브", "263750": "펄어비스",
        "036570": "엔씨소프트", "251270": "넷마블", "068270": "셀트리온",
        "207940": "삼성바이오로직스", "326030": "SK바이오팜",
        "373220": "LG에너지솔루션", "247540": "에코프로비엠", "086520": "에코프로",
        # ── 워치리스트에 포함되어 있지만 폴백에 누락된 종목 추가 ──
        "042700": "한미반도체", "403870": "HPSP", "012450": "한화에어로스페이스",
        "145020": "휴젤", "196170": "알테오젠", "316140": "우리금융지주",
        "051900": "LG생활건강", "004170": "신세계",
    }

    # 폴백을 기본으로 넣어두고, pykrx 성공 시 덮어씀
    if len(_kr_name_cache) == 0:
        _kr_name_cache.update(_FALLBACK_NAMES)

    try:
        from pykrx import stock as pykrx_stock
        loaded = 0
        for mkt in ("KOSPI", "KOSDAQ"):
            tickers = pykrx_stock.get_market_ticker_list(market=mkt)
            for ticker in tickers:
                name = pykrx_stock.get_market_ticker_name(ticker)
                if name:
                    _kr_name_cache[ticker] = name
                    loaded += 1
        if loaded > 0:
            _kr_name_cache_loaded = True
            logger.info(f"[종목명 캐시] pykrx에서 {loaded}개 종목 로드 완료")
        else:
            logger.warning("[종목명 캐시] pykrx 반환값 0개, 폴백 사용 중")
    except Exception as e:
        logger.warning(f"[종목명 캐시] pykrx 로드 실패 (폴백 {len(_FALLBACK_NAMES)}개 사용): {e}")

    # 폴백이라도 있으면 loaded 상태로 전환 (반복 로드 시도 방지)
    if len(_kr_name_cache) > 0:
        _kr_name_cache_loaded = True

    return _kr_name_cache


def get_stock_display_name(symbol: str) -> str:
    """
    종목 코드에서 표시용 이름 반환 (모든 곳에서 공통 사용)

    한국 주식: "삼성전자 (005930)" 형태
    미국 주식: 그대로 반환 (이름은 별도 조회 필요)

    Returns:
        str: 종목 표시명. 이름을 못 찾으면 원래 symbol 그대로 반환.
    """
    if is_kr_stock(symbol):
        pure_code = symbol.replace(".KS", "").replace(".KQ", "")
        # 전역 캐시에서 조회
        if not _kr_name_cache_loaded:
            _load_kr_name_cache()
        name = _kr_name_cache.get(pure_code, "")
        if name:
            return f"{name} ({pure_code})"
    return symbol


def _run_scanner(stocks_to_scan: list):
    """
    시장 스캐너 백그라운드 실행

    모든 종목을 분석하고 신호 강도 기준 상위 15개를 캐시에 저장합니다.
    분석 실패한 종목은 건너뜁니다.
    """
    global _scanner_cache, _scanner_running
    with _scanner_lock:
        _scanner_running = True

    results = []
    try:
        from collectors.price_us import PriceCollectorUS
        from collectors.price_kr import PriceCollectorKR
        from analyzers.technical import TechnicalAnalyzer
        from config.settings import TechnicalConfig

        analyzer = TechnicalAnalyzer(TechnicalConfig())
        us_collector = PriceCollectorUS()
        kr_collector = PriceCollectorKR()

        # ── 전역 한국 종목명 캐시 로드 (아직 안 됐으면) ──
        _load_kr_name_cache()

        for item in stocks_to_scan:
            symbol = item["symbol"]
            try:
                # 시장 판별 & 데이터 수집 (통합 유틸리티 사용)
                market = detect_market(symbol)
                if market == "KR":
                    df = kr_collector.safe_collect(symbol, period="3mo")
                else:
                    df = us_collector.safe_collect(symbol, period="3mo")

                if df is None or df.empty or len(df) < 20:
                    logger.debug(f"[스캐너] {symbol} 데이터 부족, 스킵")
                    continue

                # 기술적 분석
                df_analyzed = analyzer.calculate_all(df)
                signal = analyzer.generate_signal(df_analyzed)

                close = df_analyzed["Close"]
                change_1d = ((close.iloc[-1] / close.iloc[-2]) - 1) * 100 if len(close) > 1 else 0

                # 종목명 가져오기 (한국: 캐시 우선, 미국: yfinance)
                # 종목명 실패해도 분석 결과는 포함시킴
                stock_name = symbol
                try:
                    if market == "KR":
                        # 캐시에서 조회 (.KS/.KQ 제거한 순수 코드)
                        pure_code = symbol.replace(".KS", "").replace(".KQ", "")
                        stock_name = _kr_name_cache.get(pure_code, symbol)
                    else:
                        info = _get_stock_info(symbol)
                        stock_name = info.get("name", symbol)
                except Exception:
                    pass  # 이름 조회 실패해도 결과는 포함

                results.append({
                    "symbol": symbol,
                    "name": stock_name,
                    "market": market,
                    "sector": item["sector_name"],
                    "sector_key": item["sector_key"],
                    "signal": signal.signal,
                    "strength": round(signal.strength, 3),
                    "price": round(float(close.iloc[-1]), 2),
                    "change_1d": round(change_1d, 2),
                    "rsi": round(float(df_analyzed["RSI"].iloc[-1]), 1) if "RSI" in df_analyzed.columns else 0,
                    "volume": int(df_analyzed["Volume"].iloc[-1]) if "Volume" in df_analyzed.columns else 0,
                })

                logger.info(f"[스캐너] {symbol} ({stock_name}): {signal.signal} "
                           f"(강도: {signal.strength:.2f})")

            except Exception as e:
                logger.warning(f"[스캐너] {symbol} 분석 실패: {e}")
                continue

        # 신호 강도 기준 정렬 (BUY > HOLD > SELL, 강도 높은 순)
        signal_priority = {"BUY": 3, "HOLD": 2, "SELL": 1}
        results.sort(key=lambda x: (
            signal_priority.get(x["signal"], 0),
            x["strength"]
        ), reverse=True)

        # 상위 N개 (한국/미국 균형) — 각 시장에서 최소 절반은 포함
        kr_results = [r for r in results if r["market"] == "KR"]
        us_results = [r for r in results if r["market"] == "US"]
        per_mkt = _dash_cfg.scanner_per_market
        balanced = (kr_results[:per_mkt] + us_results[:per_mkt])
        balanced.sort(key=lambda x: (
            signal_priority.get(x["signal"], 0),
            x["strength"]
        ), reverse=True)
        top_n = _dash_cfg.scanner_top_results
        top_results = balanced[:top_n] if balanced else results[:top_n]

        logger.info(f"[스캐너] 결과: US {len(us_results)}개, KR {len(kr_results)}개 "
                    f"→ 상위 {len(top_results)}개 선택")

        # ── 자동 발굴 종목 정보 수집 (이름 포함) ──
        # 봇이 실행 중이면 발굴 시스템의 종목 리스트를 함께 제공
        # 프론트엔드에서 종목명을 표시할 수 있도록 {symbol, name} 객체로 전달
        discovered_info = {"us": [], "kr": [], "enabled": False}
        try:
            if bot_instance and hasattr(bot_instance, 'get_discovery_status'):
                disc = bot_instance.get_discovery_status()
                discovered_info["enabled"] = disc.get("enabled", False)
                # US: {symbol, name} 형태로 변환
                for sym in disc.get("discovered_us", []):
                    us_name = sym
                    try:
                        info = _get_stock_info(sym)
                        us_name = info.get("name", sym)
                    except Exception:
                        pass
                    discovered_info["us"].append({"symbol": sym, "name": us_name})
                # KR: {symbol, name} 형태로 변환
                for sym in disc.get("discovered_kr", []):
                    kr_name = get_stock_display_name(sym)
                    discovered_info["kr"].append({"symbol": sym, "name": kr_name})
        except Exception:
            pass

        # 캐시에 저장 (전체 결과 + 상위 결과 분리)
        _scanner_cache = {
            "results": top_results,           # 기본 표시용 (상위 N개)
            "all_results": results,            # 더보기용 (전체 결과)
            "total_results": len(results),     # 전체 결과 수
            "scanned_at": datetime.now().isoformat(),
            "total_scanned": len(stocks_to_scan),
            "scanning": False,
            "discovered": discovered_info,     # 자동 발굴 종목 정보
        }

        logger.info(f"[스캐너] 완료: {len(stocks_to_scan)}개 스캔 → "
                    f"상위 {len(top_results)}개 + 전체 {len(results)}개 캐시")

    except Exception as e:
        logger.error(f"[스캐너] 오류: {e}")
        _scanner_cache = {
            "results": [],
            "scanned_at": datetime.now().isoformat(),
            "total_scanned": 0,
            "scanning": False,
            "error": str(e)
        }
    finally:
        with _scanner_lock:
            _scanner_running = False


@app.route("/api/stock/search")
def api_stock_search():
    """
    종목 검색 API

    쿼리로 종목명 또는 티커를 검색합니다.
    yfinance의 Ticker.info를 활용하여 종목명을 가져옵니다.

    Parameters:
        q: 검색어 (예: "apple", "삼성", "AAPL")
        market: "us" 또는 "kr" (선택)
    """
    query = request.args.get("q", "").strip()
    market = request.args.get("market", "all")

    if not query or len(query) < 1:
        return jsonify([])

    results = []

    try:
        # 한국 주식: pykrx에서 종목명 매칭
        if market in ("kr", "all"):
            results.extend(_search_kr_stocks(query))

        # 미국 주식: yfinance ticker info
        if market in ("us", "all"):
            results.extend(_search_us_stocks(query))

    except Exception as e:
        logger.error(f"[검색] 오류: {e}")

    return jsonify(results[:20])  # 최대 20개


@app.route("/api/stock/info")
def api_stock_info():
    """
    종목 기본 정보 조회

    Parameters:
        symbol: 종목 코드 (예: "AAPL", "005930.KS")
    """
    symbol = request.args.get("symbol", "").strip()
    if not symbol:
        return jsonify({"error": "symbol required"}), 400

    try:
        info = _get_stock_info(symbol)
        return jsonify(info)
    except Exception as e:
        return jsonify({"error": str(e), "symbol": symbol, "name": symbol})


def _get_stock_info(symbol: str) -> dict:
    """
    종목 기본 정보 조회 (미국 주식: yfinance, 한국 주식: pykrx 캐시)

    [이전 truncation으로 사라진 함수 복원]

    yfinance의 Ticker.info에서 종목명, 시가총액, 섹터 등을 가져옵니다.
    한국 주식은 전역 _kr_name_cache에서 이름을 조회합니다.

    Parameters:
        symbol: 종목 코드 (예: "AAPL", "005930.KS")

    Returns:
        dict: {"symbol": ..., "name": ..., "sector": ..., "market_cap": ...}
    """
    result = {"symbol": symbol, "name": symbol}

    if symbol.endswith((".KS", ".KQ")):
        # 한국 주식: 캐시에서 조회
        pure_code = symbol.replace(".KS", "").replace(".KQ", "")
        if not _kr_name_cache_loaded:
            _load_kr_name_cache()
        name = _kr_name_cache.get(pure_code, "")
        if name:
            result["name"] = name
        result["market"] = "KR"
    else:
        # 미국 주식: yfinance
        try:
            import yfinance as yf
            ticker = yf.Ticker(symbol)
            info = ticker.info or {}
            result["name"] = info.get("shortName") or info.get("longName") or symbol
            result["sector"] = info.get("sector", "")
            result["industry"] = info.get("industry", "")
            result["market_cap"] = info.get("marketCap", 0)
        except Exception:
            # 하드코딩 폴백 (주요 미국 종목)
            _US_NAMES = {
                "AAPL": "Apple", "MSFT": "Microsoft", "GOOGL": "Alphabet",
                "AMZN": "Amazon", "NVDA": "NVIDIA", "META": "Meta Platforms",
                "TSLA": "Tesla", "SPY": "S&P 500 ETF", "QQQ": "NASDAQ 100 ETF",
                "DIS": "Walt Disney", "BLK": "BlackRock", "DIA": "Dow Jones ETF",
                "ARKK": "ARK Innovation", "SMCI": "Super Micro", "ENPH": "Enphase Energy",
                "RIVN": "Rivian", "CRM": "Salesforce", "AMD": "AMD",
                "INTC": "Intel", "SOXX": "Semiconductor ETF", "XLK": "Tech ETF",
                "XLE": "Energy ETF", "XLF": "Financial ETF", "XLV": "Healthcare ETF",
                "NFLX": "Netflix", "BABA": "Alibaba", "JPM": "JPMorgan Chase",
                "V": "Visa", "MA": "Mastercard", "BAC": "Bank of America",
                "WMT": "Walmart", "PG": "Procter & Gamble", "JNJ": "Johnson & Johnson",
                "UNH": "UnitedHealth", "HD": "Home Depot", "COST": "Costco",
                "AVGO": "Broadcom", "ADBE": "Adobe", "COP": "ConocoPhillips",
                "CVX": "Chevron", "XOM": "ExxonMobil", "PFE": "Pfizer",
                "MRK": "Merck", "ABBV": "AbbVie", "LLY": "Eli Lilly",
                "CSCO": "Cisco", "ORCL": "Oracle", "IBM": "IBM",
                "GS": "Goldman Sachs", "MS": "Morgan Stanley",
            }
            result["name"] = _US_NAMES.get(symbol, symbol)
        result["market"] = "US"

    return result


@app.route("/api/activity")
def api_activity():
    """
    봇 활동 로그 조회

    실시간 활동 피드에 표시할 최근 봇 활동 목록을 반환합니다.
    (분석 시작, 신호 발견, 매수/매도 체결, 리스크 체크 등)
    """
    with _activity_log_lock:
        return jsonify(list(_activity_log))


@app.route("/api/trades/recent")
def api_trades_recent():
    """
    PaperExecutor의 메모리 내 최근 거래 이력 직접 반환

    DB 기반 /api/trades와 달리 PaperExecutor.trade_history를 직접 읽어서
    실시간으로 체결된 모의매매 거래를 즉시 반환합니다.
    """
    if not bot_instance or not hasattr(bot_instance.executor, 'trade_history'):
        return jsonify([])

    trades = bot_instance.executor.trade_history[-50:]  # 최근 50건
    result = []
    for t in trades:
        sym = t.get("symbol", "")
        result.append({
            "order_id": t.get("order_id", ""),
            "symbol": sym,
            "name": get_stock_display_name(sym),
            "side": t.get("side", "").upper(),  # ★ 대문자 통일
            "quantity": t.get("quantity", 0),
            "price": t.get("price", 0),
            "total": t.get("total", 0),
            "strategy": t.get("strategy", ""),
            "timestamp": t.get("timestamp", "").isoformat()
                if hasattr(t.get("timestamp", ""), "isoformat")
                else str(t.get("timestamp", "")),
        })
    return jsonify(result)


@app.route("/api/stock/name")
def api_stock_name():
    """
    종목 코드 → 표시명 변환 API

    Parameters:
        symbol: 종목 코드 (예: "005930.KS", "AAPL")
    Returns:
        { "symbol": "005930.KS", "name": "삼성전자 (005930)", "market": "KR" }
    """
    symbol = request.args.get("symbol", "").strip()
    if not symbol:
        return jsonify({"error": "symbol required"}), 400

    display_name = get_stock_display_name(symbol)
    market = detect_market(symbol)
    return jsonify({"symbol": symbol, "name": display_name, "market": market})


@app.route("/api/stock/news")
def api_stock_news():
    """
    종목 관련 뉴스 + AI 감성 분석 API

    Google News RSS에서 뉴스를 수집하고,
    LLM(Ollama/Gemma4 → OpenAI → Anthropic → 규칙기반)으로 감성 분석을 수행합니다.

    Parameters:
        symbol: 종목 코드 (예: "AAPL", "005930.KS")
        name: 종목명 (선택, 검색 품질 향상)
    """
    symbol = request.args.get("symbol", "").strip()
    name = request.args.get("name", "").strip()

    if not symbol:
        return jsonify({"error": "symbol required"}), 400

    is_kr = is_kr_stock(symbol)

    # 종목명이 없으면 캐시에서 가져오기
    if not name or name == symbol:
        name = get_stock_display_name(symbol)

    try:
        from analyzers.news_llm import get_news_with_analysis
        result = get_news_with_analysis(
            symbol=symbol, name=name, is_kr=is_kr, lang="ko"
        )
        return jsonify(result)
    except Exception as e:
        logger.error(f"[뉴스] 오류: {e}")
        return jsonify({"error": str(e), "news": [], "ai_summary": None})


@app.route("/api/dart")
def api_dart():
    """
    DART 전자공시 API

    최근 공시를 가져와 호재/악재를 분류합니다.
    DART API 키가 config에 있어야 동작합니다.

    쿼리 파라미터:
        days (int): 조회 기간 (기본 7일)

    Returns:
        { disclosures, summary, positive_count, negative_count, ... }
    """
    days = request.args.get("days", 7, type=int)
    try:
        from collectors.dart import DARTCollector
        api_key = current_settings.get("dart_api_key", "")
        collector = DARTCollector(api_key=api_key)

        # 관심 종목 중 한국 종목만 필터
        kr_symbols = [s for s in current_settings.get("watchlist", [])
                      if s.endswith(".KS") or s.endswith(".KQ")]
        result = collector.collect(symbols=kr_symbols if kr_symbols else None, days=days)
        return jsonify(result)
    except Exception as e:
        logger.error(f"[DART] 오류: {e}")
        return jsonify({"error": str(e), "disclosures": [], "summary": "오류 발생"})


@app.route("/api/briefing")
def api_briefing():
    """
    시장 AI 브리핑 API

    DART 공시 + 뉴스 + 거시경제 + 포트폴리오를 취합하여
    종합 시장 브리핑을 생성합니다.

    Returns:
        { html, summary, sentiment, sentiment_score, sections, generated_at }
    """
    try:
        from reporter.market_briefing import MarketBriefing

        briefing = MarketBriefing(current_settings)

        # 1. DART 데이터 수집 (선택)
        dart_data = None
        try:
            from collectors.dart import DARTCollector
            api_key = current_settings.get("dart_api_key", "")
            if api_key:
                dart_collector = DARTCollector(api_key=api_key)
                dart_data = dart_collector.collect(days=3)
        except Exception as e:
            logger.warning(f"[브리핑] DART 수집 실패: {e}")

        # 2. 뉴스 데이터 (간단히 최근 뉴스)
        news_data = None
        try:
            from collectors.news import NewsCollector
            nc = NewsCollector()
            watchlist = current_settings.get("watchlist", ["AAPL", "MSFT"])
            all_news = []
            for sym in watchlist[:3]:  # 상위 3종목만
                articles = nc.collect(sym)
                if isinstance(articles, list):
                    all_news.extend(articles)
                elif isinstance(articles, dict) and "articles" in articles:
                    all_news.extend(articles["articles"])
            if all_news:
                news_data = all_news[:10]
        except Exception as e:
            logger.warning(f"[브리핑] 뉴스 수집 실패: {e}")

        # 3. 거시경제 데이터 (선택)
        macro_data = None
        try:
            from collectors.macro import MacroCollector
            mc = MacroCollector()
            macro_data = mc.collect()
        except Exception as e:
            logger.warning(f"[브리핑] 매크로 수집 실패: {e}")

        # 4. 포트폴리오 데이터
        portfolio_data = {
            "total_equity": bot_status.get("total_equity", 0),
            "cash": bot_status.get("cash", 0),
            "total_pnl": bot_status.get("total_pnl", 0),
            "positions": bot_status.get("positions", {}),
        }

        # 브리핑 생성
        result = briefing.generate(
            dart_data=dart_data,
            news_data=news_data,
            macro_data=macro_data,
            portfolio_data=portfolio_data,
        )
        return jsonify(result)

    except Exception as e:
        logger.error(f"[브리핑] 생성 실패: {e}")
        return jsonify({"error": str(e), "html": "", "summary": "브리핑 생성 실패"})


@app.route("/api/healthcheck")
def api_healthcheck():
    """
    봇 헬스체크 API

    봇 프로세스, DB 연결, 분석 주기, 디스크 사용량 등을 점검합니다.

    Returns:
        { status, checks, healthy_count, warning_count, critical_count }
    """
    try:
        from dashboard.healthcheck import HealthChecker

        with DatabaseManager() as db:
            checker = HealthChecker(bot_instance=bot_instance, db=db)
            result = checker.check_all()
        return jsonify(result)
    except Exception as e:
        logger.error(f"[헬스체크] 실패: {e}")
        return jsonify({"status": "critical", "error": str(e), "checks": []})


@app.route("/api/report/weekly", methods=["POST"])
def api_weekly_report():
    """
    주간/월간 보고서 생성 API

    쿼리 파라미터:
        period: "weekly" 또는 "monthly" (기본 weekly)
    """
    data = request.get_json() or {}
    period = data.get("period", "weekly")

    try:
        from reporter.weekly_report import WeeklyReportGenerator

        with DatabaseManager() as db:
            gen = WeeklyReportGenerator(db=db, report_dir="reports")
            capital = current_settings.get("capital", 100000)
            filepath = gen.generate(period=period, capital=capital)

        if filepath:
            filename = os.path.basename(filepath)
            return jsonify({"success": True, "filename": filename})
        else:
            return jsonify({"success": False, "error": "보고서 생성 실패"})

    except Exception as e:
        logger.error(f"[보고서] 생성 실패: {e}")
        return jsonify({"success": False, "error": str(e)})


@app.route("/api/safety")
def api_safety():
    """
    안전장치 상태 API

    킬 스위치, 일일 손익, 연속 손실 등 안전장치 상태를 반환합니다.
    """
    global bot_instance
    if bot_instance and hasattr(bot_instance, 'safety'):
        return jsonify(bot_instance.safety.get_status())
    return jsonify({
        "kill_switch": False, "daily_trades": 0,
        "daily_pnl": 0, "consecutive_losses": 0,
        "paper_mode": True, "message": "봇이 실행 중이 아닙니다"
    })


@app.route("/api/safety/kill", methods=["POST"])
def api_kill_switch():
    """
    킬 스위치 토글 API

    모든 신규 주문을 즉시 차단하거나 해제합니다.
    """
    global bot_instance
    data = request.get_json() or {}
    action = data.get("action", "activate")

    if not bot_instance or not hasattr(bot_instance, 'safety'):
        return jsonify({"error": "봇이 실행 중이 아닙니다"}), 400

    if action == "activate":
        reason = data.get("reason", "대시보드에서 수동 활성화")
        bot_instance.safety.activate_kill_switch(reason)
        return jsonify({"success": True, "kill_switch": True, "reason": reason})
    elif action == "deactivate":
        bot_instance.safety.deactivate_kill_switch()
        return jsonify({"success": True, "kill_switch": False})
    else:
        return jsonify({"error": "action: activate 또는 deactivate"}), 400


@app.route("/api/discovery/status")
def api_discovery_status():
    """
    종목 자동 발굴 상태 API

    발굴 활성화 여부, 현재 발굴된 종목 목록, 다음 발굴까지 남은 사이클 등을 반환합니다.
    """
    if bot_instance and hasattr(bot_instance, 'get_discovery_status'):
        status = bot_instance.get_discovery_status()
        # 종목명 추가
        for sym in status.get("discovered_us", []):
            pass  # US는 티커가 곧 이름
        kr_names = []
        for sym in status.get("discovered_kr", []):
            kr_names.append({
                "symbol": sym,
                "name": get_stock_display_name(sym),
            })
        status["discovered_kr_details"] = kr_names
        return jsonify(status)

    return jsonify({
        "enabled": current_settings.get("discovery_enabled", True),
        "discovered_us": [],
        "discovered_kr": [],
        "total_discovered": 0,
        "message": "봇이 실행 중이 아닙니다"
    })


@app.route("/api/discovery/trigger", methods=["POST"])
def api_discovery_trigger():
    """
    수동 종목 발굴 트리거

    봇이 실행 중일 때 즉시 발굴을 실행합니다.
    """
    if not bot_instance or not bot_status["running"]:
        return jsonify({"error": "봇이 실행 중이 아닙니다"}), 400

    try:
        _add_activity("analyzing", "🔍 수동 종목 발굴 시작...", "info")
        threading.Thread(
            target=_run_manual_discovery,
            daemon=True
        ).start()
        return jsonify({"success": True, "message": "발굴을 시작했습니다"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def _run_manual_discovery():
    """수동 발굴 백그라운드 실행"""
    try:
        bot_instance._run_discovery()
        disc = bot_instance.get_discovery_status()
        _add_activity(
            "analyzing",
            f"수동 발굴 완료: US {len(disc['discovered_us'])}개, "
            f"KR {len(disc['discovered_kr'])}개",
            "success"
        )
        # 프론트엔드용 이름 정보 추가
        disc["discovered_us_details"] = []
        for sym in disc.get("discovered_us", []):
            us_name = sym
            try:
                info = _get_stock_info(sym)
                us_name = info.get("name", sym)
            except Exception:
                pass
            disc["discovered_us_details"].append({"symbol": sym, "name": us_name})
        disc["discovered_kr_details"] = []
        for sym in disc.get("discovered_kr", []):
            disc["discovered_kr_details"].append({
                "symbol": sym, "name": get_stock_display_name(sym)
            })
        socketio.emit("discovery_update", disc)
    except Exception as e:
        logger.error(f"[발굴] 수동 발굴 실패: {e}")
        _add_activity("analyzing", f"발굴 실패: {str(e)[:50]}", "danger")


@app.route("/api/discord/test", methods=["POST"])
def api_discord_test():
    """
    디스코드 웹훅 연결 테스트

    프론트엔드에서 입력한 웹훅 URL로 테스트 메시지를 보냅니다.
    """
    data = request.get_json() or {}
    webhook_url = data.get("webhook_url", "").strip()

    if not webhook_url:
        return jsonify({"error": "Webhook URL required"}), 400

    if not webhook_url.startswith("https://discord.com/api/webhooks/"):
        return jsonify({"error": "Invalid Discord webhook URL format"}), 400

    try:
        from notifier.discord_webhook import DiscordNotifier
        notifier = DiscordNotifier(webhook_url=webhook_url)
        success = notifier.test_connection()

        if success:
            return jsonify({"success": True})
        else:
            return jsonify({"success": False, "error": "Failed to send test message"}), 400

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# ═══════════════════════════════════════════════════════════════════════════
# 디스코드 봇 (양방향 명령) API
# ═══════════════════════════════════════════════════════════════════════════

def _discord_start_bot_callback() -> dict:
    """
    디스코드 봇에서 호출하는 봇 시작 콜백

    Flask request 컨텍스트 없이 동작합니다.
    api_start_bot()과 동일한 로직을 수행합니다.
    """
    global bot_instance, bot_thread

    if not _bot_lock.acquire(blocking=False):
        return {"error": "다른 작업이 진행 중입니다"}

    try:
        if bot_status["running"]:
            return {"error": "Bot is already running"}

        from config.settings import Settings, CapitalConfig, RiskConfig, DiscoveryConfig
        settings = Settings(
            capital=CapitalConfig(
                total_capital=current_settings["capital"],
                currency=current_settings["currency"]
            ),
            risk=RiskConfig(
                risk_per_trade=current_settings["risk_per_trade"],
                max_position_size=current_settings["max_position_size"],
                max_daily_loss=current_settings["max_daily_loss"],
                max_drawdown=current_settings["max_drawdown"],
                stop_loss_atr_multiplier=current_settings["stop_loss_atr_multiplier"],
                risk_reward_ratio=current_settings["risk_reward_ratio"],
                sizing_method=current_settings["sizing_method"],
                kelly_fraction=current_settings["kelly_fraction"],
            )
        )
        settings.discovery = DiscoveryConfig(
            enabled=current_settings.get("discovery_enabled", True),
            cycle_multiplier=current_settings.get("discovery_cycle_multiplier", 4),
            max_discovered_per_market=current_settings.get("discovery_max_per_market", 10),
            max_total_watchlist=current_settings.get("discovery_max_watchlist", 35),
            include_market_movers=current_settings.get("discovery_include_movers", True),
        )

        from run_bot import QuantBot
        bot_instance = QuantBot(
            settings=settings,
            broker=current_settings["broker"],
            live=current_settings["live_mode"]
        )

        bot_status["running"] = True
        bot_status["mode"] = current_settings["broker"]
        bot_status["live"] = current_settings["live_mode"]
        bot_status["started_at"] = datetime.now().isoformat()
        bot_status["total_equity"] = current_settings["capital"]
        bot_status["cash"] = current_settings["capital"]

        bot_thread = threading.Thread(target=_run_bot_thread, daemon=True)
        bot_thread.start()

        logger.info("[디스코드] 봇 시작 명령 실행")
        return {"success": True}

    except Exception as e:
        logger.error(f"[디스코드] 봇 시작 실패: {e}")
        bot_status["running"] = False
        return {"error": str(e)}
    finally:
        _bot_lock.release()


def _discord_stop_bot_callback() -> dict:
    """디스코드 봇에서 호출하는 봇 중지 콜백"""
    global bot_instance

    if not _bot_lock.acquire(blocking=False):
        return {"error": "다른 작업이 진행 중입니다"}

    try:
        if not bot_status["running"]:
            return {"error": "Bot is not running"}

        if bot_instance:
            bot_instance.stop()
            bot_instance = None

        bot_status["running"] = False
        _add_activity("stop", "봇이 중지되었습니다 (Discord)", "warning")
        logger.info("[디스코드] 봇 중지 명령 실행")
        return {"success": True}

    except Exception as e:
        return {"error": str(e)}
    finally:
        _bot_lock.release()


def _start_discord_bot():
    """디스코드 봇 인스턴스 생성 및 시작"""
    global discord_bot_instance

    token = current_settings.get("discord_bot_token", "").strip()
    if not token:
        logger.info("[Discord Bot] 토큰 미설정 — 봇 비활성화")
        return False

    # 이미 실행 중이면 중지 후 재시작
    if discord_bot_instance:
        discord_bot_instance.stop()
        discord_bot_instance = None

    try:
        from notifier.discord_bot import QuantBotDiscord

        channel_id_str = current_settings.get("discord_bot_channel_id", "").strip()
        channel_id = int(channel_id_str) if channel_id_str else None

        discord_bot_instance = QuantBotDiscord(
            token=token,
            allowed_channel_id=channel_id,
        )

        # 콜백 연결: 디스코드 봇이 대시보드 상태에 접근할 수 있도록
        discord_bot_instance.set_callbacks(
            get_status=lambda: bot_status,
            get_settings=lambda: current_settings,
            get_bot_instance=lambda: bot_instance,
            start_bot=_discord_start_bot_callback,
            stop_bot=_discord_stop_bot_callback,
            get_db=lambda: DatabaseManager(),
        )

        discord_bot_instance.start()
        logger.info("[Discord Bot] 시작됨")
        return True

    except ImportError:
        logger.warning("[Discord Bot] discord.py 미설치 — pip install discord.py")
        return False
    except Exception as e:
        logger.error(f"[Discord Bot] 시작 실패: {e}")
        return False


def _stop_discord_bot():
    """디스코드 봇 중지"""
    global discord_bot_instance
    if discord_bot_instance:
        discord_bot_instance.stop()
        discord_bot_instance = None
        logger.info("[Discord Bot] 중지됨")


@app.route("/api/discord/bot/start", methods=["POST"])
def api_discord_bot_start():
    """디스코드 봇 시작 API"""
    data = request.get_json() or {}
    token = data.get("token", "").strip()
    channel_id = data.get("channel_id", "").strip()

    if token:
        current_settings["discord_bot_token"] = token
    if channel_id:
        current_settings["discord_bot_channel_id"] = channel_id

    if not current_settings.get("discord_bot_token"):
        return jsonify({"error": "봇 토큰이 필요합니다"}), 400

    _save_settings_to_file()

    success = _start_discord_bot()
    if success:
        return jsonify({"success": True, "message": "디스코드 봇이 시작되었습니다"})
    else:
        return jsonify({"error": "디스코드 봇 시작 실패 (토큰 확인 또는 discord.py 설치 필요)"}), 500


@app.route("/api/discord/bot/stop", methods=["POST"])
def api_discord_bot_stop():
    """디스코드 봇 중지 API"""
    _stop_discord_bot()
    return jsonify({"success": True, "message": "디스코드 봇이 중지되었습니다"})


@app.route("/api/discord/bot/status")
def api_discord_bot_status():
    """디스코드 봇 상태 조회 API"""
    if discord_bot_instance:
        return jsonify(discord_bot_instance.status_summary)
    return jsonify({
        "running": False, "connected": False,
        "username": None, "guilds": 0,
    })


@app.route("/api/bot/reset", methods=["POST"])
def api_reset_bot():
    """
    봇 데이터 초기화 API

    모든 포지션, 거래 이력, 자산 기록을 삭제하고
    초기 자본금 상태로 되돌립니다.

    ⚠️ 봇이 실행 중이면 먼저 중지해야 합니다.
    ⚠️ 이 작업은 되돌릴 수 없습니다.
    """
    global bot_instance, _last_trade_count

    # 봇이 실행 중이면 거부
    if bot_status["running"]:
        return jsonify({
            "error": "봇이 실행 중입니다. 먼저 봇을 중지한 후 초기화하세요."
        }), 400

    try:
        # DB 데이터 삭제
        with DatabaseManager() as reset_db:
            deleted = reset_db.reset_all_data()
        logger.info(f"[대시보드] DB 초기화 완료: {deleted}")

        # 메모리 상태 초기화
        with _trade_count_lock:
            _last_trade_count = 0

        # 봇 인스턴스의 메모리 데이터도 초기화
        if bot_instance and hasattr(bot_instance, 'executor'):
            executor = bot_instance.executor
            with executor._lock:
                executor.positions.clear()
                executor.trade_history.clear()
                executor.cash = executor.initial_capital
                executor.orders.clear()

        # 대시보드 상태 초기화
        bot_status["total_equity"] = 0
        bot_status["cash"] = 0
        bot_status["positions"] = {}
        bot_status["daily_pnl"] = 0
        bot_status["total_pnl"] = 0
        bot_status["total_trades"] = 0
        bot_status["win_rate"] = 0
        bot_status["signals_today"] = []

        _add_activity("reset", "봇 데이터가 초기화되었습니다", "warning")

        # 설정에서 초기 자본금 읽기
        capital = float(current_settings.get("capital", 10_000_000))

        return jsonify({
            "success": True,
            "message": f"초기화 완료. 자본금 {capital:,.0f}원으로 리셋됩니다.",
            "deleted": deleted
        })

    except Exception as e:
        logger.error(f"[대시보드] 초기화 실패: {e}")
        return jsonify({"error": str(e)}), 500


# =============================================================================
# WebSocket 이벤트
# =============================================================================

@socketio.on("connect")
def handle_connect(auth=None):
    """
    클라이언트 연결 시 현재 상태 전송

    F5 새로고침이나 네트워크 끊김 후 재연결 시에도 호출됩니다.
    재연결된 클라이언트에게 최신 상태를 즉시 전송하여
    빈 화면 / 이전 데이터 표시 문제를 방지합니다.

    ★ auth 파라미터: Flask-SocketIO >= 5.x에서 connect 이벤트에
       인증 데이터를 전달합니다. 사용하지 않더라도 받아야
       TypeError 방지됩니다.
    """
    try:
        emit("status_update", bot_status)
        emit("settings_update", current_settings)
    except Exception as e:
        logger.warning(f"[WebSocket] 연결 시 초기 데이터 전송 실패: {e}")
    logger.info(f"[WebSocket] 클라이언트 연결됨 (sid: {request.sid})")


@socketio.on("disconnect")
def handle_disconnect():
    """
    클라이언트 연결 해제 핸들러

    F5 새로고침, 탭 닫기, 네트워크 끊김 등으로 발생합니다.
    연결 해제 시 리소스 정리 및 로그를 남깁니다.
    """
    logger.info(f"[WebSocket] 클라이언트 연결 해제 (sid: {request.sid})")


@socketio.on("request_status")
def handle_request_status():
    """클라이언트가 상태 요청"""
    emit("status_update", bot_status)


# =============================================================================
# 일일 보고서 생성
# =============================================================================

def _generate_daily_report() -> Optional[str]:
    """
    현재 봇 상태를 기반으로 일일 거래 보고서를 생성합니다.

    [호출 시점]
    1. 봇 중지(Stop) 시 자동 호출 → 당일 거래 내역 스냅샷을 HTML로 저장
    2. /api/report/generate 엔드포인트 → 수동 보고서 생성 버튼

    [데이터 수집 과정]
    - bot_instance.executor.trade_history → 거래 내역 (PaperExecutor가 기록)
    - bot_instance.executor.get_positions() → 현재 보유 포지션
    - bot_instance.executor.get_account() → 계좌 정보 (총자산, 현금)
    - bot_status["signals_today"] → 당일 매매 신호

    Returns:
        str: 생성된 보고서 파일 경로, 실패 시 None
    """
    global bot_instance

    if not bot_instance:
        logger.warning("[보고서] bot_instance가 없어 보고서 생성 불가")
        return None

    try:
        # ── 1. 거래 내역 수집 ──
        trades = []
        if hasattr(bot_instance.executor, 'trade_history'):
            for t in bot_instance.executor.trade_history:
                sym = t.get("symbol", "")
                trades.append({
                    "symbol": sym,
                    "name": get_stock_display_name(sym),
                    # ★ side를 대문자로 통일: OrderSide.BUY.value="buy"(소문자)
                    # 보고서에서 "BUY"/"SELL" 대문자로 비교하므로 .upper() 필수
                    "side": t.get("side", "").upper(),
                    "quantity": t.get("quantity", 0),
                    "price": t.get("price", 0),
                    "total": t.get("total", 0),
                    "strategy": t.get("strategy", ""),
                    "timestamp": t.get("timestamp", ""),
                    # ★ in-memory trade_history는 "realized_pnl" 키 사용
                    # (paper_executor.py가 "realized_pnl"로 저장하므로)
                    "pnl": t.get("realized_pnl", t.get("pnl", 0)),
                })

        # ── 2. 포지션 수집 ──
        positions = []
        try:
            pos_list = bot_instance.executor.get_positions()
            for p in pos_list:
                # ★ market_value는 KRW 환산값 (paper_executor.get_positions에서 to_krw 적용)
                # current_price는 native 통화이므로 평가액 계산에 직접 쓰면 안됨
                positions.append({
                    "symbol": p.symbol,
                    "name": get_stock_display_name(p.symbol),
                    "shares": p.quantity,
                    "avg_price": p.avg_price,         # native 통화
                    "current_price": p.current_price, # native 통화
                    "market_value": p.market_value,   # ★ KRW 환산
                    "pnl": p.unrealized_pnl,           # KRW 환산
                    "pnl_pct": p.unrealized_pnl_pct,
                })
        except Exception as e:
            logger.warning(f"[보고서] 포지션 수집 오류: {e}")

        # ── 3. 계좌 정보 수집 ──
        account_info = {}
        try:
            account = bot_instance.executor.get_account()
            # ★ positions_value는 get_account()에서 이미 KRW 환산됨
            account_info = {
                "total_equity": account.total_equity,
                "cash": account.cash,
                "positions_value": account.positions_value,
            }
        except Exception as e:
            logger.warning(f"[보고서] 계좌 정보 수집 오류: {e}")

        # ── 4. 매매 신호 수집 ──
        signals = bot_status.get("signals_today", [])

        # ── 5. equity history 수집 (DB에서) ──
        equity_history = []
        try:
            if hasattr(bot_instance, 'db') and bot_instance.db:
                eq_data = bot_instance.db.get_equity_history(days=90)
                equity_history = [
                    {"date": e["timestamp"][:10], "equity": e["total_equity"]}
                    for e in eq_data
                ]
        except Exception:
            pass

        # ── 6. 보고서 생성 ──
        report_path = _report_generator.generate(
            trades=trades,
            positions=positions,
            account_info=account_info,
            signals=signals,
            initial_capital=current_settings.get("capital", 10_000_000),
            currency="KRW",
            news_summary="",  # 향후 LLM 뉴스 요약 연동 가능
            equity_history=equity_history,
        )

        logger.info(f"[보고서] 일일 보고서 생성 완료: {report_path}")
        return report_path

    except Exception as e:
        logger.error(f"[보고서] 일일 보고서 생성 실패: {e}")
        return None


# =============================================================================
# 백그라운드 작업
# =============================================================================

def _run_bot_thread():
    """
    봇을 별도 스레드에서 실행

    기본 start()는 스케줄만 설정하고 대기하는데, 대시보드에서는:
    1. 즉시 1회 분석을 실행하여 사용자에게 빠른 피드백 제공
    2. analysis_interval 설정에 따른 반복 분석 등록
    """
    global bot_instance
    try:
        if bot_instance:
            # 브로커 연결
            if not bot_instance.executor.connect():
                logger.error("[봇 스레드] 브로커 연결 실패")
                bot_status["running"] = False
                return

            # ── ★ 거래 카운터를 DB 복원된 거래 수에 맞춤 ──
            # connect() → _restore_from_db()로 과거 trade_history가 메모리에 로드됨
            # 카운터를 이 수에 맞추지 않으면, _status_broadcaster가
            # DB 복원된 과거 거래를 전부 "새 거래"로 인식하여
            # "매수 체결! 매도 체결!" 토스트 알림을 쏟아냄
            global _last_trade_count
            if hasattr(bot_instance.executor, 'trade_history'):
                restored_count = len(bot_instance.executor.trade_history)
                with _trade_count_lock:
                    _last_trade_count = restored_count
                logger.info(
                    f"[봇 스레드] 거래 카운터 동기화: {restored_count}건 "
                    f"(DB 복원분 스킵 → 새 거래만 알림)"
                )

            # ── 최근 신호 복원: DB에서 오늘자 신호를 메모리로 로드 ──
            # bot_status["signals_today"]는 메모리에만 있어 재시작 시 사라짐.
            # DB의 signals 테이블에서 오늘자 신호를 가져와 UI에 표시되도록 복원.
            try:
                if hasattr(bot_instance, 'db') and bot_instance.db:
                    today_str = datetime.now().strftime("%Y-%m-%d")
                    cursor = bot_instance.db.conn.execute(
                        "SELECT timestamp, symbol, signal_type, confidence, score, "
                        "components_json, reasons_json "
                        "FROM signals WHERE timestamp LIKE ? "
                        "ORDER BY timestamp DESC LIMIT ?",
                        (f"{today_str}%", _dash_cfg.signals_log_max)
                    )
                    restored_signals = []
                    for row in cursor.fetchall():
                        # 종목 정보 (이름/시장)
                        sym = row["symbol"]
                        info = _get_stock_info(sym)
                        try:
                            reasons = json.loads(row["reasons_json"] or "[]")
                        except (json.JSONDecodeError, TypeError):
                            reasons = []
                        restored_signals.append({
                            "symbol": sym,
                            "name": info.get("name", sym),
                            "market": info.get("market", ""),
                            "signal": (row["signal_type"] or "").upper(),
                            "strength": float(row["confidence"] or 0),
                            "score": float(row["score"] or 0),
                            "reasons": reasons,
                            "timestamp": row["timestamp"],
                            # ★ 복원된 신호는 가격/RSI 정보 없음 (DB에 미저장)
                            "price": 0,
                            "rsi": 0,
                        })
                    # 시간순 정렬 (오래된 → 최신, signals_today는 append로 쌓이므로)
                    restored_signals.reverse()
                    bot_status["signals_today"] = restored_signals
                    logger.info(
                        f"[봇 스레드] 신호 복원: {len(restored_signals)}건 "
                        f"(DB의 오늘자 신호)"
                    )
            except Exception as e:
                logger.warning(f"[봇 스레드] 신호 복원 실패: {e}")

            # ── 분석 간격을 설정에서 가져와 스케줄에 적용 ──
            interval_str = current_settings.get("analysis_interval", "1h")
            interval_minutes = _parse_interval(interval_str)

            # 봇 running 상태 설정
            bot_instance.running = True

            logger.info(f"[봇 스레드] 시작 완료 (분석 간격: {interval_minutes}분)")
            _add_activity("start", f"봇 시작됨 (간격: {interval_minutes}분)", "success")

            # ══════════════════════════════════════════════════════
            # 분석 실행 함수 (초기 + 반복에서 공통 사용)
            # ══════════════════════════════════════════════════════
            def _run_one_cycle(cycle_label="분석"):
                """
                미국+한국 시장 1회 분석 실행 + 활동 로그 기록

                APScheduler에 의존하지 않고, 메인 루프의 타이머에서 직접 호출.
                이렇게 하면 스케줄러 import 실패, daemon thread 충돌 등의
                문제를 완전히 우회할 수 있음.

                ★ 종목 발굴은 _analyze_us_market() 내부에서 자체적으로
                  cycle_multiplier 주기마다 실행됩니다.
                  여기서 중복 호출하면 카운터가 2배로 증가하는 버그가 생기므로
                  dashboard에서는 발굴을 직접 호출하지 않습니다.
                """
                _add_activity("analyzing", f"미국 시장 {cycle_label} 중...", "info")
                try:
                    bot_instance._analyze_us_market()
                    _add_activity("analyzing", f"미국 시장 {cycle_label} 완료 ✓", "success")
                except Exception as e:
                    logger.warning(f"[봇 스레드] 미국 분석 오류: {e}")
                    _add_activity("analyzing", f"미국 분석 오류: {str(e)[:60]}", "warning")

                _add_activity("analyzing", f"한국 시장 {cycle_label} 중...", "info")
                try:
                    bot_instance._analyze_kr_market()
                    _add_activity("analyzing", f"한국 시장 {cycle_label} 완료 ✓", "success")
                except Exception as e:
                    logger.warning(f"[봇 스레드] 한국 분석 오류: {e}")
                    _add_activity("analyzing", f"한국 분석 오류: {str(e)[:60]}", "warning")

                # 분석 후 신호/포지션 상태 요약
                try:
                    from datetime import timezone, timedelta as _td
                    kst_now = datetime.now(timezone(+_td(hours=9)))
                    kst_today = kst_now.strftime("%Y-%m-%d")
                    with DatabaseManager() as db:
                        cursor = db.conn.execute(
                            "SELECT COUNT(*) FROM signals WHERE timestamp LIKE ?",
                            (f"{kst_today}%",)
                        )
                        today_signals = cursor.fetchone()[0]
                    positions = bot_instance.executor.get_positions()
                    _add_activity(
                        "analyzing",
                        f"{cycle_label} 완료: 오늘 신호 {today_signals}개, "
                        f"보유 {len(positions)}종목",
                        "success"
                    )
                except Exception as db_e:
                    logger.debug(f"신호 카운트 오류: {db_e}")
                    _add_activity("analyzing", f"{cycle_label} 완료", "success")

            # ══════════════════════════════════════════════════════
            # 즉시 1회 분석 (초기)
            # ══════════════════════════════════════════════════════
            try:
                logger.info("[봇 스레드] 초기 분석 실행 중...")
                _run_one_cycle("초기 분석")
            except Exception as e:
                logger.warning(f"[봇 스레드] 초기 분석 중 오류 (무시): {e}")
                _add_activity("analyzing", f"분석 오류: {str(e)[:50]}", "danger")

            # ══════════════════════════════════════════════════════
            # 메인 루프 (타이머 기반 반복 분석)
            # ══════════════════════════════════════════════════════
            # APScheduler에 의존하지 않는 직접 타이머 방식
            # interval_minutes마다 분석 사이클을 실행
            # 장점: 별도 라이브러리 불필요, daemon 스레드 충돌 없음
            interval_seconds = interval_minutes * 60
            last_analysis_time = time.time()  # 초기 분석 직후
            cycle_count = 0

            logger.info(
                f"[봇 스레드] 반복 분석 타이머 시작: "
                f"{interval_minutes}분({interval_seconds}초) 간격"
            )

            while bot_instance and bot_instance.running:
                time.sleep(1)

                # 설정된 간격이 지났는지 체크
                elapsed = time.time() - last_analysis_time
                if elapsed >= interval_seconds:
                    cycle_count += 1
                    logger.info(
                        f"[봇 스레드] 정기 분석 #{cycle_count} 시작 "
                        f"({interval_minutes}분 경과)"
                    )
                    try:
                        _run_one_cycle(f"정기 분석 #{cycle_count}")
                    except Exception as e:
                        logger.error(f"[봇 스레드] 정기 분석 오류: {e}")
                        _add_activity(
                            "analyzing",
                            f"정기 분석 오류: {str(e)[:50]}",
                            "danger"
                        )
                    last_analysis_time = time.time()

    except Exception as e:
        logger.error(f"[봇 스레드] 오류: {e}")
        bot_status["running"] = False


def _parse_interval(interval_str) -> int:
    """
    분석 간격 문자열을 분(minutes)으로 변환

    지원 형식: "15m", "30m", "1h", "2h", "4h", "1d"
    숫자만 오면 분 단위로 간주
    """
    if isinstance(interval_str, (int, float)):
        return int(interval_str)

    s = str(interval_str).strip().lower()
    if s.endswith("m"):
        return int(s[:-1])
    elif s.endswith("h"):
        return int(s[:-1]) * 60
    elif s.endswith("d"):
        return int(s[:-1]) * 1440
    else:
        try:
            return int(s)
        except ValueError:
            return 60  # 기본값 1시간


def _reschedule_analysis(new_minutes: int):
    """
    실행 중인 봇의 분석 스케줄러 간격을 동적으로 변경

    기존에 등록된 'dashboard_kr_analysis', 'dashboard_us_analysis' 작업을
    제거하고 새로운 간격으로 재등록합니다.
    봇 재시작 없이 설정 변경이 즉시 반영되게 해줍니다.

    Args:
        new_minutes: 새로운 분석 간격 (분 단위)
    """
    global bot_instance
    if not bot_instance or not hasattr(bot_instance, 'scheduler'):
        raise RuntimeError("봇 인스턴스 또는 스케줄러 없음")

    scheduler = bot_instance.scheduler

    # ── 기존 분석 작업 제거 ──
    # APScheduler의 remove_job 또는 커스텀 스케줄러의 제거 메서드 사용
    for job_id in ["dashboard_kr_analysis", "dashboard_us_analysis"]:
        try:
            if hasattr(scheduler, 'remove_job'):
                scheduler.remove_job(job_id)
            elif hasattr(scheduler, 'jobs') and isinstance(scheduler.jobs, dict):
                scheduler.jobs.pop(job_id, None)
        except Exception:
            pass  # 작업이 없으면 무시

    # ── 새 간격으로 재등록 ──
    scheduler.add_interval_job(
        "dashboard_kr_analysis",
        bot_instance._analyze_kr_market,
        minutes=new_minutes
    )
    scheduler.add_interval_job(
        "dashboard_us_analysis",
        bot_instance._analyze_us_market,
        minutes=new_minutes
    )

    logger.info(f"[스케줄러] 분석 간격 동적 변경 완료: {new_minutes}분")


def _refresh_position_prices():
    """
    보유 포지션의 현재가를 가볍게 새로고침 (실시간 PnL 표시용)

    분석 사이클은 5~30분에 1번만 실행되지만, 사용자는 대시보드에서
    실시간 PnL 변화를 보고 싶어합니다. 이 함수는 broadcaster에서
    1분마다 호출되어 보유 종목의 가격만 빠르게 갱신합니다.

    - 한국 주식: pykrx로 일봉 종가 조회 (장중에는 직전 분봉 가격)
    - 미국 주식: yfinance로 1분봉 마지막 가격 조회
    - 봇이 paper 모드일 때만 set_current_price() 호출
      (실거래는 broker가 직접 가격 갱신)

    실패해도 무시 (다음 분석 사이클 또는 다음 호출에서 재시도)
    """
    if not bot_instance or not hasattr(bot_instance, 'executor'):
        return

    executor = bot_instance.executor
    if not hasattr(executor, 'set_current_price'):
        return

    try:
        positions = executor.get_positions()
    except Exception:
        return

    if not positions:
        return

    # 한국/미국 종목 분리
    kr_symbols = []
    us_symbols = []
    for p in positions:
        if is_us_stock(p.symbol):
            us_symbols.append(p.symbol)
        else:
            kr_symbols.append(p.symbol)

    # ── 미국 종목: yfinance로 1분봉 최신 가격 ──
    if us_symbols:
        try:
            import yfinance as yf
            # tickers 일괄 조회 (개별 호출보다 빠름)
            tickers_str = " ".join(us_symbols)
            data = yf.download(
                tickers_str, period="1d", interval="1m",
                progress=False, prepost=True, threads=True
            )
            if not data.empty:
                # 단일 ticker vs 다중 ticker 처리
                if len(us_symbols) == 1:
                    closes = data["Close"].dropna()
                    if len(closes) > 0:
                        executor.set_current_price(us_symbols[0], float(closes.iloc[-1]))
                else:
                    for sym in us_symbols:
                        try:
                            closes = data["Close"][sym].dropna()
                            if len(closes) > 0:
                                executor.set_current_price(sym, float(closes.iloc[-1]))
                        except (KeyError, AttributeError):
                            continue
        except Exception as e:
            logger.debug(f"[가격갱신] 미국 종목 실패: {e}")

    # ── 한국 종목: KIS API 우선, 실패 시 pykrx fallback ──
    if kr_symbols:
        # 1순위: KIS API (실시간 시세, ~1초 지연)
        kis_client = get_kis_price_client()
        kr_remaining = list(kr_symbols)

        if kis_client:
            try:
                prices = kis_client.get_current_prices(kr_symbols)
                for sym, price in prices.items():
                    if price > 0:
                        executor.set_current_price(sym, price)
                        kr_remaining.remove(sym) if sym in kr_remaining else None
                if prices:
                    logger.debug(
                        f"[가격갱신] KIS API로 한국 종목 {len(prices)}개 갱신"
                    )
            except Exception as e:
                logger.debug(f"[가격갱신] KIS API 실패, pykrx로 fallback: {e}")

        # 2순위: pykrx (KIS 미설정 또는 일부 실패한 경우)
        if kr_remaining:
            try:
                from pykrx import stock as pyk_stock
                from datetime import datetime as _dt
                today = _dt.now().strftime("%Y%m%d")
                for sym in kr_remaining:
                    try:
                        code = sym.replace(".KS", "").replace(".KQ", "")
                        df = pyk_stock.get_market_ohlcv(today, today, code)
                        if not df.empty:
                            last_price = float(df["종가"].iloc[-1])
                            if last_price > 0:
                                executor.set_current_price(sym, last_price)
                    except Exception:
                        continue
            except Exception as e:
                logger.debug(f"[가격갱신] 한국 종목 pykrx fallback 실패: {e}")


def _status_broadcaster():
    """
    2초마다 봇 상태를 WebSocket으로 브로드캐스트

    봇이 실행 중이면 executor에서 실시간 포트폴리오 정보를 가져와서
    모든 연결된 클라이언트에게 전송합니다.

    추가 기능:
    - trade_history 길이 변화를 감지하여 새 거래 발생 시
      'trade_executed' 이벤트를 별도로 emit
    - 5분마다 equity 스냅샷을 DB에 저장 (equity curve 추적용)
    """
    global _last_trade_count, _last_snapshot_time, _last_price_refresh

    while True:
        time.sleep(_dash_cfg.broadcast_interval)
        try:
            if bot_instance and bot_status["running"]:
                # ── 보유 포지션 현재가 새로고침 (1분마다) ──
                # 분석 사이클(보통 5~30분) 중간에도 PnL이 갱신되도록
                # 보유 종목만 가볍게 가격을 조회하여 set_current_price() 호출
                _now_price = time.time()
                if (_now_price - _last_price_refresh
                        >= _dash_cfg.position_price_refresh_interval):
                    try:
                        _refresh_position_prices()
                    except Exception as e:
                        logger.debug(f"[브로드캐스터] 포지션 가격 갱신 실패: {e}")
                    _last_price_refresh = _now_price

                # executor에서 현재 상태 가져오기
                account = bot_instance.executor.get_account()
                positions = bot_instance.executor.get_positions()

                bot_status["total_equity"] = float(account.total_equity)
                bot_status["cash"] = float(account.cash)
                bot_status["positions"] = {
                    p.symbol: {
                        "shares": int(p.quantity),
                        "avg_price": float(p.avg_price),
                        "current_price": float(p.current_price),
                        "pnl": float(p.unrealized_pnl),          # KRW 환산
                        "pnl_pct": float(getattr(p, 'unrealized_pnl_pct', 0) or 0),
                        "market_value_krw": float(p.market_value),  # KRW 환산 시가
                        "currency": "USD" if is_us_stock(p.symbol) else "KRW",
                        "name": get_stock_display_name(p.symbol),
                    }
                    for p in positions
                }

                # ── 포지션 유형 메타데이터 DB에서 병합 ──
                try:
                    with DatabaseManager() as _db:
                        for sym in bot_status["positions"]:
                            db_pos = _db.get_position(sym)
                            if db_pos:
                                bot_status["positions"][sym]["position_type"] = db_pos.get("position_type", "")
                                bot_status["positions"][sym]["position_type_en"] = db_pos.get("position_type_en", "")
                                bot_status["positions"][sym]["target_price"] = db_pos.get("target_price", 0)
                                bot_status["positions"][sym]["stop_price"] = db_pos.get("stop_price", 0)
                                bot_status["positions"][sym]["holding_period"] = db_pos.get("holding_period", "")
                                bot_status["positions"][sym]["bought_at"] = db_pos.get("bought_at", "")
                                # ── ExitManager 추적 데이터 (손절/익절/트레일링) ──
                                bot_status["positions"][sym]["entry_atr"] = db_pos.get("entry_atr", 0)
                                bot_status["positions"][sym]["current_stop"] = db_pos.get("current_stop", 0)
                                bot_status["positions"][sym]["highest_since_entry"] = db_pos.get("highest_since_entry", 0)
                                bot_status["positions"][sym]["partial_sold_pct"] = db_pos.get("partial_sold_pct", 0)
                                bot_status["positions"][sym]["target_1"] = db_pos.get("target_1", 0)
                                bot_status["positions"][sym]["target_2"] = db_pos.get("target_2", 0)
                                try:
                                    bot_status["positions"][sym]["reasons"] = json.loads(
                                        db_pos.get("reasons_json", "[]"))
                                except (json.JSONDecodeError, TypeError):
                                    bot_status["positions"][sym]["reasons"] = []
                except Exception:
                    pass  # DB 조회 실패해도 기본 포지션 정보는 유지

                # ★ numpy/bytes 타입 안전 변환 + 0 나누기 방지
                capital = float(current_settings.get("capital", 1) or 1)
                equity = float(account.total_equity)
                bot_status["total_pnl"] = ((equity / capital) - 1) * 100

                # 환율 정보 (프론트엔드에서 USD 가격 표시용)
                try:
                    bot_status["exchange_rate"] = float(get_exchange_rate())
                except Exception:
                    bot_status["exchange_rate"] = 1350.0

                # 수수료 통계
                try:
                    if hasattr(bot_instance.executor, 'get_commission_stats'):
                        bot_status["commission"] = bot_instance.executor.get_commission_stats()
                except Exception:
                    pass

                # 발굴 상태 추가
                try:
                    if hasattr(bot_instance, 'get_discovery_status'):
                        disc = bot_instance.get_discovery_status()
                        bot_status["discovery"] = {
                            "enabled": disc["enabled"],
                            "total": disc["total_discovered"],
                            "us_count": len(disc["discovered_us"]),
                            "kr_count": len(disc["discovered_kr"]),
                        }
                except Exception:
                    pass

                # ── 새 거래 감지 (Lock으로 동시 수정 방지) ──
                new_trades = []
                if hasattr(bot_instance.executor, 'trade_history'):
                    current_count = len(bot_instance.executor.trade_history)
                    with _trade_count_lock:
                        if current_count > _last_trade_count:
                            # Lock 내에서 스냅샷만 빠르게 캡처
                            new_trades = list(bot_instance.executor.trade_history[_last_trade_count:current_count])
                            _last_trade_count = current_count

                # Lock 해제 후 I/O (WebSocket emit은 느릴 수 있으므로 Lock 밖)
                for trade in new_trades:
                    sym = trade.get("symbol", "")
                    display_name = get_stock_display_name(sym)
                    trade_data = {
                        "order_id": trade.get("order_id", ""),
                        "symbol": sym,
                        "name": display_name,
                        # ★ side를 대문자로 통일: OrderSide.BUY.value="buy"(소문자)
                        # 프론트엔드는 "BUY"/"SELL"(대문자)로 비교하므로 .upper() 필수
                        "side": trade.get("side", "").upper(),
                        "quantity": trade.get("quantity", 0),
                        "price": trade.get("price", 0),
                        "total": trade.get("total", 0),
                        "strategy": trade.get("strategy", ""),
                        "timestamp": trade.get("timestamp", datetime.now()).isoformat()
                            if hasattr(trade.get("timestamp", ""), "isoformat")
                            else str(trade.get("timestamp", "")),
                    }
                    socketio.emit("trade_executed", trade_data)

                    side_kr = "매수" if trade_data["side"] == "BUY" else "매도"
                    _add_activity(
                        action=trade_data["side"].lower(),
                        detail=f"{side_kr}: {display_name} "
                               f"{trade_data['quantity']}주 @ "
                               f"{trade_data['price']:,.2f}",
                        level="success" if trade_data["side"] == "BUY" else "warning"
                    )

                if new_trades:
                    bot_status["total_trades"] = _last_trade_count

                # ── equity 스냅샷 저장 (5분마다) ──
                # PaperExecutor에 DB가 연결되어 있으면, 5분 주기로
                # 현재 자산 상태를 equity_history 테이블에 기록
                # → 보고서의 equity curve 차트 + MDD 계산에 사용됨
                now = time.time()
                if now - _last_snapshot_time >= _dash_cfg.equity_snapshot_interval:
                    try:
                        if hasattr(bot_instance.executor, 'save_equity_snapshot'):
                            bot_instance.executor.save_equity_snapshot()
                    except Exception as e:
                        logger.debug(f"[브로드캐스터] equity 스냅샷 저장 실패: {e}")
                    _last_snapshot_time = now

            # WebSocket으로 전체 상태 브로드캐스트
            socketio.emit("status_update", bot_status)
        except Exception as e:
            # ★ 에러를 로그로 남겨야 디버깅 가능
            # 단, broadcaster가 멈추면 안 되므로 try-except는 유지
            logger.warning(f"[브로드캐스터] 상태 브로드캐스트 실패: {e}")


def _run_single_analysis(symbol: str):
    """단일 종목 즉시 분석 (백그라운드)"""
    try:
        from collectors.price_us import PriceCollectorUS
        from collectors.price_kr import PriceCollectorKR
        from analyzers.technical import TechnicalAnalyzer
        from config.settings import TechnicalConfig

        # 시장 판별 (통합 유틸리티 사용)
        market = detect_market(symbol)
        if market == "KR":
            collector = PriceCollectorKR()
        else:
            collector = PriceCollectorUS()

        df = collector.safe_collect(symbol, period="6mo")
        if df is None or df.empty:
            socketio.emit("analysis_result", {
                "symbol": symbol, "error": "No data"
            })
            return

        analyzer = TechnicalAnalyzer(TechnicalConfig())
        df_analyzed = analyzer.calculate_all(df)
        signal = analyzer.generate_signal(df_analyzed)

        # 종목 정보 가져오기
        stock_info = _get_stock_info(symbol)

        # 추가 데이터: 최근 변동률, 거래량
        close = df_analyzed["Close"]
        volume = df_analyzed["Volume"] if "Volume" in df_analyzed.columns else None
        change_1d = ((close.iloc[-1] / close.iloc[-2]) - 1) * 100 if len(close) > 1 else 0
        change_5d = ((close.iloc[-1] / close.iloc[-5]) - 1) * 100 if len(close) > 5 else 0
        change_20d = ((close.iloc[-1] / close.iloc[-20]) - 1) * 100 if len(close) > 20 else 0

        result = {
            "symbol": symbol,
            "name": stock_info.get("name", symbol),
            "market": market,
            "sector": stock_info.get("sector", ""),
            "signal": signal.signal,
            "strength": signal.strength,
            "reasons": signal.reasons,
            "price": float(close.iloc[-1]),
            "change_1d": round(change_1d, 2),
            "change_5d": round(change_5d, 2),
            "change_20d": round(change_20d, 2),
            "volume": int(volume.iloc[-1]) if volume is not None and len(volume) > 0 else 0,
            "high_52w": float(close.tail(252).max()) if len(close) >= 252 else float(close.max()),
            "low_52w": float(close.tail(252).min()) if len(close) >= 252 else float(close.min()),
            "rsi": float(df_analyzed["RSI"].iloc[-1]) if "RSI" in df_analyzed.columns else 0,
            "atr": float(df_analyzed["ATR"].iloc[-1]) if "ATR" in df_analyzed.columns else 0,
            "timestamp": datetime.now().isoformat(),
        }

        # 신호 목록에 추가
        bot_status["signals_today"].append(result)
        if len(bot_status["signals_today"]) > _dash_cfg.signals_log_max:
            bot_status["signals_today"] = bot_status["signals_today"][-_dash_cfg.signals_log_max:]

        socketio.emit("analysis_result", result)
        logger.info(f"[분석] {symbol} ({stock_info.get('name', '')}): "
                    f"{signal.signal} (강도: {signal.strength:.2f})")

    except Exception as e:
        socketio.emit("analysis_result", {
            "symbol": symbol, "error": str(e)
        })






@app.route("/api/server/restart", methods=["POST"])
def api_restart_server():
    """
    서버 재시작 API

    봇이 실행 중이면 먼저 중지한 후 서버 프로세스를 재시작합니다.
    os.execv()를 사용하여 동일한 인자로 프로세스를 교체합니다.
    """
    global bot_instance, bot_thread

    try:
        # 봇 실행 중이면 먼저 중지
        if bot_status["running"] and bot_instance:
            try:
                bot_instance.running = False
                if hasattr(bot_instance, 'scheduler'):
                    bot_instance.scheduler.stop()
                bot_status["running"] = False
                logger.info("[대시보드] 재시작 전 봇 중지 완료")
            except Exception:
                pass

        logger.info("[대시보드] 서버 재시작 요청 수신")

        # 별도 스레드에서 약간의 딜레이 후 재시작 (응답 먼저 보내기 위해)
        def _do_restart():
            time.sleep(1)
            os.execv(sys.executable, [sys.executable] + sys.argv)

        restart_thread = threading.Thread(target=_do_restart, daemon=True)
        restart_thread.start()

        return jsonify({"success": True, "message": "서버가 재시작됩니다..."})

    except Exception as e:
        logger.error(f"[대시보드] 서버 재시작 실패: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/api/kis/status")
def api_kis_status():
    """
    KIS API 연결 상태 확인

    환경변수에 KIS 자격증명이 설정되었는지, 토큰 발급에 성공했는지,
    실시간 시세 조회가 가능한지 종합 진단합니다.
    """
    app_key = os.environ.get("KIS_APP_KEY", "")
    app_secret = os.environ.get("KIS_APP_SECRET", "")
    account = os.environ.get("KIS_ACCOUNT", "")
    paper_str = os.environ.get("KIS_PAPER", "true").lower()
    paper = paper_str in ("true", "1", "yes")

    result = {
        "configured": bool(app_key and app_secret and account),
        "mode": "paper" if paper else "live",
        "connected": False,
        "token_expires": None,
        "account_masked": "",
        "test_price": None,  # 삼성전자 시세로 연결 검증
    }

    if not result["configured"]:
        result["message"] = "환경변수 미설정 (.env에 KIS_APP_KEY/SECRET/ACCOUNT 입력 필요)"
        return jsonify(result)

    # 계좌번호 마스킹 (앞 4자리만)
    if len(account) >= 6:
        result["account_masked"] = account[:4] + "****" + account[-3:]

    # 클라이언트 가져오기 (싱글톤, 토큰 자동 발급)
    client = get_kis_price_client()
    if client:
        result["connected"] = True
        if client.token_expires:
            result["token_expires"] = client.token_expires.isoformat()
        # 삼성전자 가격으로 라이브 검증
        try:
            test_price = client.get_current_price("005930")
            if test_price and test_price > 0:
                result["test_price"] = test_price
                result["message"] = "정상 — 실시간 시세 사용 중"
            else:
                result["message"] = "토큰 발급은 성공했으나 시세 조회 실패"
        except Exception as e:
            result["message"] = f"시세 검증 실패: {e}"
    else:
        result["message"] = "토큰 발급 실패 (자격증명 확인 또는 모의투자/실거래 매칭 확인)"

    return jsonify(result)


@app.route("/api/market/indices")
def api_market_indices():
    """
    주요 시장 지수 조회 API (KOSPI, KOSDAQ, NASDAQ, S&P500, Dow, USD/KRW)

    yfinance를 사용하여 6개 지수의 현재가와 전일 대비 변동률을 반환합니다.
    캐시 1분 — 너무 자주 호출되지 않도록.

    Returns:
        {symbol: {price, change, change_pct}, ...}
    """
    global _market_indices_cache, _market_indices_cache_time

    # 캐시 확인 (60초 TTL)
    now = time.time()
    if _market_indices_cache and (now - _market_indices_cache_time) < 60:
        return jsonify(_market_indices_cache)

    result = {}

    # ── 한국 지수: KIS API 우선 사용 (실시간) ──
    kis_client = get_kis_price_client()
    kis_kr_success = False
    if kis_client:
        try:
            kospi = kis_client.get_index_quote("0001")
            kosdaq = kis_client.get_index_quote("1001")
            if kospi:
                result["^KS11"] = {"name": "KOSPI", **kospi}
            if kosdaq:
                result["^KQ11"] = {"name": "KOSDAQ", **kosdaq}
            kis_kr_success = bool(kospi or kosdaq)
        except Exception as e:
            logger.debug(f"[지수] KIS 조회 실패: {e}")

    # ── 미국 지수 + USD/KRW: yfinance 사용 ──
    # KIS API는 미국 지수 무료 제공 안 됨 (해외 시세는 별도 신청 필요)
    us_indices = {
        "^IXIC": "NASDAQ",
        "^GSPC": "S&P 500",
        "^DJI": "Dow Jones",
        "USDKRW=X": "USD/KRW",
    }
    # KIS가 KR 지수 못 가져왔으면 yfinance로 fallback 추가
    if not kis_kr_success:
        us_indices["^KS11"] = "KOSPI"
        us_indices["^KQ11"] = "KOSDAQ"

    try:
        import yfinance as yf
        data = yf.download(
            list(us_indices.keys()),
            period="2d",
            interval="1d",
            progress=False,
            threads=True,
        )

        if not data.empty and "Close" in data:
            for sym in us_indices:
                try:
                    closes = (
                        data["Close"][sym].dropna()
                        if len(us_indices) > 1
                        else data["Close"].dropna()
                    )
                    if len(closes) >= 2:
                        prev = float(closes.iloc[-2])
                        curr = float(closes.iloc[-1])
                        change = curr - prev
                        change_pct = (change / prev * 100) if prev > 0 else 0
                        result[sym] = {
                            "name": us_indices[sym],
                            "price": curr,
                            "change": change,
                            "change_pct": change_pct,
                        }
                    elif len(closes) == 1:
                        result[sym] = {
                            "name": us_indices[sym],
                            "price": float(closes.iloc[-1]),
                            "change": 0,
                            "change_pct": 0,
                        }
                except (KeyError, AttributeError, IndexError):
                    continue
    except Exception as e:
        logger.warning(f"[지수] yfinance 조회 실패: {e}")

    _market_indices_cache = result
    _market_indices_cache_time = now
    return jsonify(result)


@app.route("/api/market/status")
def api_market_status():
    """
    한국/미국 시장 개장 상태 API

    현재 시각 기준으로 한국(KRX) 및 미국(NYSE/NASDAQ) 시장의
    개장 여부, 남은 시간, 이번 주 일정을 반환합니다.

    한국 시장: 09:00~15:30 KST (평일)
    미국 시장: 09:30~16:00 ET = 23:30~06:00+1 KST (서머타임 기준)

    한국 공휴일 및 미국 공휴일은 별도 체크합니다.
    """
    from datetime import datetime, timedelta
    import calendar

    now_kst = datetime.now()  # 서버 시간 = KST 가정
    weekday = now_kst.weekday()  # 0=월~6=일
    hour = now_kst.hour
    minute = now_kst.minute
    time_minutes = hour * 60 + minute

    # ── 한국 시장 (KRX) ──
    kr_open = 9 * 60  # 09:00
    kr_close = 15 * 60 + 30  # 15:30

    kr_is_open = False
    kr_status = "휴장"
    kr_next = ""

    if weekday < 5:  # 평일
        if time_minutes < kr_open:
            kr_status = "개장 전"
            remaining = kr_open - time_minutes
            kr_next = f"개장까지 {remaining // 60}시간 {remaining % 60}분"
        elif time_minutes < kr_close:
            kr_is_open = True
            kr_status = "거래 중"
            remaining = kr_close - time_minutes
            kr_next = f"폐장까지 {remaining // 60}시간 {remaining % 60}분"
        else:
            kr_status = "폐장"
            # 다음 영업일 개장까지
            if weekday == 4:  # 금요일
                kr_next = "다음 거래일: 월요일 09:00"
            else:
                kr_next = "다음 거래일: 내일 09:00"
    else:
        kr_status = "주말 휴장"
        days_until = 7 - weekday  # 월요일까지 남은 일수
        kr_next = f"다음 거래일: 월요일 09:00 ({days_until}일 후)"

    # ── 미국 시장 (NYSE/NASDAQ) ──
    # ET = KST - 14시간 (서머타임), KST - 13시간 (겨울)
    # 서머타임 (3월~11월) 기준: 개장 23:30 KST, 폐장 06:00 KST (+1일)
    us_open_kst = 23 * 60 + 30   # 23:30 KST
    us_close_kst = 6 * 60        # 06:00 KST (다음날)

    us_is_open = False
    us_status = "휴장"
    us_next = ""

    # 미국 장 시간은 KST 기준 23:30 ~ 다음날 06:00
    if weekday < 5:  # 월~금
        if time_minutes >= us_open_kst:
            # 23:30 이후 = 미국 장 시작 (월~금 밤)
            us_is_open = True
            us_status = "거래 중"
            remaining = (24 * 60 - time_minutes) + us_close_kst
            us_next = f"폐장까지 {remaining // 60}시간 {remaining % 60}분"
        elif time_minutes < us_close_kst and weekday > 0:
            # 00:00~06:00 = 전날 밤 시작된 미국 장 (화~토 새벽)
            us_is_open = True
            us_status = "거래 중"
            remaining = us_close_kst - time_minutes
            us_next = f"폐장까지 {remaining // 60}시간 {remaining % 60}분"
        elif time_minutes < us_open_kst:
            us_status = "개장 전"
            remaining = us_open_kst - time_minutes
            us_next = f"개장까지 {remaining // 60}시간 {remaining % 60}분"
        else:
            us_status = "폐장"
            us_next = "다음 거래일: 오늘 23:30"
    elif weekday == 5:  # 토요일
        if time_minutes < us_close_kst:
            # 금요일 밤 시작된 장 (토요일 새벽)
            us_is_open = True
            us_status = "거래 중"
            remaining = us_close_kst - time_minutes
            us_next = f"폐장까지 {remaining // 60}시간 {remaining % 60}분"
        else:
            us_status = "주말 휴장"
            us_next = "다음 거래일: 월요일 23:30"
    else:  # 일요일
        us_status = "주말 휴장"
        us_next = "다음 거래일: 월요일 23:30"

    # ── 이번 달 거래일 캘린더 ──
    year = now_kst.year
    month = now_kst.month
    today = now_kst.day
    _, days_in_month = calendar.monthrange(year, month)

    cal_days = []
    for d in range(1, days_in_month + 1):
        dt = datetime(year, month, d)
        wd = dt.weekday()
        is_trading = wd < 5  # 주말 제외 (공휴일은 별도 DB 필요)
        cal_days.append({
            "day": d,
            "weekday": ["월","화","수","목","금","토","일"][wd],
            "is_trading": is_trading,
            "is_today": d == today,
            "is_past": d < today,
        })

    return jsonify({
        "server_time": now_kst.strftime("%Y-%m-%d %H:%M:%S"),
        "kr": {
            "name": "한국 (KRX)",
            "is_open": kr_is_open,
            "status": kr_status,
            "next": kr_next,
            "hours": "09:00 ~ 15:30 KST",
        },
        "us": {
            "name": "미국 (NYSE)",
            "is_open": us_is_open,
            "status": us_status,
            "next": us_next,
            "hours": "23:30 ~ 06:00 KST (ET 09:30~16:00)",
        },
        "calendar": {
            "year": year,
            "month": month,
            "month_name": f"{year}년 {month}월",
            "days": cal_days,
        },
    })

def _search_kr_stocks(query: str) -> list:
    """한국 주식 검색 (pykrx 종목 리스트에서 매칭)"""
    results = []
    try:
        from pykrx import stock as pykrx_stock
        # pykrx에서 전체 종목 리스트 가져오기
        # 코스피
        kospi_tickers = pykrx_stock.get_market_ticker_list(market="KOSPI")
        for ticker in kospi_tickers:
            name = pykrx_stock.get_market_ticker_name(ticker)
            if query.upper() in ticker or query in name:
                results.append({
                    "symbol": f"{ticker}.KS",
                    "name": name,
                    "market": "KOSPI",
                    "type": "stock"
                })
                if len(results) >= 10:
                    break

        if len(results) < 10:
            # 코스닥
            kosdaq_tickers = pykrx_stock.get_market_ticker_list(market="KOSDAQ")
            for ticker in kosdaq_tickers:
                name = pykrx_stock.get_market_ticker_name(ticker)
                if query.upper() in ticker or query in name:
                    results.append({
                        "symbol": f"{ticker}.KQ",
                        "name": name,
                        "market": "KOSDAQ",
                        "type": "stock"
                    })
                    if len(results) >= 10:
                        break

    except Exception as e:
        logger.warning(f"[검색] 한국 종목 검색 실패: {e}")

    return results


def _search_us_stocks(query: str) -> list:
    """
    미국 종목 검색 (하드코딩된 주요 종목 + yfinance)

    주요 미국 종목은 사전에 매핑하여 빠르게 검색하고,
    찾지 못하면 yfinance ticker.info를 시도합니다.
    """
    results = []
    query_upper = query.upper()

    # 주요 미국 종목 사전 (빠른 검색용)
    _US_STOCKS = {
        "AAPL": "Apple Inc.", "MSFT": "Microsoft Corp.", "GOOG": "Alphabet Inc.",
        "GOOGL": "Alphabet Inc.", "AMZN": "Amazon.com Inc.", "NVDA": "NVIDIA Corp.",
        "META": "Meta Platforms Inc.", "TSLA": "Tesla Inc.", "BRK.B": "Berkshire Hathaway",
        "UNH": "UnitedHealth Group", "JNJ": "Johnson & Johnson", "JPM": "JPMorgan Chase",
        "V": "Visa Inc.", "PG": "Procter & Gamble", "MA": "Mastercard Inc.",
        "HD": "Home Depot Inc.", "CVX": "Chevron Corp.", "MRK": "Merck & Co.",
        "ABBV": "AbbVie Inc.", "LLY": "Eli Lilly", "PEP": "PepsiCo Inc.",
        "KO": "Coca-Cola Co.", "COST": "Costco Wholesale", "AVGO": "Broadcom Inc.",
        "TMO": "Thermo Fisher", "MCD": "McDonald's Corp.", "WMT": "Walmart Inc.",
        "CSCO": "Cisco Systems", "ACN": "Accenture plc", "ABT": "Abbott Laboratories",
        "DHR": "Danaher Corp.", "ADBE": "Adobe Inc.", "CRM": "Salesforce Inc.",
        "NKE": "Nike Inc.", "TXN": "Texas Instruments", "NEE": "NextEra Energy",
        "PM": "Philip Morris", "UNP": "Union Pacific", "RTX": "RTX Corp.",
        "HON": "Honeywell Intl.", "LOW": "Lowe's Companies", "SPGI": "S&P Global",
        "BA": "Boeing Co.", "INTC": "Intel Corp.", "AMD": "AMD Inc.",
        "QCOM": "Qualcomm Inc.", "CAT": "Caterpillar Inc.", "GS": "Goldman Sachs",
        "MS": "Morgan Stanley", "BLK": "BlackRock Inc.", "SCHW": "Charles Schwab",
        "AMAT": "Applied Materials", "LRCX": "Lam Research", "MU": "Micron Technology",
        "NFLX": "Netflix Inc.", "DIS": "Walt Disney Co.", "PYPL": "PayPal Holdings",
        "XYZ": "Block Inc.", "COIN": "Coinbase Global", "PLTR": "Palantir Technologies",
        "SNOW": "Snowflake Inc.", "UBER": "Uber Technologies", "ABNB": "Airbnb Inc.",
        "RIVN": "Rivian Automotive", "LCID": "Lucid Group", "SOFI": "SoFi Technologies",
        "SPY": "SPDR S&P 500 ETF", "QQQ": "Invesco QQQ Trust", "IWM": "iShares Russell 2000",
        "DIA": "SPDR Dow Jones", "VTI": "Vanguard Total Market",
        "ARKK": "ARK Innovation ETF", "XLF": "Financial Select SPDR",
        "SMCI": "Super Micro Computer", "ENPH": "Enphase Energy",
        "SOXX": "iShares Semiconductor ETF", "XLK": "Technology Select SPDR",
        "XLE": "Energy Select SPDR", "XLV": "Health Care Select SPDR",
    }

    for symbol, name in _US_STOCKS.items():
        if query_upper in symbol or query.lower() in name.lower():
            results.append({
                "symbol": symbol,
                "name": name,
                "market": "US",
                "type": "stock"
            })
            if len(results) >= 10:
                break

    # yfinance 폴백 (사전에 없는 종목)
    if not results:
        try:
            import yfinance as yf
            ticker = yf.Ticker(query_upper)
            info = ticker.info
            if info and info.get("shortName"):
                results.append({
                    "symbol": query_upper,
                    "name": info["shortName"],
                    "market": "US",
                    "type": "stock"
                })
        except Exception:
            pass

    return results


# =============================================================================
# 서버 실행
# =============================================================================

if __name__ == "__main__":
    # ── werkzeug 중복 로그 억제 ──
    # Flask의 werkzeug 서버가 HTTP 요청 로그를 별도로 출력하면
    # quantbot 로거와 겹쳐서 콘솔이 지저분해집니다.
    # WARNING 이상만 표시하여 핵심 에러만 노출합니다.
    import logging as _logging
    _logging.getLogger("werkzeug").setLevel(_logging.WARNING)
    _logging.getLogger("engineio").setLevel(_logging.WARNING)

    logger.info(f"Dashboard starting on http://localhost:5000")

    # ── 상태 브로드캐스터 스레드 시작 ──
    # _status_broadcaster()는 봇 상태(포지션, 잔고, PnL 등)를
    # 주기적으로 WebSocket 클라이언트에게 전송하는 백그라운드 작업.
    # ★ 이 스레드가 없으면 대시보드에 포지션이 표시되지 않음!
    import threading
    broadcast_thread = threading.Thread(
        target=_status_broadcaster,
        daemon=True,  # 메인 프로세스 종료 시 자동 정리
        name="status-broadcaster"
    )
    broadcast_thread.start()
    logger.info("[Dashboard] 상태 브로드캐스터 스레드 시작됨")

    # ── 디스코드 봇 자동 시작 ──
    # 설정에 토큰이 있고 autostart가 켜져있으면 대시보드 시작 시 자동 연결
    if current_settings.get("discord_bot_token") and current_settings.get("discord_bot_autostart", False):
        try:
            _start_discord_bot()
        except Exception as e:
            logger.warning(f"[Discord Bot] 자동 시작 실패: {e}")

    socketio.run(
        app,
        host="0.0.0.0",
        port=5000,
        debug=False,
        allow_unsafe_werkzeug=True,
    )
