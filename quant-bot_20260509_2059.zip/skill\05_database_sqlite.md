# 05. SQLite 데이터베이스 운용

## 배운 것

SQLite는 파일 하나로 작동하는 가벼운 DB이지만,
실전에서 예상치 못한 문제들을 많이 겪었다.

---

## 1. 기본 구조

```python
import sqlite3

class DatabaseManager:
    def __init__(self, db_path="data/quantbot.db"):
        self.db_path = db_path
        self.conn = None
    
    def initialize(self):
        """DB 연결 + 테이블 생성"""
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")  # 동시 읽기 성능 향상
        self._create_tables()
    
    def _create_tables(self):
        """필요한 테이블 자동 생성 (없으면)"""
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                symbol TEXT,
                action TEXT,
                score REAL,
                confidence REAL,
                reasons TEXT
            )
        """)
        self.conn.commit()
```

---

## 2. 테이블 설계 (이 프로젝트)

```
signals          — 매매 신호 기록 (BUY/SELL/HOLD, 점수, 사유)
trades           — 실제/모의 거래 이력 (종목, 방향, 수량, 가격)
positions        — 현재 보유 포지션 (PaperExecutor 상태 영속화)
portfolio_snapshots — 일별 자산 스냅샷 (equity curve용)
equity_history   — 자산 변동 이력
cache            — 가격 데이터 캐시 (API 호출 절감)
```

---

## 3. 겪은 문제들

### 문제 1: DB 손상 (database disk image is malformed)

**증상:**
```
sqlite3.DatabaseError: database disk image is malformed
```

**원인:** 
봇이 데이터를 쓰는 도중 강제 종료되면 DB 파일이 손상됨.
특히 WAL 모드에서 .db-wal, .db-shm 파일이 불일치하면 발생.

**해결:**
```python
# 1. 손상된 DB 백업
import shutil
shutil.copy("data/quantbot.db", "data/quantbot_corrupted_backup.db")

# 2. 새 DB 생성
conn = sqlite3.connect("data/quantbot.db")
# 테이블 재생성...

# 3. 가능하면 백업에서 데이터 복구 시도
try:
    old_conn = sqlite3.connect("data/quantbot_corrupted_backup.db")
    # SELECT로 읽을 수 있는 데이터만 복구
except:
    pass  # 복구 불가능하면 포기
```

**예방책:**
```python
# WAL 모드 사용 (손상 위험 감소)
conn.execute("PRAGMA journal_mode=WAL")

# 쓰기 후 즉시 커밋
conn.execute("INSERT INTO ...")
conn.commit()  # 빼먹지 말 것!
```

### 문제 2: 멀티스레드 접근

**증상:**
```
sqlite3.ProgrammingError: SQLite objects created in a thread 
can only be used in that same thread
```

**해결:**
```python
# 방법 1: check_same_thread=False (간단하지만 동시 쓰기 주의)
conn = sqlite3.connect("data/quantbot.db", check_same_thread=False)

# 방법 2: 스레드마다 별도 연결 (더 안전)
import threading
local = threading.local()

def get_conn():
    if not hasattr(local, 'conn'):
        local.conn = sqlite3.connect("data/quantbot.db")
    return local.conn
```

### 문제 3: UTC vs KST 시간대 ★★★ (이 프로젝트에서 큰 삽질)

**증상:** 봇 시작할 때마다 "오늘 신호 0개"로 표시됨

**원인:**
```sql
-- SQLite의 date('now')는 항상 UTC를 반환한다!
SELECT COUNT(*) FROM signals WHERE date(timestamp) = date('now')
-- 한국시간 2026-05-07 04:00 = UTC 2026-05-06 19:00
-- date('now') = '2026-05-06' (UTC) ≠ 오늘 한국날짜 '2026-05-07'
```

**해결:**
```python
from datetime import datetime, timezone, timedelta

# Python에서 KST 시간 직접 계산
kst = timezone(timedelta(hours=9))
kst_today = datetime.now(kst).strftime("%Y-%m-%d")

# SQL에서 KST 날짜로 필터링
cursor = conn.execute(
    "SELECT COUNT(*) FROM signals WHERE timestamp LIKE ?",
    (f"{kst_today}%",)
)
```

**교훈:** 
DB에 시간을 저장할 때는 항상 타임존을 명시하거나,
저장 시 KST로 통일하고 조회 시도 KST로 비교해야 한다.
SQLite의 date('now')를 한국에서 쓰면 날짜가 하루 밀린다.

---

## 4. DB가 매매 실행을 차단한 사례

**흐름:**
```
분석 → BUY 신호 발생 → log_signal() → _execute_buy()
```

**문제:** `log_signal()`에서 DB 에러 발생 시 예외가 전파되어
`_execute_buy()`까지 도달하지 못함.

**해결:**
```python
# log_signal을 별도 try-except로 감싸서 DB 실패가 매매를 막지 않게
try:
    self.db.log_signal(symbol, action, score, ...)
except Exception as db_err:
    self.logger.warning(f"[DB] 신호 로그 저장 실패 ({symbol}): {db_err}")
    # DB 에러와 무관하게 매매 실행은 계속 진행

# 매수 실행 (위의 DB 에러와 독립적)
if action == "BUY" and confidence > threshold:
    self._execute_buy(symbol, price, ...)
```

**교훈:** 
로깅(부수 효과)이 핵심 로직(매매 실행)을 차단하면 안 된다.
"기록이 안 되어도 거래는 해야 한다" → 방어적 코딩.
