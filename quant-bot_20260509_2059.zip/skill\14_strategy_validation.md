# 14. 전략 검증 (Backtest + Benchmark + Adaptive Threshold)

"이 봇이 정말로 그냥 SPY 사놓는 것보다 나은가?" 라는 질문에 답하는 방법.

---

## 핵심 깨달음

**검증 없는 알고리즘은 그냥 도박입니다.** 봇이 100번 매매해서 수익이 났다고 해도:
- 같은 기간 buy-and-hold가 더 나았다면 → 실패
- 거래비용을 빼면 수익이 사라진다면 → 실패
- 한 종목의 성공이 다른 종목의 실패를 가렸다면 → 실패

이 문서는 **3가지 검증 도구**를 다룹니다:
1. **Buy-and-Hold 벤치마크**: 봇 vs 단순 보유 비교
2. **자동 백테스트 CLI**: 과거 데이터로 전략 시뮬레이션
3. **적응형 임계값**: 시장 체제에 따른 동적 파라미터 조정

---

## 1. Buy-and-Hold 벤치마크

### 핵심 지표

```python
@dataclass
class BenchmarkResult:
    bot_return_pct: float          # 봇 누적 수익률
    benchmark_return_pct: float    # 벤치마크 수익률
    alpha_pct: float               # 알파 = 봇 - 벤치
    information_ratio: float       # 알파 / Tracking Error
    correlation: float             # 봇 vs 벤치 상관계수
    bot_max_dd: float              # 봇 최대낙폭
    benchmark_max_dd: float        # 벤치 최대낙폭
```

### 정보비율 (Information Ratio) 해석

```
IR = (포트폴리오 수익률 - 벤치마크 수익률) / Tracking Error
```

| IR 값 | 평가 |
|-------|------|
| < 0 | 벤치마크 미달 (의미 없음) |
| 0~0.5 | 평균 수준 |
| 0.5~1.0 | 우수 |
| 1.0+ | 매우 우수 (대부분의 헤지펀드도 못 미침) |

### 벤치마크 자동 선택

```python
def pick_benchmark(positions_summary):
    kr_pct = positions_summary.get("KR", 0)
    us_pct = positions_summary.get("US", 0)
    if kr_pct > us_pct * 1.5:
        return "069500.KS", "KODEX 200"   # 한국 시장
    elif us_pct > kr_pct * 1.5:
        return "SPY", "S&P 500"            # 미국 시장
    else:
        return "ACWI", "MSCI All-World"    # 글로벌
```

### 학술적 근거

- **SPIVA Report (S&P)**: S&P 500을 5년 이상 이기는 액티브 펀드는 25% 미만
- **Efficient Market Hypothesis**: 적극적 운용은 평균적으로 시장을 못 이김
- 따라서 **알고리즘은 벤치마크 대비 알파**로 평가해야 함

---

## 2. 자동 백테스트 CLI

### 기본 구조

```python
def run_backtest_with_exits(df, signal, atr_stop_mult=2.0, rr_ratio=2.0):
    """
    ExitManager 통합 백테스트
    
    각 봉마다:
    1. 보유 중이면 ExitManager 청산 체크
    2. 신호 1이면 매수
    3. equity 기록
    """
    em = ExitManager(atr_stop_multiplier=atr_stop_mult, rr_ratio=rr_ratio)
    cash = INITIAL_CAPITAL
    shares = 0
    
    for i, row in enumerate(df.iterrows()):
        price = row["Close"]
        atr = row["ATR"]
        
        if shares > 0:
            decision = em.evaluate(SYMBOL, price)
            if decision.should_exit:
                # 매도 (수수료 0.1% 차감)
                cash += shares * decision.sell_ratio * price * 0.999
                shares -= int(shares * decision.sell_ratio)
        
        if shares == 0 and signal[i] == 1:
            # 매수 (수수료 0.1% 추가)
            qty = int(cash * 0.99 / (price * 1.001))
            cash -= qty * price * 1.001
            shares = qty
            em.register_entry(SYMBOL, price, atr, atr_stop_mult, rr_ratio)
    
    return {"final_equity": cash + shares * price, ...}
```

### 백테스트의 함정 (반드시 피해야 할 것)

#### 1. **Look-ahead Bias (미래 정보 사용)**
```python
# 나쁜 예
signal[i] = 1 if df["Close"][i+1] > df["Close"][i] else 0  # 미래 정보!

# 좋은 예
signal[i] = 1 if df["SMA20"][i] > df["SMA50"][i] else 0  # 그 시점 정보만
```

#### 2. **Survivorship Bias (생존자 편향)**
- 상장폐지된 종목을 데이터에서 제외 → 결과 부풀림
- 해결: 당시 지수 구성 종목 포함 (어렵지만 중요)

#### 3. **Overfitting (과적합)**
```python
# 나쁜 예: 파라미터 100개를 과거 데이터에 맞춤
# → 미래 데이터에서 망함

# 좋은 예: Walk-forward 검증
for train_window, test_window in walk_forward_splits(data, train=2y, test=6mo):
    model = fit(train_window)
    score = test(model, test_window)  # 과적합 여부 검출
```

#### 4. **거래비용 미반영**
```python
# 봇 수익률 +10%, 벤치 +8% → 알파 +2%
# 하지만 봇이 100회 거래 → 수수료 1% × 100 = 100% (말도 안 되는 거래비용)
```

### 등급 시스템

```python
if alpha > 5 and sharpe_diff > 0.2:
    print("🟢 등급 A: 봇이 의미 있게 초과")
elif alpha > -5 and abs(sharpe_diff) < 0.5:
    print("🟡 등급 B: 비슷 → buy-and-hold 권장")
else:
    print("🔴 등급 C: 미달 → 전략 재검토")
```

### CLI 사용 예시

```bash
# 기본: SPY 1년
python scripts/run_backtest.py

# 종목 + 기간 지정
python scripts/run_backtest.py --symbol AAPL --period 2y

# 한국 주식
python scripts/run_backtest.py --symbol 005930.KS --period 1y

# ATR 멀티플라이어 변경
python scripts/run_backtest.py --atr-mult 3.0 --rr 2.5
```

---

## 3. 적응형 임계값 (Adaptive Threshold)

### 왜 고정 임계값이 나쁜가?

기존 코드:
```python
buy_threshold = 0.20    # 모든 시장 상황에서 동일
sell_threshold = -0.20
```

문제:
- VIX < 15 (안정장): 임계값이 너무 높아 매매 기회 놓침
- VIX > 30 (위기장): 임계값이 너무 낮아 가짜 신호로 진입

### VIX 4단계 체제

```python
VIX_LOW = 15.0       # 안정장
VIX_NORMAL = 20.0    # 정상
VIX_ELEVATED = 30.0  # 불안정
                     # VIX > 30: 위기

def classify_volatility(vix):
    if vix < 15: return "low"
    if vix < 20: return "normal"
    if vix < 30: return "elevated"
    return "crisis"
```

### 변동성 배수 적용

```python
vol_multipliers = {
    "low":      0.7,   # 약한 신호도 OK
    "normal":   1.0,   # 표준
    "elevated": 1.5,   # 강한 신호만
    "crisis":   2.5,   # 거의 매매 중지
}

# 적용
buy_threshold = BASE_BUY * vol_multiplier
min_confidence = BASE_MIN_CONF * vol_multiplier
```

### 시장 체제 (Market Regime)

```python
def fetch_market_regime():
    """SPY 200일 MA + 50일 모멘텀으로 판별"""
    if current > ma200 and ma50 > ma200 and momentum > 2%:
        return "bull"
    elif current < ma200 and ma50 < ma200 and momentum < -2%:
        return "bear"
    return "sideways"
```

체제별 보정:
- **Bull**: 매수 임계값 0.9배 (적극적)
- **Bear**: 매수 1.2배, 매도 0.8배, 포지션 0.7배 (보수적)
- **Sideways**: 변경 없음

### 위기장 + Bear 차단

```python
if regime_volatility == "crisis" and regime_market == "bear":
    return "BLOCK_BUY"  # 신규 매수 자체 차단
```

### 학술 자료

- **Whaley (2000)** "The Investor Fear Gauge" — VIX의 변동성 예측력
- **Volatility Box (2025)** — 동적 임계값이 정적 대비 일관되게 우월
- **HMM 2-3 latent states** — 90%+ 정확도로 시장 체제 분류

---

## 통합 워크플로우

```
1. 백테스트로 초기 검증
   python scripts/run_backtest.py --symbol SPY --period 2y
   
2. 알파 < 0이면 전략 재검토
   - 매수 임계값 조정
   - ATR 멀티플라이어 변경
   - 추가 알파 발굴 (섹터 로테이션 등)

3. 알파 > 0이면 모의투자 배포
   - VIX 기반 적응형 임계값 활성화
   - 1~2주 모의투자로 라이브 검증
   
4. 일일 보고서로 지속 모니터링
   - Buy-and-Hold 벤치마크 비교 카드
   - 정보비율 추세 추적
   - MDD 한도 체크 (15% 초과 시 경고)
```

---

## 흔한 실수

### ❌ 백테스트 결과를 라이브 성과와 동일시
백테스트 +20% ≠ 라이브 +20%. 다음 요인으로 큰 차이:
- 슬리피지 (백테스트는 정확한 가격 가정)
- 호가 스프레드
- 시간 지연 (분석 → 주문 사이)
- 부분 체결

### ❌ 단일 기간 백테스트로 결론
2024년 한 해만 백테스트해서 +30%? 다른 해는?
- 2020 (코로나 폭락), 2022 (인플레 위기) 등 다양한 체제 포함 필수
- **최소 5년**, 가능하면 10년+ 권장

### ❌ 임계값을 너무 자주 변경
시장 변화 → 임계값 변경 → 새 시장 변화 → 또 변경...
- 적응형 임계값은 **자동 조정용** (사용자가 손대지 않음)
- 5분 캐시로 고주파 변경 방지

---

## 빠른 진단 체크리스트

봇이 잘 작동하는지 확인하려면:

| 체크 | 합격 기준 |
|------|----------|
| 알파 > 0 | 1년 기준 +2% 이상 |
| 정보비율 > 0.3 | 0.5+면 우수 |
| MDD < 벤치 MDD | 봇이 더 작은 낙폭이어야 의미 있음 |
| 승률 > 50% | 손익비 1.5+ 와 결합 |
| 손익비(Profit Factor) > 1.5 | 1 이하면 손실 누적 |
| 거래비용 < 알파의 50% | 비용이 알파를 다 잡아먹으면 무의미 |
| Walk-forward 일관성 | 다른 기간에서도 비슷한 성과 |

위 7개 중 5개 이상 통과해야 라이브 배포 권장.

---

*핵심: "백테스트 == 미래 보장"이 절대 아니다. 백테스트는 "이 전략이 과거에 안 통했다면 미래에도 안 통할 것"의 필요조건일 뿐, 충분조건이 아니다.*
