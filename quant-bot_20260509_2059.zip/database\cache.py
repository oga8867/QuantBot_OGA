"""
=============================================================================
database/cache.py - SQLite 기반 데이터 캐시 및 거래 기록
=============================================================================

API 호출 결과를 캐싱하고, 거래 기록/포트폴리오 스냅샷을 저장합니다.

테이블 구조:
1. cache        → API 데이터 캐시 (TTL 기반)
2. trades       → 거래 기록 (매수/매도 이력)
3. portfolio_snapshots → 일별 포트폴리오 요약
4. signals      → 매매 신호 로그
5. positions    → 현재 보유 포지션 (실시간)
6. equity_history → 시간별 자산 추적 (차트/MDD용)
=============================================================================
"""

import sqlite3
import json
import os
from typing import Optional, Any, List
from datetime import datetime, timedelta


class DatabaseManager:
    """SQLite 데이터베이스 관리자"""

    def __init__(self, db_path: str = "data/quantbot.db"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path) if os.path.dirname(db_path) else "data", exist_ok=True)
        self.conn = None

    def initialize(self):
        """DB 연결 및 테이블 생성"""
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    # ── Context Manager (with문) 지원 ──
    # DB 연결 누수를 방지: with문 벗어나면 자동으로 close() 호출
    # 사용법:
    #   with DatabaseManager() as db:
    #       trades = db.get_trades()
    #   # ← 여기서 자동 close() (예외 발생 시에도)
    def __enter__(self):
        self.initialize()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False  # 예외를 삼키지 않음

    def close(self):
        """DB 연결 종료"""
        if self.conn:
            self.conn.close()
            self.conn = None

    def _create_tables(self):
        """6개 테이블 생성"""
        c = self.conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS cache (
            key TEXT PRIMARY KEY, value TEXT NOT NULL,
            expires_at TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        c.execute("""CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL, symbol TEXT NOT NULL,
            market TEXT NOT NULL DEFAULT 'US', side TEXT NOT NULL,
            quantity INTEGER NOT NULL, price REAL NOT NULL,
            total_value REAL NOT NULL, strategy TEXT DEFAULT '',
            signal_score REAL DEFAULT 0, status TEXT DEFAULT 'filled',
            order_id TEXT DEFAULT '', notes TEXT DEFAULT '',
            pnl REAL DEFAULT 0)""")
        c.execute("""CREATE TABLE IF NOT EXISTS portfolio_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL UNIQUE, total_value REAL NOT NULL,
            cash REAL NOT NULL, positions_json TEXT DEFAULT '{}',
            daily_return REAL DEFAULT 0, cumulative_return REAL DEFAULT 0,
            max_drawdown REAL DEFAULT 0, notes TEXT DEFAULT '')""")
        c.execute("""CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL, symbol TEXT NOT NULL,
            signal_type TEXT NOT NULL, confidence REAL DEFAULT 0,
            score REAL DEFAULT 0, components_json TEXT DEFAULT '{}',
            reasons_json TEXT DEFAULT '[]', acted_on INTEGER DEFAULT 0)""")
        c.execute("""CREATE TABLE IF NOT EXISTS positions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL UNIQUE, quantity INTEGER NOT NULL,
            avg_price REAL NOT NULL, current_price REAL DEFAULT 0,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
        c.execute("""CREATE TABLE IF NOT EXISTS equity_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL, total_equity REAL NOT NULL,
            cash REAL NOT NULL, positions_value REAL DEFAULT 0,
            daily_pnl REAL DEFAULT 0, cumulative_return REAL DEFAULT 0)""")
        self.conn.commit()

        # ── 기존 DB 마이그레이션: trades 테이블에 pnl 컬럼이 없으면 추가 ──
        # ALTER TABLE은 CREATE TABLE IF NOT EXISTS와 달리
        # 컬럼이 이미 있으면 에러가 나므로 try/except로 처리
        try:
            c.execute("ALTER TABLE trades ADD COLUMN pnl REAL DEFAULT 0")
            self.conn.commit()
        except sqlite3.OperationalError:
            pass  # 이미 pnl 컬럼이 존재하면 무시

        # ── 포지션 유형 시스템 마이그레이션 ──
        # 포지션 테이블에 유형/목표가/손절가/매매이유 등 추가
        _pos_migrations = [
            ("positions", "position_type TEXT DEFAULT ''"),
            ("positions", "position_type_en TEXT DEFAULT ''"),
            ("positions", "target_price REAL DEFAULT 0"),
            ("positions", "stop_price REAL DEFAULT 0"),
            ("positions", "reasons_json TEXT DEFAULT '[]'"),
            ("positions", "holding_period TEXT DEFAULT ''"),
            ("positions", "bought_at TEXT DEFAULT ''"),
            ("trades", "position_type TEXT DEFAULT ''"),
            ("trades", "reasons_json TEXT DEFAULT '[]'"),
            # ── ExitManager 추적 필드 (트레일링 스탑 / 분할 매도 / 본전 상향) ──
            ("positions", "entry_atr REAL DEFAULT 0"),                  # 진입 시점 ATR
            ("positions", "current_stop REAL DEFAULT 0"),               # 현재 활성 손절선 (트레일링 갱신)
            ("positions", "highest_since_entry REAL DEFAULT 0"),        # 최고가 (Chandelier용)
            ("positions", "partial_sold_pct REAL DEFAULT 0"),           # 이미 매도한 비중 (0/0.5/1.0)
            ("positions", "target_1 REAL DEFAULT 0"),                   # 1차 목표가
            ("positions", "target_2 REAL DEFAULT 0"),                   # 2차 목표가
            ("trades", "exit_reason TEXT DEFAULT ''"),                  # 청산 사유 (stop_loss, take_profit_1 등)
        ]
        for table, col_def in _pos_migrations:
            try:
                c.execute(f"ALTER TABLE {table} ADD COLUMN {col_def}")
                self.conn.commit()
            except sqlite3.OperationalError:
                pass  # 이미 존재

    # === 캐시 ===

    def set_cache(self, key: str, value: Any, ttl: int = 3600):
        """캐시 저장 (TTL: 유효 시간 초)"""
        expires_at = datetime.now() + timedelta(seconds=ttl)
        self.conn.execute(
            "INSERT OR REPLACE INTO cache (key, value, expires_at) VALUES (?, ?, ?)",
            (key, json.dumps(value, default=str), expires_at.isoformat()))
        self.conn.commit()

    def get_cache(self, key: str) -> Optional[Any]:
        """캐시 조회 (만료 시 None)"""
        row = self.conn.execute(
            "SELECT value, expires_at FROM cache WHERE key = ?", (key,)).fetchone()
        if not row:
            return None
        if datetime.now() > datetime.fromisoformat(row["expires_at"]):
            self.conn.execute("DELETE FROM cache WHERE key = ?", (key,))
            self.conn.commit()
            return None
        return json.loads(row["value"])

    def clear_expired_cache(self):
        """만료된 캐시 정리"""
        self.conn.execute("DELETE FROM cache WHERE expires_at < ?",
                          (datetime.now().isoformat(),))
        self.conn.commit()

    # === 거래 기록 ===

    def log_trade(self, symbol, side, quantity, price, strategy="", market="US",
                  signal_score=0.0, order_id="", pnl=0.0,
                  position_type="", reasons_json="[]",
                  total_value=None):
        """
        거래 기록 저장

        Parameters:
            symbol: 종목 코드
            side: "BUY" 또는 "SELL"
            quantity: 수량
            price: 체결 가격 (원래 통화 기준)
            strategy: 전략 이름
            market: "US" 또는 "KR"
            signal_score: 신호 점수
            order_id: 주문 ID
            pnl: 실현 손익 (매도 시에만 의미 있음, KRW 기준)
                 = (매도가 - 평균매수가) × 수량
            position_type: 포지션 유형 ("단타", "스윙", "장기")
            reasons_json: 매매 이유 JSON 문자열
            total_value: 거래 총액 (KRW 환산 기준).
                         None이면 quantity*price로 계산 (한국 주식용 하위 호환)
        """
        # ★ total_value가 명시적으로 전달되면 KRW 환산액 사용
        # 미국 주식은 USD가격 × 환율로 환산한 KRW 금액이 들어옴
        # 한국 주식은 quantity × price 그대로 (KRW = KRW)
        actual_total = total_value if total_value is not None else quantity * price
        self.conn.execute(
            """INSERT INTO trades
            (timestamp, symbol, market, side, quantity, price, total_value,
             strategy, signal_score, order_id, pnl, position_type, reasons_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (datetime.now().isoformat(), symbol, market, side, quantity, price,
             actual_total, strategy, signal_score, order_id, pnl,
             position_type, reasons_json))
        self.conn.commit()

    def get_trades(self, symbol=None, limit=100):
        """거래 기록 조회"""
        if symbol:
            cursor = self.conn.execute(
                "SELECT * FROM trades WHERE symbol = ? ORDER BY timestamp DESC LIMIT ?",
                (symbol, limit))
        else:
            cursor = self.conn.execute(
                "SELECT * FROM trades ORDER BY timestamp DESC LIMIT ?", (limit,))
        return [dict(row) for row in cursor.fetchall()]

    def get_trades_by_date(self, date_str):
        """특정 날짜 거래 조회"""
        cursor = self.conn.execute(
            "SELECT * FROM trades WHERE timestamp LIKE ? ORDER BY timestamp",
            (date_str + "%",))
        return [dict(row) for row in cursor.fetchall()]

    def get_trade_stats(self):
        """전체 거래 통계"""
        trades = [dict(r) for r in self.conn.execute("SELECT * FROM trades").fetchall()]
        if not trades:
            return {"total_trades": 0, "buy_count": 0, "sell_count": 0,
                    "unique_symbols": 0, "total_buy_value": 0, "total_sell_value": 0}
        buys = [t for t in trades if t["side"].upper() == "BUY"]
        sells = [t for t in trades if t["side"].upper() == "SELL"]
        return {
            "total_trades": len(trades), "buy_count": len(buys),
            "sell_count": len(sells),
            "unique_symbols": len(set(t["symbol"] for t in trades)),
            "total_buy_value": sum(t["total_value"] for t in buys),
            "total_sell_value": sum(t["total_value"] for t in sells),
        }

    # === 포지션 관리 ===

    def save_positions(self, positions):
        """
        포지션 전체 저장 (트랜잭션으로 원자적 실행)

        DELETE→INSERT를 하나의 트랜잭션에서 실행하여,
        중간에 크래시가 나도 데이터가 사라지지 않도록 보장합니다.
        (이전: DELETE 후 INSERT 전에 크래시 → 포지션 소실 위험)
        """
        try:
            self.conn.execute("BEGIN IMMEDIATE")
            self.conn.execute("DELETE FROM positions")
            for p in positions:
                self.conn.execute(
                    """INSERT INTO positions
                    (symbol, quantity, avg_price, current_price,
                     position_type, position_type_en, target_price, stop_price,
                     reasons_json, holding_period, bought_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (p["symbol"], p["quantity"], p["avg_price"],
                     p.get("current_price", 0),
                     p.get("position_type", ""),
                     p.get("position_type_en", ""),
                     p.get("target_price", 0),
                     p.get("stop_price", 0),
                     p.get("reasons_json", "[]"),
                     p.get("holding_period", ""),
                     p.get("bought_at", "")))
            self.conn.execute("COMMIT")
        except Exception:
            self.conn.execute("ROLLBACK")
            raise

    def update_position(self, symbol, quantity, avg_price, current_price=0,
                        position_type="", position_type_en="",
                        target_price=0, stop_price=0,
                        reasons_json="[]", holding_period="", bought_at=""):
        """포지션 UPSERT (포지션 유형 메타데이터 포함)"""
        self.conn.execute(
            """INSERT OR REPLACE INTO positions
               (symbol, quantity, avg_price, current_price, updated_at,
                position_type, position_type_en, target_price, stop_price,
                reasons_json, holding_period, bought_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (symbol, quantity, avg_price, current_price,
             datetime.now().isoformat(),
             position_type, position_type_en,
             target_price, stop_price,
             reasons_json, holding_period, bought_at))
        self.conn.commit()

    def load_positions(self):
        """DB에서 모든 포지션 복원"""
        return [dict(r) for r in
                self.conn.execute("SELECT * FROM positions ORDER BY symbol").fetchall()]

    def get_position(self, symbol):
        """특정 종목 포지션 조회"""
        row = self.conn.execute(
            "SELECT * FROM positions WHERE symbol = ?", (symbol,)).fetchone()
        return dict(row) if row else None

    def delete_position(self, symbol):
        """포지션 삭제"""
        self.conn.execute("DELETE FROM positions WHERE symbol = ?", (symbol,))
        self.conn.commit()

    # === 포트폴리오 스냅샷 (일별) ===

    def save_snapshot(self, total_value, cash, positions,
                      daily_return=0.0, cumulative_return=0.0, max_drawdown=0.0):
        """일일 포트폴리오 스냅샷 저장 (UPSERT)"""
        self.conn.execute(
            """INSERT OR REPLACE INTO portfolio_snapshots
            (date, total_value, cash, positions_json,
             daily_return, cumulative_return, max_drawdown)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (datetime.now().strftime("%Y-%m-%d"),
             total_value, cash, json.dumps(positions, default=str),
             daily_return, cumulative_return, max_drawdown))
        self.conn.commit()

    def get_snapshots(self, days=30):
        """최근 N일간 스냅샷"""
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM portfolio_snapshots ORDER BY date DESC LIMIT ?", (days,)
        ).fetchall()]

    def get_latest_snapshot(self):
        """최신 스냅샷"""
        row = self.conn.execute(
            "SELECT * FROM portfolio_snapshots ORDER BY date DESC LIMIT 1").fetchone()
        return dict(row) if row else None

    # === Equity History (시간별 자산 추적) ===

    def save_equity_snapshot(self, total_equity, cash, positions_value=0,
                              daily_pnl=0, cumulative_return=0):
        """자산 스냅샷 저장 (5분 간격)"""
        self.conn.execute(
            """INSERT INTO equity_history
               (timestamp, total_equity, cash, positions_value, daily_pnl, cumulative_return)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (datetime.now().isoformat(),
             total_equity, cash, positions_value, daily_pnl, cumulative_return))
        self.conn.commit()

    def get_equity_history(self, days=30):
        """최근 N일간 equity history"""
        since = (datetime.now() - timedelta(days=days)).isoformat()
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM equity_history WHERE timestamp >= ? ORDER BY timestamp ASC",
            (since,)).fetchall()]

    def get_latest_equity(self):
        """최신 equity 스냅샷"""
        row = self.conn.execute(
            "SELECT * FROM equity_history ORDER BY timestamp DESC LIMIT 1").fetchone()
        return dict(row) if row else None

    def calculate_max_drawdown(self, days=30):
        """최대 낙폭(MDD) 계산 (0~1)"""
        history = self.get_equity_history(days=days)
        if not history:
            return 0.0
        equities = [h["total_equity"] for h in history]
        peak = equities[0]
        max_dd = 0.0
        for eq in equities:
            if eq > peak:
                peak = eq
            dd = (peak - eq) / peak if peak > 0 else 0
            max_dd = max(max_dd, dd)
        return max_dd

    # === 신호 로그 ===

    def log_signal(self, symbol, signal_type, confidence, score,
                   components, reasons, acted_on=False):
        """매매 신호 기록"""
        self.conn.execute(
            """INSERT INTO signals
            (timestamp, symbol, signal_type, confidence, score,
             components_json, reasons_json, acted_on)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (datetime.now().isoformat(), symbol, signal_type, confidence, score,
             json.dumps(components), json.dumps(reasons), 1 if acted_on else 0))
        self.conn.commit()

    def get_signals(self, symbol=None, limit=50):
        """매매 신호 조회"""
        if symbol:
            cursor = self.conn.execute(
                "SELECT * FROM signals WHERE symbol = ? ORDER BY timestamp DESC LIMIT ?",
                (symbol, limit))
        else:
            cursor = self.conn.execute(
                "SELECT * FROM signals ORDER BY timestamp DESC LIMIT ?", (limit,))
        return [dict(row) for row in cursor.fetchall()]

    # === 데이터 초기화 ===

    def reset_all_data(self):
        """
        모든 거래/포지션/자산 데이터를 초기화합니다.

        삭제 대상:
        - positions: 보유 포지션
        - trades: 거래 이력
        - equity_history: 자산 추적 기록
        - portfolio_snapshots: 일일 스냅샷
        - signals: 매매 신호 기록

        보존 대상:
        - cache: 주가 데이터 캐시 (재다운로드 시간 절약)

        Returns:
            dict: 테이블별 삭제 건수
        """
        deleted = {}
        tables = ["positions", "trades", "equity_history",
                  "portfolio_snapshots", "signals"]

        for table in tables:
            try:
                cursor = self.conn.execute(f"SELECT COUNT(*) FROM {table}")
                count = cursor.fetchone()[0]
                self.conn.execute(f"DELETE FROM {table}")
                deleted[table] = count
            except Exception:
                deleted[table] = 0

        # AUTO_INCREMENT 카운터 리셋
        try:
            self.conn.execute(
                "DELETE FROM sqlite_sequence WHERE name IN (?, ?, ?, ?, ?)",
                tables
            )
        except Exception:
            pass

        self.conn.commit()
        return deleted
