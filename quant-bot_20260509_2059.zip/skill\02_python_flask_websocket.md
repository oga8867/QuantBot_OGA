# 02. Python Flask + WebSocket 실시간 대시보드

## 배운 것

Flask 기반 웹 대시보드에 WebSocket(Socket.IO)을 결합하여
실시간으로 봇 상태, 매매 신호, 거래 체결을 브라우저에 push하는 구조를 만들었다.

---

## 핵심 기술 스택

```
Flask           → HTTP API 서버 (REST endpoints)
Flask-SocketIO  → WebSocket 실시간 양방향 통신
Jinja2          → HTML 템플릿 렌더링
threading       → 봇을 백그라운드 스레드에서 실행
```

---

## Flask 기본 구조

```python
from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

# ── REST API 엔드포인트 ──
@app.route('/api/settings', methods=['GET', 'POST'])
def api_settings():
    if request.method == 'GET':
        return jsonify(current_settings)
    else:
        # POST: 설정 업데이트
        data = request.get_json()
        update_settings(data)
        return jsonify({"status": "ok"})

# ── WebSocket 이벤트 ──
@socketio.on('connect')
def handle_connect():
    print("[WebSocket] 클라이언트 연결됨")

# ── 서버 → 클라이언트 push ──
def broadcast_trade(trade_data):
    socketio.emit('trade_executed', trade_data)

# ── 실행 ──
if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
```

---

## WebSocket vs REST API 사용 구분

| 용도 | 방식 | 이유 |
|------|------|------|
| 설정 저장/로드 | REST (GET/POST) | 요청-응답 1회성 |
| 봇 시작/정지 | REST (POST) | 액션 트리거 |
| 스캐너 결과 | REST (GET) + 폴링 | 캐시된 데이터 조회 |
| 매매 체결 알림 | WebSocket (emit) | 실시간 push 필요 |
| 봇 상태 변경 | WebSocket (emit) | 즉시 UI 반영 필요 |
| 활동 로그 | WebSocket (emit) | 스트리밍 데이터 |

---

## 스레딩: Flask + 봇 동시 실행

```python
import threading, time

bot_instance = None  # 전역 봇 객체
bot_thread = None    # 봇 실행 스레드

@app.route('/api/bot/start', methods=['POST'])
def start_bot():
    global bot_instance, bot_thread
    
    # QuantBot 인스턴스 생성
    bot_instance = QuantBot(settings, broker="paper", live=False)
    
    # 별도 스레드에서 봇 실행 (Flask 메인 스레드 블로킹 방지)
    bot_thread = threading.Thread(target=_run_bot_thread, daemon=True)
    bot_thread.start()
    
    return jsonify({"status": "started"})

def _run_bot_thread():
    """봇 분석 루프 (백그라운드 스레드)"""
    interval_seconds = 300  # 5분
    last_analysis_time = time.time()
    
    # 초기 분석 1회
    _run_one_cycle("초기 분석")
    
    # 반복 분석 루프
    while bot_instance and bot_instance.running:
        time.sleep(1)  # CPU 부하 방지
        if time.time() - last_analysis_time >= interval_seconds:
            _run_one_cycle("정기 분석")
            last_analysis_time = time.time()
```

**핵심 교훈:**
- `daemon=True`로 스레드를 만들면 메인 프로세스 종료 시 함께 종료됨
- Flask의 메인 스레드를 블로킹하면 웹 요청을 처리할 수 없음
- `socketio.emit()`은 어떤 스레드에서든 호출 가능 (Flask-SocketIO가 처리)

---

## 캐시 버스팅 (Cache Busting)

```html
<!-- 브라우저가 구버전 JS/CSS를 캐시하는 문제 방지 -->
<script src="/static/js/main.js?v={{ cache_bust }}"></script>
<link rel="stylesheet" href="/static/css/style.css?v={{ cache_bust }}">
```

```python
# Flask에서 타임스탬프를 템플릿에 전달
@app.route('/')
def index():
    return render_template('index.html', cache_bust=int(time.time()))
```

이걸 안 하면 CSS/JS 수정해도 브라우저가 캐시된 구버전을 계속 보여줘서
"코드는 고쳤는데 왜 안 바뀌지?" 하게 된다.

---

## 실전 트러블슈팅

### 문제: socketio.run() vs app.run()
- `app.run()`을 쓰면 WebSocket이 작동하지 않음
- 반드시 `socketio.run(app, ...)`을 사용해야 함

### 문제: CORS 에러
- `SocketIO(app, cors_allowed_origins="*")`로 모든 오리진 허용
- 개발 환경에서는 `*`, 프로덕션에서는 특정 도메인만 허용 권장

### 문제: 다중 WebSocket 연결
- 브라우저 새 탭을 열 때마다 새 WebSocket 연결 생성됨
- `emit(broadcast=True)`로 모든 클라이언트에 전송
- 특정 클라이언트에만: `emit('event', data, room=request.sid)`
