"""
=============================================================================
executor/base.py - 주문 실행기 추상 베이스 클래스
=============================================================================

모든 주문 실행기(Executor)가 상속받는 인터페이스를 정의합니다.
Alpaca, 한국투자증권, 모의매매 등 브로커별 실행기가 이 인터페이스를 구현합니다.

실행기의 역할:
1. 주문 제출 (시장가/지정가/손절주문)
2. 주문 상태 확인
3. 포지션 조회
4. 계좌 잔고 확인
5. 주문 취소
=============================================================================
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, List
from dataclasses import dataclass
from enum import Enum
from datetime import datetime


class OrderSide(Enum):
    """주문 방향"""
    BUY = "buy"
    SELL = "sell"


class OrderType(Enum):
    """주문 유형"""
    MARKET = "market"      # 시장가 (즉시 체결, 가격 보장 없음)
    LIMIT = "limit"        # 지정가 (가격 지정, 체결 보장 없음)
    STOP = "stop"          # 스탑 (특정 가격 도달 시 시장가 전환)
    STOP_LIMIT = "stop_limit"  # 스탑 리밋 (스탑 + 지정가)


class OrderStatus(Enum):
    """주문 상태"""
    PENDING = "pending"        # 대기 중
    SUBMITTED = "submitted"    # 제출됨
    PARTIAL = "partial"        # 부분 체결
    FILLED = "filled"          # 전량 체결
    CANCELLED = "cancelled"    # 취소됨
    REJECTED = "rejected"      # 거부됨
    EXPIRED = "expired"        # 만료됨


@dataclass
class Order:
    """주문 정보"""
    symbol: str
    side: OrderSide
    order_type: OrderType
    quantity: int
    price: Optional[float] = None       # 지정가 (LIMIT/STOP_LIMIT)
    stop_price: Optional[float] = None  # 스탑 가격 (STOP/STOP_LIMIT)
    order_id: Optional[str] = None      # 브로커 할당 ID
    status: OrderStatus = OrderStatus.PENDING
    filled_price: Optional[float] = None
    filled_quantity: int = 0
    submitted_at: Optional[datetime] = None
    filled_at: Optional[datetime] = None
    strategy: str = ""                  # 어떤 전략이 주문했는지


@dataclass
class Position:
    """보유 포지션 정보"""
    symbol: str
    quantity: int
    avg_price: float             # 평균 매수 단가
    current_price: float = 0.0   # 현재가
    unrealized_pnl: float = 0.0  # 미실현 손익
    market_value: float = 0.0    # 시장가치
    side: str = "long"           # "long" or "short"

    @property
    def unrealized_pnl_pct(self) -> float:
        """미실현 수익률 (%) — avg_price 대비 현재가 변동 비율"""
        if self.avg_price <= 0:
            return 0.0
        return (self.current_price - self.avg_price) / self.avg_price


@dataclass
class AccountInfo:
    """계좌 정보"""
    total_equity: float = 0.0    # 총 자산
    cash: float = 0.0            # 현금
    buying_power: float = 0.0    # 매수 가능 금액
    positions_value: float = 0.0 # 보유 포지션 합계
    daily_pnl: float = 0.0      # 당일 손익
    currency: str = "KRW"


class BaseExecutor(ABC):
    """
    주문 실행기 추상 베이스 클래스

    모든 브로커 실행기는 이 클래스를 상속받아 구현합니다.
    인터페이스가 동일하므로 브로커를 교체해도 코드 변경이 최소화됩니다.
    """

    def __init__(self, name: str, paper: bool = True):
        """
        Parameters:
            name: 실행기 이름 (로깅용)
            paper: True=모의매매, False=실거래
        """
        self.name = name
        self.paper = paper
        self.orders: List[Order] = []

    @abstractmethod
    def connect(self) -> bool:
        """브로커 API 연결"""
        pass

    @abstractmethod
    def submit_order(self, order: Order) -> Order:
        """
        주문 제출

        Parameters:
            order: 주문 정보

        Returns:
            업데이트된 Order (order_id, status 포함)
        """
        pass

    @abstractmethod
    def cancel_order(self, order_id: str) -> bool:
        """주문 취소"""
        pass

    @abstractmethod
    def get_order_status(self, order_id: str) -> OrderStatus:
        """주문 상태 조회"""
        pass

    @abstractmethod
    def get_positions(self) -> List[Position]:
        """전체 보유 포지션 조회"""
        pass

    @abstractmethod
    def get_account(self) -> AccountInfo:
        """계좌 정보 조회"""
        pass

    def buy_market(self, symbol: str, quantity: int, strategy: str = "") -> Order:
        """시장가 매수 (편의 메서드)"""
        order = Order(
            symbol=symbol,
            side=OrderSide.BUY,
            order_type=OrderType.MARKET,
            quantity=quantity,
            strategy=strategy
        )
        return self.submit_order(order)

    def sell_market(self, symbol: str, quantity: int, strategy: str = "") -> Order:
        """시장가 매도 (편의 메서드)"""
        order = Order(
            symbol=symbol,
            side=OrderSide.SELL,
            order_type=OrderType.MARKET,
            quantity=quantity,
            strategy=strategy
        )
        return self.submit_order(order)

    def buy_limit(self, symbol: str, quantity: int, price: float, strategy: str = "") -> Order:
        """지정가 매수"""
        order = Order(
            symbol=symbol,
            side=OrderSide.BUY,
            order_type=OrderType.LIMIT,
            quantity=quantity,
            price=price,
            strategy=strategy
        )
        return self.submit_order(order)

    def close_position(self, symbol: str, strategy: str = "close_position") -> Optional[Order]:
        """특정 종목 전량 청산"""
        positions = self.get_positions()
        for pos in positions:
            if pos.symbol == symbol and pos.quantity > 0:
                return self.sell_market(symbol, pos.quantity, strategy=strategy)
        return None

    def close_partial(
        self, symbol: str, ratio: float, strategy: str = "close_partial"
    ) -> Optional[Order]:
        """
        보유 포지션의 일부 매도 (비중 기반)

        Parameters:
            symbol: 종목코드
            ratio: 매도 비중 (0.0~1.0, 예: 0.5 = 50%)
            strategy: 거래 사유 태그 (예: "take_profit_1")

        Returns:
            매도 주문 (None이면 보유 없음 또는 수량 0)

        주의: 1주 단위 절삭 (소수점 매도 불가)
              잔여 1주가 ratio*qty < 1 보다 많으면 1주 매도, 아니면 None
        """
        if ratio <= 0 or ratio > 1.0:
            return None
        positions = self.get_positions()
        for pos in positions:
            if pos.symbol == symbol and pos.quantity > 0:
                # 1주 단위 절삭 (반올림이 아닌 floor)
                sell_qty = int(pos.quantity * ratio)
                if sell_qty < 1:
                    # 1주 미만이면 ratio가 0.5 이상일 때만 1주 매도
                    if ratio >= 0.5 and pos.quantity >= 1:
                        sell_qty = 1
                    else:
                        return None
                if sell_qty >= pos.quantity:
                    sell_qty = pos.quantity  # 전량보다 많이 잡히지 않도록
                return self.sell_market(symbol, sell_qty, strategy=strategy)
        return None
