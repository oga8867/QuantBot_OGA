# 퀀트봇 프로젝트 스킬 노트

이 폴더는 퀀트봇 프로젝트를 진행하면서 사용한 기술, 배운 개념, 문제 해결 경험을 정리한 곳입니다.
프로젝트 기간 동안 겪은 실전 경험을 기록하여 다음 프로젝트에서 참고할 수 있도록 합니다.

---

## 파일 목록

### Phase 1: 초기 구축 (2026-04 ~ 2026-05-07)

| 파일 | 분류 | 내용 |
|------|------|------|
| [01_project_architecture.md](01_project_architecture.md) | 설계 | 프로젝트 구조 설계, 모듈 분리, 레이어드 아키텍처 |
| [02_python_flask_websocket.md](02_python_flask_websocket.md) | 백엔드 | Flask + Flask-SocketIO 실시간 웹 대시보드 구현 |
| [03_quant_finance_concepts.md](03_quant_finance_concepts.md) | 금융 | 퀀트 투자 개념 (앙상블, 팩터, Kelly, ATR, 안전장치) |
| [04_data_collection_api.md](04_data_collection_api.md) | 데이터 | yfinance, pykrx, DART API, Google News RSS 데이터 수집 |
| [05_database_sqlite.md](05_database_sqlite.md) | DB | SQLite 운용, 손상 복구, 시간대(UTC/KST) 문제 |
| [06_debugging_problem_solving.md](06_debugging_problem_solving.md) | 디버깅 | 실전 디버깅 사례 10가지 + 문제 해결 프레임워크 |
| [07_frontend_ui_ux.md](07_frontend_ui_ux.md) | 프론트 | PlayStation 스타일 UI, CSS 변수, 반응형 디자인 |
| [08_error_handling_resilience.md](08_error_handling_resilience.md) | 안정성 | 에러 복구, graceful degradation, 방어적 코딩 |
| [09_file_encoding_truncation.md](09_file_encoding_truncation.md) | 환경 | UTF-8 인코딩, 파일 잘림 문제, Windows 환경 주의점 |
| [10_agent_ai_workflow.md](10_agent_ai_workflow.md) | AI/자동화 | AI 에이전트 협업, 프롬프트 설계, 대규모 코드 관리 |
| [11_scheduler_timer.md](11_scheduler_timer.md) | 스케줄링 | APScheduler vs 직접 타이머, 백그라운드 작업 관리 |
| [12_security_safety.md](12_security_safety.md) | 보안 | 실거래 안전장치, 통화별 한도, 킬스위치 설계 |

### Phase 2: 안정성 + 검증 강화 (2026-05-08)

| 파일 | 분류 | 내용 |
|------|------|------|
| [13_position_management.md](13_position_management.md) | 청산 | ExitManager (ATR 손절/분할 익절/Chandelier 트레일링) |
| [14_strategy_validation.md](14_strategy_validation.md) | 검증 | Buy-and-Hold 벤치마크, 자동 백테스트, VIX 적응형 임계값 |
| [15_kis_realtime_integration.md](15_kis_realtime_integration.md) | API | 한국투자증권 KIS Open API 실시간 시세 + 매매 |
| [16_advanced_quant_models.md](16_advanced_quant_models.md) | 고급 | Risk Parity 자본 분할, 섹터 로테이션, 거래비용 모델 |
| [17_session_log_2026_05_08.md](17_session_log_2026_05_08.md) | 기록 | 2026-05-08 세션 로그 (버그 6개 + 신기능 9개) |
| [18_project_structure_v2.md](18_project_structure_v2.md) | 구조 | 현재 전체 디렉토리 트리 + 데이터 흐름도 + DB 스키마 v2 |

---

## 주제별 빠른 찾기

### 🔧 디버깅하다 막혔을 때
- 일반: [06_debugging_problem_solving.md](06_debugging_problem_solving.md)
- 봇 cash가 이상함: [17_session_log_2026_05_08.md](17_session_log_2026_05_08.md) Bug #1
- 그래프 안 뜸: [17_session_log_2026_05_08.md](17_session_log_2026_05_08.md) Bug #5
- 매도 신호인데 안 팔림: [13_position_management.md](13_position_management.md)
- BUY/SELL 케이싱: [17_session_log_2026_05_08.md](17_session_log_2026_05_08.md) Bug #2

### 💰 매매 전략 관련
- 앙상블 가중치: [03_quant_finance_concepts.md](03_quant_finance_concepts.md)
- 손절/익절/트레일링: [13_position_management.md](13_position_management.md)
- 자본 분할 (멀티 전략): [16_advanced_quant_models.md](16_advanced_quant_models.md) §1
- 섹터 로테이션: [16_advanced_quant_models.md](16_advanced_quant_models.md) §2
- 거래비용 모델: [16_advanced_quant_models.md](16_advanced_quant_models.md) §3
- 적응형 임계값: [14_strategy_validation.md](14_strategy_validation.md) §3

### ✅ 전략 검증 관련
- 백테스트 함정: [14_strategy_validation.md](14_strategy_validation.md) §2
- Buy-and-Hold 비교: [14_strategy_validation.md](14_strategy_validation.md) §1
- 회귀 테스트 패턴: [17_session_log_2026_05_08.md](17_session_log_2026_05_08.md) Phase 1-F
- 정보비율 해석: [14_strategy_validation.md](14_strategy_validation.md)

### 🔌 API 연동 관련
- 무료 데이터: [04_data_collection_api.md](04_data_collection_api.md)
- KIS 한국투자증권: [15_kis_realtime_integration.md](15_kis_realtime_integration.md)
- yfinance vs KIS 비교: [15_kis_realtime_integration.md](15_kis_realtime_integration.md)

### 🛡️ 보안 관련
- 일반 보안: [12_security_safety.md](12_security_safety.md)
- API 키 관리 (.env): [15_kis_realtime_integration.md](15_kis_realtime_integration.md)
- 회귀 테스트: [17_session_log_2026_05_08.md](17_session_log_2026_05_08.md)

### 📊 프로젝트 구조 이해
- 초기 설계: [01_project_architecture.md](01_project_architecture.md)
- v2 (현재): [18_project_structure_v2.md](18_project_structure_v2.md)

---

## 학습 경로 추천

### 처음 입문자
1. [01_project_architecture.md](01_project_architecture.md) — 큰 그림 이해
2. [03_quant_finance_concepts.md](03_quant_finance_concepts.md) — 퀀트 기본 개념
3. [04_data_collection_api.md](04_data_collection_api.md) — 데이터 수집
4. [05_database_sqlite.md](05_database_sqlite.md) — DB 기본
5. [02_python_flask_websocket.md](02_python_flask_websocket.md) — 웹 인터페이스

### 봇 안정성 강화
1. [08_error_handling_resilience.md](08_error_handling_resilience.md) — 에러 처리
2. [12_security_safety.md](12_security_safety.md) — 안전장치
3. [13_position_management.md](13_position_management.md) — 자동 청산
4. [14_strategy_validation.md](14_strategy_validation.md) — 검증

### 수익성 개선
1. [16_advanced_quant_models.md](16_advanced_quant_models.md) — 고급 모델
2. [14_strategy_validation.md](14_strategy_validation.md) §3 — 적응형 임계값
3. [15_kis_realtime_integration.md](15_kis_realtime_integration.md) — 실시간 연동

### 디버깅 / 트러블슈팅
1. [06_debugging_problem_solving.md](06_debugging_problem_solving.md)
2. [17_session_log_2026_05_08.md](17_session_log_2026_05_08.md) — 실제 버그 사례
3. [09_file_encoding_truncation.md](09_file_encoding_truncation.md) — 환경 문제

---

## 학술 자료 인덱스

이 프로젝트에서 인용/적용한 학술 모델:

| 모델/이론 | 출처 | 적용 위치 |
|---------|-----|---------|
| Le Beau Chandelier Exit | Le Beau & Lucas (1992) | ExitManager 트레일링 (×3 ATR) |
| Half-Kelly Position Sizing | Kelly (1956) + 현대 개정 | risk/position_sizer.py |
| ATR Square-Root Law | Almgren et al. (2005) | transaction_cost.py |
| Risk Parity | AQR (2012) | strategy/capital_allocator.py |
| 1/N Naive Diversification | DeMiguel et al. (2009) | 자본 분할 기본값 |
| VIX Regime Detection | Whaley (2000) | adaptive_threshold.py |
| Sector Rotation Theory | Stovall (1996) | strategy/sector_rotation.py |
| Optimal Execution | Almgren-Chriss (2000) | order_splitter.py |
| Hidden Markov Model | Baum-Welch | (미구현, 향후 추가) |

---

*최종 업데이트: 2026-05-08*
*총 문서: 18개 (Phase 1: 12개, Phase 2: 6개)*
