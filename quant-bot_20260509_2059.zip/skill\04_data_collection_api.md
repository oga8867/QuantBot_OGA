# 04. 데이터 수집 API 활용

## 배운 것

퀀트봇에서 가장 중요한 첫 단계는 "좋은 데이터를 안정적으로 가져오는 것"이다.
무료 API의 한계와 우회 방법을 많이 배웠다.

---

## 1. yfinance (미국 주식)

### 기본 사용법
```python
import yfinance as yf

# 단일 종목 3개월 데이터
ticker = yf.Ticker("AAPL")
df = ticker.history(period="3mo")
# → Date, Open, High, Low, Close, Volume 컬럼

# 기업 정보
info = ticker.info
name = info.get('shortName', 'Unknown')
per = info.get('trailingPE', None)
```

### 주의사항
- **무료 API이므로 요청 제한**이 있음. 너무 빈번하게 호출하면 차단됨
- `$SQ` (Block Inc.)처럼 **종목코드가 변경**된 경우 데이터가 없음
  - 에러: `possibly delisted; no price data found`
  - 해결: try-except로 감싸고, 실패 종목은 스킵
- `.info` 호출이 가끔 느리거나 실패함 → 캐시 + 하드코딩 폴백 필수
- 한국 종목도 `.KS`(코스피), `.KQ`(코스닥) 접미사로 조회 가능하지만 불안정

### 폴백 패턴 (이 봇에서 사용)
```python
# yfinance → 하드코딩 딕셔너리 → 종목코드 그대로 반환
def _get_stock_info(symbol):
    try:
        info = yf.Ticker(symbol).info
        return info.get('shortName', symbol)
    except:
        # 40+ 주요 종목 하드코딩 폴백
        fallback = {"AAPL": "Apple Inc.", "NVDA": "NVIDIA Corporation", ...}
        return fallback.get(symbol, symbol)
```

---

## 2. pykrx (한국 주식)

### 기본 사용법
```python
from pykrx import stock

# 종목명 조회
name = stock.get_market_ticker_name("005930")  # → "삼성전자"

# 가격 데이터
df = stock.get_market_ohlcv_by_date("20260101", "20260507", "005930")
# → 날짜, 시가, 고가, 저가, 종가, 거래량

# 전체 종목 리스트
tickers = stock.get_market_ticker_list("20260507", market="KOSPI")
```

### 주의사항
- **KRX 로그인**이 필요한 일부 기능이 있음 (환경변수 KRX_ID, KRX_PW)
  - 없으면: `KRX 로그인 실패: KRX_ID 또는 KRX_PW 환경변수가 설정되지 않았습니다.`
  - 기본 가격/종목명 조회는 로그인 없이도 가능
- 빈 데이터 반환 시 `index -1 is out of bounds for axis 0 with size 0` 에러
  - 해결: pykrx 실패 시 하드코딩 폴백 (41개 주요 종목)
- **코스닥 종목**은 `.KQ`, 코스피는 `.KS` 접미사
  - 주의: pykrx는 접미사 없는 순수 코드(005930)를, yfinance는 접미사 포함(005930.KS) 사용

### 종목명 캐시 패턴
```python
# 부팅 시 1회만 전체 종목명을 가져와서 캐시
_kr_name_cache = {}

def _build_kr_name_cache():
    try:
        tickers = stock.get_market_ticker_list(today, market="KOSPI")
        for code in tickers:
            _kr_name_cache[code] = stock.get_market_ticker_name(code)
    except:
        # 폴백: 주요 41개 종목 하드코딩
        _kr_name_cache = {"005930": "삼성전자", "000660": "SK하이닉스", ...}
```

---

## 3. Google News RSS (뉴스 감성)

```python
import feedparser

url = f"https://news.google.com/rss/search?q={keyword}&hl=ko&gl=KR"
feed = feedparser.parse(url)

for entry in feed.entries[:10]:
    title = entry.title
    published = entry.published
    link = entry.link
```

### 주의사항
- 무료이지만 요청 빈도 제한 있음
- 한국어 뉴스: `hl=ko&gl=KR`, 영어 뉴스: `hl=en&gl=US`
- 뉴스 본문은 못 가져옴 (제목만) → 키워드 기반 감성 분석

---

## 4. DART API (공시 정보)

```python
import requests

url = "https://opendart.fss.or.kr/api/list.json"
params = {
    "crtfc_key": DART_API_KEY,
    "corp_code": "00126380",  # 삼성전자
    "bgn_de": "20260101",
    "end_de": "20260507",
    "page_count": 10,
}
response = requests.get(url, params=params)
```

### 주의사항
- API 키 필요 (DART OpenAPI에서 발급)
- 일일 요청 제한: 10,000건
- 한국 종목만 지원

---

## 공통 교훈

1. **외부 API는 반드시 실패한다** → try-except + 폴백 필수
2. **캐시를 적극 활용** → 같은 데이터를 반복 요청하지 않기
3. **rate limit 준수** → time.sleep()으로 간격 두기
4. **데이터 검증** → 빈 DataFrame, None, NaN 체크 필수
5. **한국/미국 종목코드 형식 차이** → 접미사(.KS/.KQ) 변환 로직 필요
