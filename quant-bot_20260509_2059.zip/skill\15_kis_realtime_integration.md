# 15. KIS API 실시간 시세 연동

한국투자증권 Open API로 실시간 가격 조회 및 매매 실행.

---

## 핵심 깨달음

**무료 데이터 API의 한계를 넘으려면 증권사 API가 필요하다.**

| 데이터 소스 | 지연 | 비용 |
|----------|-----|-----|
| yfinance (Yahoo) | 15-20분 | 무료 |
| pykrx (KRX 공시) | 일/분봉 | 무료 |
| **KIS Open API** | **~1초** | **무료 (계좌 보유자)** |
| Bloomberg Terminal | 실시간 (틱) | $24,000/년 |

알고리즘 매매에서 15-20분 지연은 치명적이지 않지만, 진정한 실시간 가격은 결정의 정확도를 크게 향상시킨다.

---

## KIS API 시작 방법

### 1. 비대면 계좌 개설 (10-15분)
- 한국투자 모바일 앱 → "비대면 계좌개설"
- 신분증 + 휴대폰 + 1원 인증 (또는 영상통화)
- 영업일 기준 즉시~당일 활성화

### 2. 모의투자 신청 (필수, 권장)
- 한국투자 앱 → "모의투자" 메뉴
- 1억원 가상 자본 자동 지급
- 검증 후 실거래 전환 권장

### 3. Open API 신청
- [apiportal.koreainvestment.com](https://apiportal.koreainvestment.com) 가입
- "API 신청" → 1-2 영업일 내 승인
- 발급되는 정보:
  - **App Key** (36자리)
  - **App Secret** (180자리)
  - **계좌번호** (8-2 형식: `12345678-01`)

### 4. 호출 한도
- **일별 한도**: 200,000회/일
- **초당 한도**: 20회/초
- 대시보드 1분 갱신은 충분히 여유

---

## OAuth2 토큰 발급

```python
import requests

def get_access_token(app_key, app_secret, paper=True):
    base_url = (
        "https://openapivts.koreainvestment.com:29443"  # 모의
        if paper else
        "https://openapi.koreainvestment.com:9443"      # 실거래
    )
    response = requests.post(
        f"{base_url}/oauth2/tokenP",
        json={
            "grant_type": "client_credentials",
            "appkey": app_key,
            "appsecret": app_secret,
        },
        timeout=10,
    )
    return response.json()["access_token"]
```

**토큰 유효기간**: 24시간. 만료 임박 시 자동 갱신 패턴:

```python
def _ensure_token(self):
    if not self.access_token:
        return self._request_token()
    if datetime.now() >= self.token_expires:
        return self._request_token()
    return True
```

---

## 실시간 시세 조회

### 단일 종목 (1초 지연)

```python
def get_current_price(self, symbol: str) -> float:
    kis_symbol = symbol.replace(".KS", "").replace(".KQ", "")  # 6자리만
    
    response = requests.get(
        f"{base_url}/uapi/domestic-stock/v1/quotations/inquire-price",
        headers={
            "authorization": f"Bearer {access_token}",
            "appkey": app_key,
            "appsecret": app_secret,
            "tr_id": "FHKST01010100",   # 현재가 조회 TR
        },
        params={
            "FID_COND_MRKT_DIV_CODE": "J",   # J=주식
            "FID_INPUT_ISCD": kis_symbol,
        },
    )
    return float(response.json()["output"]["stck_prpr"])
```

### 일괄 조회 (호출 한도 보호)

```python
def get_current_prices(self, symbols: list) -> dict:
    result = {}
    for i, sym in enumerate(symbols):
        result[sym] = self.get_current_price(sym)
        # 18개마다 1초 대기 (분당 한도 보호)
        if (i + 1) % 18 == 0 and i < len(symbols) - 1:
            time.sleep(1.0)
    return result
```

### 시장 지수

```python
def get_index_quote(self, code: str) -> dict:
    """KOSPI=0001, KOSDAQ=1001, KOSPI200=2001"""
    response = requests.get(
        f"{base_url}/uapi/domestic-stock/v1/quotations/inquire-index-price",
        headers={..., "tr_id": "FHPUP02100000"},
        params={"FID_COND_MRKT_DIV_CODE": "U", "FID_INPUT_ISCD": code},
    )
    output = response.json()["output"]
    return {
        "price": float(output["bstp_nmix_prpr"]),
        "change": float(output["bstp_nmix_prdy_vrss"]),
        "change_pct": float(output["prdy_ctrt"]),
    }
```

---

## 주요 TR ID (Transaction ID)

KIS API는 모든 요청에 `tr_id` 헤더로 어떤 작업인지 명시:

| 작업 | 모의투자 | 실거래 |
|------|---------|-------|
| 현재가 조회 | FHKST01010100 | FHKST01010100 |
| 지수 조회 | FHPUP02100000 | FHPUP02100000 |
| 잔고 조회 | VTTC8434R | TTTC8434R |
| 매수 주문 | VTTC0802U | TTTC0802U |
| 매도 주문 | VTTC0801U | TTTC0801U |
| 정정/취소 | VTTC0803U | TTTC0803U |
| 체결 조회 | VTTC8001R | TTTC8001R |

**규칙**:
- `V` 접두사 = 모의투자 (VTS)
- `T` 접두사 = 실거래 (TTS)

---

## 싱글톤 클라이언트 패턴

매번 토큰 발급하지 않도록 캐시:

```python
_kis_price_client = None
_kis_price_client_lock = threading.Lock()

def get_kis_price_client():
    global _kis_price_client
    if _kis_price_client is not None:
        return _kis_price_client  # 빠른 경로
    
    with _kis_price_client_lock:  # 더블 체크 락
        if _kis_price_client is not None:
            return _kis_price_client
        
        app_key = os.environ.get("KIS_APP_KEY", "")
        if not app_key:
            return None  # 자격증명 없으면 None
        
        client = KISExecutor(paper=True)
        if client.connect():
            _kis_price_client = client
            return client
        return None
```

---

## Graceful Fallback (필수)

KIS 키가 없거나 실패 시 기존 yfinance/pykrx로 자동 폴백:

```python
def _refresh_position_prices():
    kr_remaining = list(kr_symbols)
    
    # 1순위: KIS API (실시간)
    kis_client = get_kis_price_client()
    if kis_client:
        try:
            prices = kis_client.get_current_prices(kr_symbols)
            for sym, price in prices.items():
                executor.set_current_price(sym, price)
                kr_remaining.remove(sym)
        except Exception as e:
            logger.debug(f"[KIS] 실패 → pykrx fallback: {e}")
    
    # 2순위: pykrx (KIS 미설정/실패)
    for sym in kr_remaining:
        try:
            df = pyk_stock.get_market_ohlcv(today, today, sym.replace(".KS", ""))
            executor.set_current_price(sym, float(df["종가"].iloc[-1]))
        except Exception:
            continue
```

---

## .env 파일 관리 (보안 핵심)

### 절대 하지 말아야 할 것
- ❌ 코드에 키 하드코딩
- ❌ 깃에 .env 커밋
- ❌ 채팅/이메일/스크린샷에 키 노출
- ❌ 공용 컴퓨터에 키 저장

### 올바른 패턴

`.env`:
```bash
KIS_APP_KEY=PSlawusu...
KIS_APP_SECRET=fOmb9rV09Wvr...
KIS_ACCOUNT=12345678-01
KIS_PAPER=true
```

`.gitignore`:
```
.env
.env.local
*.key
*.pem
data/
*.db
```

코드에서 로드:
```python
from dotenv import load_dotenv
load_dotenv()  # 자동으로 환경변수에 주입

app_key = os.environ.get("KIS_APP_KEY", "")
```

### 키 노출 시 대응
1. 즉시 [API 포털](https://apiportal.koreainvestment.com) → 마이페이지 → "앱 키 재발급"
2. 기존 키는 자동 무효화
3. .env 업데이트 후 봇 재시작

---

## 자격증명 검증 스크립트

키 입력 후 작동 확인 (키는 절대 출력 안 함):

```python
def mask(value, show=4):
    """앞 4자리 + ****  + 뒤 4자리"""
    if len(value) <= show:
        return "*" * len(value)
    return value[:show] + "*" * (len(value) - show - 4) + value[-4:]

# 1. .env 변수 확인
print(f"KIS_APP_KEY: {mask(app_key)} (길이 {len(app_key)})")

# 2. 토큰 발급 테스트
ex = KISExecutor(paper=True)
assert ex.connect(), "토큰 발급 실패"

# 3. 시세 조회 테스트 (삼성전자)
price = ex.get_current_price("005930")
assert price > 0, "시세 조회 실패"
print(f"✅ 모든 테스트 통과")
```

---

## 흔한 에러와 해결

### 1. "approval_key invalid"
- 모의투자 키로 실거래 서버에 요청 (또는 반대)
- 해결: `KIS_PAPER=true/false` 확인

### 2. "Account not found" or rt_cd != "0"
- 계좌번호 형식 잘못됨 (`12345678-01`이어야 함)
- API 신청이 아직 승인 안 됨

### 3. "Rate limit exceeded"
- 분당 호출 한도(20회/초) 초과
- 해결: 일괄 조회 시 18개마다 1초 대기

### 4. 모의투자 잔고가 ₩0
- 모의투자 메뉴에서 신청 안 했거나 활성화 지연
- 해결: 한국투자 앱 → 모의투자 → 신청 → 즉시 1억원 지급

### 5. "심볼 형식 오류"
- KIS는 6자리 숫자만 허용 (`.KS`, `.KQ` 제거 필요)
```python
def _strip_suffix(symbol):
    if symbol.endswith(".KS") or symbol.endswith(".KQ"):
        return symbol[:-3]
    return symbol
```

---

## WebSocket vs REST API

KIS는 두 가지 실시간 방식 제공:

| 방식 | 지연 | 구현 난이도 | 용도 |
|------|-----|----------|------|
| REST API (현재가) | ~1초 | ⭐ 쉬움 | 분봉 단위 매매 |
| WebSocket (체결가) | 틱 단위 | ⭐⭐⭐ 어려움 | 초단타, HFT |

대부분의 알고리즘에는 REST API로 충분. 진정한 틱 단위 데이터가 필요한 경우만 WebSocket 도입.

---

## 실거래 전환 체크리스트

```
[ ] 모의투자에서 최소 2-4주 검증
[ ] 알파 > 0 (벤치마크 초과)
[ ] 정보비율 > 0.3
[ ] MDD < 15%
[ ] 회귀 테스트 18/18 통과
[ ] KIS_PAPER=false 변경
[ ] 실거래 App Key/Secret 별도 발급 (모의 키와 다름)
[ ] 처음에는 자본금의 10%만 (소액)
[ ] 1주일 정상 작동 확인 후 점진 확대
```

---

## 보안 모범 사례 정리

1. **키 발급 단계에서 IP 제한** (가능하면 본인 IP만)
2. **봇 서버를 다른 IP/네트워크에 격리** (메인 PC와 분리)
3. **로그에 키 출력 금지** (마스킹 필수)
4. **실거래 키는 모의투자보다 더 엄격하게 관리**
5. **.env를 다른 사람과 공유 금지** (가족 PC도 위험)

---

*핵심: KIS API는 무료지만 강력하다. 호출 한도와 토큰 갱신만 잘 관리하면 개인 알고리즘 매매에 충분한 인프라.*
