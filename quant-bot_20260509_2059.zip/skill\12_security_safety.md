# 12. 실거래 보안 & 안전장치 설계

## 배운 것

"돈이 걸린 코드"는 일반 소프트웨어와 다른 수준의 안전성이 필요하다.
모의매매에서는 버그가 학습 기회지만, 실거래에서는 돈 손실이다.

---

## 1. SafetyGuard: 8단계 주문 검증

모든 주문은 실행 전 아래 체크를 **순서대로** 통과해야 한다.
하나라도 실패하면 주문이 차단되고, 사유가 로그에 기록된다.

```python
def check_order(self, symbol, side, quantity, price, 
                account_equity, positions) -> Tuple[bool, str]:
    
    order_value = quantity * price  # 주문 총액
    
    # 1. 킬 스위치 — 비상 정지
    if self.kill_switch:
        return False, f"킬 스위치 활성화: {self.kill_switch_reason}"
    
    # 2. 일일 손실 한도 — 하루 -3% 초과 시
    if self.daily_pnl < -(account_equity * self.config.max_daily_loss_pct):
        return False, "일일 손실 한도 초과"
    
    # 3. 일일 거래 횟수 — 50회 초과 시 (과매매 방지)
    if self.daily_trades_count >= self.config.max_daily_trades:
        return False, "일일 거래 횟수 한도"
    
    # 4. 연속 손실 — 5연패 시 쿨다운
    if self.consecutive_losses >= self.config.consecutive_loss_limit:
        return False, "연속 손실 한도 → 쿨다운 필요"
    
    # 매도는 위의 기본 체크만 통과하면 허용
    if side == "SELL":
        return True, "매도 주문 승인"
    
    # ── 이하 매수 전용 ──
    
    # 5. 주문 금액 범위 (통화별)
    if order_value < self.config.min_order_value:
        return False, "최소 주문 금액 미달"
    if order_value > self.config.max_order_value:
        return False, "최대 주문 금액 초과"
    
    # 6. 단일 주문 비율 — 자본의 10% 이하
    max_order = account_equity * self.config.max_order_pct
    if order_value > max_order:
        return False, "단일 주문 비율 초과"
    
    # 7. 최대 보유 종목 수 — 10개
    if len(set(p.symbol for p in positions)) >= self.config.max_positions:
        return False, "최대 보유 종목 수 초과"
    
    # 8. 종목당 비중 — 20% 이하
    # 기존 보유 + 신규 주문의 합이 전체 자산의 20% 초과 불가
    
    return True, "주문 승인"
```

---

## 2. 통화별 한도 설정 (실전 버그에서 배운 것)

### 문제
SafetyConfig의 `max_order_value`가 $50,000(USD)로 하드코딩.
KRW 주문(삼성전자 1,596,000원)이 $1,596,000로 취급되어 차단.

### 해결
```python
currency = getattr(settings.capital, 'currency', 'KRW')
capital = settings.capital.total_capital

if currency == "KRW":
    max_order_val = max(capital * 0.20, 70_000_000)  # 최소 7천만원
    min_order_val = 1000.0   # 최소 1,000원
else:  # USD
    max_order_val = max(capital * 0.20, 50_000)       # 최소 $50,000
    min_order_val = 10.0     # 최소 $10
```

### 교훈
금융 코드에서 **단위(unit)**를 명시하지 않으면 치명적이다.
변수명에 단위를 넣거나, 통화 정보를 항상 함께 전달해야 한다.

```python
# 나쁜 예
max_order_value = 50000  # 이게 원? 달러?

# 좋은 예
max_order_value_usd = 50000
max_order_value_krw = 70_000_000
```

---

## 3. 모의매매 vs 실거래 안전 차이

```python
SafetyConfig(
    # 모의매매 (paper=True)
    order_delay_sec=0,          # 대기 없음 (빠른 테스트)
    max_daily_trades=50,        # 넉넉하게
    
    # 실거래 (paper=False)  
    order_delay_sec=3,          # 3초 대기 (취소 기회)
    max_daily_trades=20,        # 보수적으로
)
```

실거래에서는 주문 전 3초 대기 시간을 줌.
이 시간에 "취소" 할 수 있는 기회 제공 (킬 스위치).

---

## 4. 킬 스위치 (Kill Switch)

```python
def activate_kill_switch(self, reason: str):
    """모든 거래를 즉시 중단"""
    self.kill_switch = True
    self.kill_switch_reason = reason
    logger.critical(f"[KILL SWITCH] 활성화: {reason}")
    # 이후 모든 check_order()가 False를 반환

def deactivate_kill_switch(self):
    """킬 스위치 해제 (수동)"""
    self.kill_switch = False
    self.kill_switch_reason = ""
    logger.info("[KILL SWITCH] 해제됨")
```

활용 시나리오:
- MDD 15% 초과 → 자동 킬 스위치
- 사용자가 대시보드에서 수동 활성화
- API 연결 불안정 감지 시

---

## 5. 거래 기록 추적

```python
def record_trade(self, symbol, side, value=0, pnl=0):
    """거래 기록 (일일 통계용)"""
    self.daily_trades_count += 1
    self.daily_pnl += pnl
    
    if pnl < 0:
        self.consecutive_losses += 1
    elif pnl > 0:
        self.consecutive_losses = 0  # 이기면 리셋
    
    self.trade_log.append({
        "time": datetime.now(),
        "symbol": symbol,
        "side": side,
        "value": value,
        "pnl": pnl,
    })
```

---

## 6. API 키 보안

```python
# 환경변수로 관리 (코드에 하드코딩 금지!)
import os

ALPACA_API_KEY = os.environ.get("ALPACA_API_KEY", "")
ALPACA_SECRET_KEY = os.environ.get("ALPACA_SECRET_KEY", "")
KIS_APP_KEY = os.environ.get("KIS_APP_KEY", "")
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "")

# .env 파일 또는 환경변수로 설정
# 절대 git에 커밋하면 안 됨! (.gitignore에 추가)
```

---

## 7. 메서드명 정확성 (send_alert 사건)

### 문제
```python
self.notifier.send_alert(msg)  # ← 존재하지 않는 메서드!
# AttributeError: 'TelegramNotifier' object has no attribute 'send_alert'
```

실제 메서드: `send_risk_alert(message, level)`

### 교훈
- 클래스의 실제 인터페이스를 반드시 확인
- IDE 자동완성이 없는 환경에서는 grep으로 확인:
  ```bash
  grep "def send_" notifier/telegram_bot.py
  ```
- 알림 시스템이 크래시하면 매매 후속 처리가 안 됨

---

## 8. 실거래 전환 체크리스트

실거래로 전환하기 전 반드시 확인할 것:

```
□ 모의매매 2~4주 이상 운영
□ 승률/MDD/Sharpe Ratio 확인
□ SafetyGuard 모든 한도 적절히 설정
□ 통화(KRW/USD) 올바르게 설정
□ API 키 환경변수로 안전하게 관리
□ 텔레그램/디스코드 알림 연결
□ 킬 스위치 동작 테스트
□ 소액(전체 자산의 10~20%)으로 시작
□ 손절선이 실제로 동작하는지 확인
□ 장 마감 후 자동 포지션 정리 확인
```

---

## 핵심 교훈

1. **안전장치는 보수적으로** — 오탐(잘못 차단)이 미탐(잘못 실행)보다 낫다
2. **통화 단위 항상 명시** — KRW과 USD를 혼동하면 100배 차이
3. **모의매매 충분히 돌린 뒤 실거래** — 최소 2주, 가능하면 한 달
4. **킬 스위치는 필수** — 비상 상황에서 1초 만에 전체 중단
5. **API 키는 코드에 넣지 않는다** — 환경변수 또는 별도 .env 파일
