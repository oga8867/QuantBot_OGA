# 09. 파일 인코딩 & 잘림 문제 (Windows 환경)

## 배운 것

Windows + 한글 + 대용량 파일 조합에서 인코딩/잘림 문제를 많이 겪었다.
특히 UTF-8 멀티바이트 문자(한글 3바이트)가 중간에 잘리면 치명적이다.

---

## 1. UTF-8 한글 잘림 문제 ★★★

### 사건
index.html이 47,135 바이트 지점에서 잘림.
한글 "설"(EC 84 A4)의 3바이트 중 2바이트(EC 84)만 남아서
Flask가 `UnicodeDecodeError`를 발생시킴.

### 왜 위험한가?
```
한글 한 글자 = UTF-8에서 3바이트
예: "설" = 0xEC 0x84 0xA4

파일이 0xEC 0x84에서 잘리면:
→ 바이트 스트림이 "불완전한 UTF-8 시퀀스"가 됨
→ Python이 파일을 읽을 수 없음
→ Flask가 템플릿을 렌더링할 수 없음
→ 서버 500 에러
```

### 진단 방법
```bash
# 파일 크기 확인
wc -c index.html  # → 47135 (비정상적으로 작음)

# 마지막 바이트 확인
xxd index.html | tail -5
# → EC 84 에서 끝남 (불완전한 UTF-8)

# Python으로 확인
with open('index.html', 'rb') as f:
    data = f.read()
    print(len(data))  # 바이트 수
    print(data[-10:])  # 마지막 10바이트
```

### 복원 방법
```bash
# 1. 불완전한 바이트 제거 (마지막 유효한 줄까지 자르기)
python3 -c "
data = open('index.html', 'rb').read()
# 마지막 개행 위치 찾기
last_newline = data.rfind(b'\n')
clean = data[:last_newline+1]
open('index.html', 'wb').write(clean)
"

# 2. 나머지 내용 이어붙이기
cat >> index.html << 'HEREDOC'
... 잘린 뒷부분 코드 ...
HEREDOC
```

---

## 2. 대용량 파일 수정 시 잘림 방지

### 문제
Edit 도구로 500줄 이상 파일을 수정하면 뒷부분이 잘리는 경우가 있다.
app.py (2300줄)에서 여러 차례 발생함.

### 해결책: bash `cat >>` 사용
```bash
# 큰 파일의 끝부분 추가/수정 시
cat >> /path/to/app.py << 'PYEOF'
def new_function():
    """이 함수는 bash로 안전하게 추가됨"""
    pass
PYEOF
```

### 안전한 수정 절차
```
1. 수정 전 백업: cp app.py app.py.bak
2. 수정할 부분 확인: wc -l app.py (줄 수)
3. 작은 수정: Edit 도구 사용 (100줄 이하 변경)
4. 큰 수정: bash로 직접 수정
5. 수정 후 검증: python3 -c "import ast; ast.parse(open('app.py').read())"
```

---

## 3. Windows BAT 파일 인코딩

### 문제
BAT 파일에 한글을 넣으면 `chcp 65001` 없이는 깨진다.

### 해결
```bat
@echo off
chcp 65001 >nul 2>&1
:: 이 아래부터 한글 사용 가능

echo 퀀트봇을 시작합니다...
python dashboard/app.py
```

- `chcp 65001` = 콘솔 코드페이지를 UTF-8로 변경
- `>nul 2>&1` = chcp 명령의 출력 숨기기
- BAT 파일 저장 시 반드시 "UTF-8 (BOM 없음)"으로 저장

---

## 4. Python 파일 인코딩 선언

```python
# -*- coding: utf-8 -*-
"""
이 파일은 한글 주석이 포함되어 있습니다.
Python 3에서는 기본이 UTF-8이지만, 명시적으로 선언하면 안전합니다.
"""
```

Python 3는 기본 UTF-8이지만, 일부 IDE나 도구에서 인코딩 감지 실패 시 도움.

---

## 5. JSON 한글 저장

```python
import json

settings = {"이름": "삼성전자", "코드": "005930"}

# ensure_ascii=False → 한글이 유니코드 이스케이프되지 않음
with open("settings.json", "w", encoding="utf-8") as f:
    json.dump(settings, f, ensure_ascii=False, indent=2)

# ensure_ascii=True (기본값) → "이름" 이 "이름"으로 저장됨
# ensure_ascii=False        → "이름" 그대로 저장됨 (가독성 좋음)
```

---

## 6. heredoc에서 특수문자 처리

```bash
# 따옴표로 감싼 heredoc: 변수 치환 안 됨 (안전)
cat >> file.py << 'EOF'
price = f"${value:,.2f}"  # $가 그대로 들어감
EOF

# 따옴표 없는 heredoc: 변수 치환됨 (위험!)
cat >> file.py << EOF
price = f"${value:,.2f}"  # $value가 쉘 변수로 해석됨!
EOF
```

**규칙:** 코드를 heredoc으로 붙일 때는 항상 `<< 'EOF'` (따옴표 포함) 사용.

---

## 핵심 교훈

1. **한글 파일은 항상 UTF-8로 저장** — BOM 없는 UTF-8 권장
2. **대용량 파일 수정 시 bash 사용** — Edit 도구의 크기 제한 주의
3. **수정 후 반드시 검증** — `python3 -c "ast.parse(...)"` 또는 `wc -l`
4. **BAT 파일에 `chcp 65001`** — Windows 콘솔 한글 필수
5. **JSON에 `ensure_ascii=False`** — 한글 가독성 유지
6. **heredoc에 따옴표** — `<< 'EOF'`로 변수 치환 방지
