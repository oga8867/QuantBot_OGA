# 06. 디버깅 & 문제 해결 실전 사례

## 배운 것

이 프로젝트에서 가장 많은 시간을 보낸 곳은 "새 기능 개발"이 아니라 "왜 안 되는지 찾기"였다.
아래는 실제로 겪은 디버깅 사례 10가지와 해결 과정이다.

---

## 문제 해결 프레임워크

어떤 버그를 만나든 이 순서로 접근하면 효율적이다:

```
1. 증상 정확히 기록 — "안 돼요"가 아니라 "무엇이, 언제, 어떻게"
2. 로그 확인 — 에러 메시지, 스택 트레이스 읽기
3. 재현 — 같은 조건에서 다시 발생하는지 확인
4. 가설 세우기 — "아마 ~일 것이다"
5. 가설 검증 — 최소한의 변경으로 테스트
6. 근본 원인 파악 — 증상이 아닌 원인을 고침
7. 회귀 방지 — 같은 문제가 다시 생기지 않도록
```

---

## 사례 1: 5분 반복 분석이 실행되지 않음

**증상:** 봇 시작 후 초기 분석은 되지만, 5분 뒤 반복 분석이 안 됨

**로그:** 에러 없음. 아무 일도 안 일어남.

**디버깅 과정:**
1. 분석 간격 설정 확인 → `analysis_interval: "5"` 정상
2. 스케줄러 코드 확인 → `JobManager.add_interval_job()` 호출됨
3. `add_interval_job()` 내부 확인 → **APScheduler가 None일 때 False를 리턴하고 끝남!**

```python
# scheduler/job_manager.py
def add_interval_job(self, func, minutes, job_id):
    if self.scheduler is None:  # APScheduler import 실패 시
        return False  # ← 조용히 실패! 에러 로그도 없음!
    self.scheduler.add_job(func, 'interval', minutes=minutes, id=job_id)
    return True
```

**근본 원인:** APScheduler가 설치되었지만 import 실패 시 `APSCHEDULER_AVAILABLE = False`

**해결:** APScheduler 의존성을 버리고, 직접 타이머 루프 구현
```python
while bot_instance and bot_instance.running:
    time.sleep(1)
    if time.time() - last_analysis_time >= interval_seconds:
        _run_one_cycle(f"정기 분석 #{cycle_count}")
        last_analysis_time = time.time()
```

**교훈:** "조용히 실패하는 코드"가 가장 위험하다. 실패하면 반드시 로그를 남겨야 한다.

---

## 사례 2: 모의매매가 전혀 실행되지 않음

**증상:** BUY 신호는 나오지만 실제 매수가 0건

**로그:** `database disk image is malformed`

**디버깅 과정:**
1. `_execute_buy()` 호출 여부 확인 → 호출 안 됨
2. 호출 전 코드 추적 → `log_signal()` 예외 발생
3. `log_signal()`에서 DB 에러 → 예외가 상위로 전파
4. `_analyze_symbol()`의 try-except가 전체를 감싸고 있어서, 
   DB 에러가 매수 실행까지 차단

**코드 흐름:**
```python
def _analyze_symbol(self, symbol):
    try:
        score = self.ensemble.combine(...)
        self.db.log_signal(...)  # ← 여기서 DB 에러!
        self._execute_buy(...)   # ← 여기에 도달 못 함
    except Exception as e:
        self.logger.error(f"분석 오류: {e}")  # DB 에러로 전체 스킵
```

**해결:** 
1. 손상된 DB를 새로 생성
2. `log_signal()`을 별도 try-except로 분리

**교훈:** 로깅(부수 효과)이 핵심 로직(매매)을 차단하면 안 된다.

---

## 사례 3: "오늘 신호 0개" 항상 표시

**증상:** 방금 신호를 생성했는데도 대시보드에 "오늘 신호 0개"

**디버깅 과정:**
1. DB에 신호가 저장되어 있는지 확인 → 저장됨
2. SQL 쿼리 확인 → `WHERE date(timestamp) = date('now')`
3. `date('now')` 결과 확인 → UTC 날짜!
4. 한국시간 04:00 = UTC 전날 19:00 → 날짜가 하루 다름

**해결:** Python에서 KST 날짜를 직접 계산하여 사용

**교훈:** SQLite의 날짜 함수는 항상 UTC이다.

---

## 사례 4: index.html UTF-8 잘림으로 서버 크래시

**증상:** Flask가 index.html을 렌더링하지 못하고 500 에러

**로그:** `UnicodeDecodeError: 'utf-8' codec can't decode byte 0xec`

**디버깅 과정:**
1. index.html을 열어보니 787번째 줄에서 한글 중간에 파일이 끝남
2. 바이트 크기 확인 → 정확히 47135 바이트에서 잘림
3. 한글은 UTF-8에서 3바이트인데, 2바이트째에서 잘려서 깨진 바이트

**해결:** 잘린 바이트를 제거하고 나머지 ~120줄을 bash `cat >>`로 이어붙임

**교훈:** 대용량 파일 수정 시 Edit 도구의 크기 제한에 주의.

---

## 사례 5: SafetyGuard가 KRW 주문을 USD로 해석

**증상:** 삼성전자 매수 시도 → `$1,596,000.00 > $50,000` 차단

**디버깅 과정:**
1. SafetyConfig 확인 → `max_order_value: float = 50000.0` (USD 하드코딩)
2. run_bot.py 확인 → SafetyConfig 생성 시 `max_order_value` 미지정
3. 삼성전자 30주 × 53,200원 = 1,596,000원 → 숫자만 비교 → 차단

**해결:** 통화(currency) 확인 후 적절한 한도 자동 설정
```python
if currency == "KRW":
    max_order_val = max(capital * 0.20, 70_000_000)  # 7천만원
else:
    max_order_val = max(capital * 0.20, 50_000)      # $50,000
```

**교훈:** 금융 코드에서 통화 단위 혼동은 치명적. 항상 통화를 명시적으로 다뤄야 한다.

---

## 사례 6: send_alert 메서드 없음

**증상:** SafetyGuard 차단 후 크래시
**로그:** `'TelegramNotifier' object has no attribute 'send_alert'`
**원인:** 실제 메서드명은 `send_risk_alert()`
**해결:** 메서드명 수정 (`send_alert` → `send_risk_alert`)
**교훈:** IDE 자동완성 없이 코딩할 때 실제 클래스의 메서드 시그니처를 반드시 확인

---

## 사례 7: app.py 2197줄에서 잘림

**증상:** 서버 시작은 되지만 일부 기능 미동작
**원인:** Edit 도구로 대형 파일 수정 시 뒷부분이 잘림
**해결:** 마지막 유효 줄까지 남기고, 나머지를 bash `cat >>`로 이어붙임
**교훈:** 500줄 이상 파일은 Edit 도구 대신 bash로 수정

---

## 사례 8: Start Bot 버튼 클릭 안 됨

**증상:** 버튼은 보이지만 클릭 시 아무 반응 없음
**디버깅:** 브라우저 콘솔 → JS 에러 (다른 함수에서 예외 발생 → 전역 중단)
**교훈:** JS에서 한 곳의 에러가 전체 이벤트 리스너를 죽일 수 있음

---

## 사례 9: PaperExecutor 거래 이력 소실

**증상:** 서버 재시작하면 모의매매 이력이 사라짐
**원인:** PaperExecutor가 메모리에만 데이터 보관
**해결:** SQLite에 positions, trades 테이블 추가 + connect()에서 복원
**교훈:** "상태"가 있는 객체는 영속화 전략이 필수

---

## 사례 10: 스캐너 카드에 종목명 안 나옴

**증상:** 코드(005930.KS)만 표시되고 이름(삼성전자)이 없음
**원인:** `_get_stock_info()` 함수가 이전 잘림 사고에서 누락됨
**디버깅:** NameError가 발생했지만 try-except에 잡혀서 조용히 실패
**해결:** 함수 전체를 복원 (yfinance + 폴백 딕셔너리 + pykrx 캐시)
**교훈:** "조용히 실패하는 코드"는 기능 누락을 인지하기 어렵게 만든다.

---

## 디버깅 도구 정리

| 상황 | 도구 |
|------|------|
| Python 런타임 에러 | 서버 로그 (터미널 출력) |
| JS 에러 | 브라우저 개발자 도구 → Console |
| DB 상태 확인 | sqlite3 CLI 또는 Python 스크립트 |
| API 응답 확인 | 브라우저 Network 탭 또는 curl |
| 파일 잘림/인코딩 | `wc -c` (바이트 수), `file` (인코딩 확인) |
| 함수 호출 추적 | 로그에 진입/종료 기록 추가 |
