# 07. 프론트엔드 UI/UX (PlayStation 스타일 대시보드)

## 배운 것

금융 대시보드는 정보가 많아서 UI 설계를 잘못하면 쓸 수 없게 된다.
PlayStation의 다크 모드 UI를 참고하여 깔끔한 대시보드를 만들었다.

---

## 1. 디자인 시스템: CSS 변수

```css
:root {
    /* ── 메인 컬러 ── */
    --bg-primary: #0a0a0f;        /* 배경 (거의 검정) */
    --bg-card: #14141f;           /* 카드 배경 */
    --bg-hover: #1e1e2e;          /* 호버 시 */
    --accent: #00d4ff;            /* PlayStation 블루 (강조색) */
    --accent-hover: #00b8e6;      
    
    /* ── 상태 컬러 ── */
    --green: #00e676;             /* 수익/매수/상승 */
    --red: #ff5252;               /* 손실/매도/하락 */
    --yellow: #ffd740;            /* 경고/HOLD */
    --text-primary: #ffffff;      
    --text-secondary: #b0b0b8;    
    
    /* ── 레이아웃 ── */
    --radius: 12px;               /* 카드 모서리 둥글기 */
    --gap: 16px;                  /* 그리드 간격 */
}
```

**왜 CSS 변수?**
- 테마 변경이 쉬움 (라이트 모드 전환 시 변수만 바꾸면 됨)
- 일관된 디자인 유지 (색상을 하드코딩하면 불일치 발생)
- 유지보수 편리 (한 곳만 수정하면 전체 반영)

---

## 2. 탭 기반 네비게이션

```html
<nav class="tabs">
    <button class="tab active" data-tab="overview">개요</button>
    <button class="tab" data-tab="scanner">스캐너</button>
    <button class="tab" data-tab="analysis">분석</button>
    <button class="tab" data-tab="settings">설정</button>
    <button class="tab" data-tab="guide">가이드</button>
</nav>

<section id="tab-overview" class="tab-content">...</section>
<section id="tab-scanner" style="display:none;">...</section>
```

```javascript
// 탭 전환 로직
document.querySelectorAll('.tab').forEach(btn => {
    btn.addEventListener('click', () => {
        // 모든 탭 비활성화
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('[id^="tab-"]').forEach(s => s.style.display = 'none');
        
        // 클릭된 탭 활성화
        btn.classList.add('active');
        document.getElementById(`tab-${btn.dataset.tab}`).style.display = 'block';
    });
});
```

---

## 3. 카드 컴포넌트 패턴

```css
.card {
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 20px;
    border: 1px solid rgba(255,255,255,0.06);
    transition: border-color 0.2s;
}
.card:hover {
    border-color: var(--accent);
}
```

대시보드의 거의 모든 것이 카드 안에 들어간다.
카드는 독립적인 정보 단위를 표현하는 기본 블록.

---

## 4. 반응형 그리드 (CSS Grid)

```css
.grid-3 {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: var(--gap);
}

/* 모바일에서 1열로 */
@media (max-width: 768px) {
    .grid-3 {
        grid-template-columns: 1fr;
    }
}
```

---

## 5. 실시간 데이터 표시 패턴

```javascript
// Socket.IO로 실시간 업데이트 수신
socket.on('trade_executed', (data) => {
    // 1. 토스트 알림 표시 (3초 후 자동 사라짐)
    showToast(`${data.action} ${data.symbol} ${data.shares}주`, 
              data.action === 'BUY' ? 'success' : 'warning');
    
    // 2. 활동 피드에 추가
    addActivityItem(data);
    
    // 3. 관련 카드 값 업데이트
    updatePortfolioCard(data);
});

// 토스트 알림
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.getElementById('toastContainer').appendChild(toast);
    
    setTimeout(() => toast.remove(), 3000);
}
```

---

## 6. 모달 (종목 상세 팝업)

```javascript
function openStockModal(symbol, name) {
    document.getElementById('modalStockName').textContent = name;
    document.getElementById('modalStockSymbol').textContent = symbol;
    
    // 외부 링크 동적 생성 (네이버, 야후, 구글 등)
    const links = generateStockLinks(symbol);
    document.getElementById('modalLinks').innerHTML = links;
    
    // 뉴스 API 호출
    fetchStockNews(symbol, name);
    
    // 모달 표시
    document.getElementById('stockLinkModal').style.display = 'flex';
}

// 배경 클릭으로 닫기
function closeStockModal(event) {
    if (!event || event.target === event.currentTarget) {
        document.getElementById('stockLinkModal').style.display = 'none';
    }
}
```

---

## 7. 스캐너 카드: 이름 + 코드 표시

```javascript
// 종목 이름과 코드를 적절히 분리하여 표시
const rawName = item.name || item.symbol;
const cleanSymbol = item.symbol.replace(".KS", "").replace(".KQ", "");
const hasRealName = rawName !== item.symbol && rawName !== cleanSymbol;
const displayName = hasRealName ? rawName : cleanSymbol;
const displayCode = hasRealName ? cleanSymbol : "";

// 카드 HTML
`<strong>${displayName}</strong>
 ${displayCode ? `<span class="text-mute">${displayCode}</span>` : ''}`
```

---

## 실전 교훈

1. **국기 이모지(🇰🇷/🇺🇸) 대신 텍스트(KR/US)** 사용 — 이모지는 OS/브라우저마다 렌더링이 다름
2. **캐시 버스팅 필수** — `?v=timestamp`로 브라우저 캐시 문제 방지
3. **CSS 변수로 색상 관리** — 하드코딩 금지
4. **모바일 먼저 생각** — `@media` 쿼리로 반응형 대응
5. **정보 밀도 조절** — 한 화면에 너무 많은 정보 ≠ 좋은 UX
